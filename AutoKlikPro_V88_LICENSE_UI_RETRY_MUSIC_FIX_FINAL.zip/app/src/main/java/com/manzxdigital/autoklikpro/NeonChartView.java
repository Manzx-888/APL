package com.manzxdigital.autoklikpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Lightweight seven-day activity chart. Values are supplied by MainActivity from real session counters. */
public class NeonChartView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float[] values = {0,0,0,0,0,0,0};

    public NeonChartView(Context c, AttributeSet a) { super(c, a); init(); }
    public NeonChartView(Context c) { super(c); init(); }
    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        text.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
        text.setTextSize(9f * getResources().getDisplayMetrics().scaledDensity);
        text.setColor(0xFF777286);
    }
    public void setValues(float[] v) {
        if (v == null || v.length == 0) return;
        values = new float[7];
        int copy = Math.min(7, v.length);
        System.arraycopy(v, 0, values, 7 - copy, copy);
        invalidate();
    }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        if (w <= 0 || h <= 0) return;
        float left=22f, right=w-4f, top=6f, bottom=h-22f;
        float chartH=Math.max(1f,bottom-top);
        float max=1f;
        for(float v:values) max=Math.max(max,v);
        if(max>10f) max=(float)Math.ceil(max/5f)*5f;
        else max=10f;

        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(0x553E2A68);
        for(int i=0;i<3;i++) {
            float y=top+chartH*i/2f;
            c.drawLine(left,y,right,y,p);
        }
        text.setTextAlign(Paint.Align.RIGHT);
        // Scale the axis to the real daily volume. The previous fixed 0/5/10
        // labels made a 1,000+ activity day look like a 10-task day.
        float mid = max / 2f;
        c.drawText(formatAxis(max), left-5, top+3, text);
        c.drawText(formatAxis(mid), left-5, top+chartH/2f+3, text);
        c.drawText("0", left-5, bottom+3, text);

        float gap=(right-left)/(values.length);
        glow.setStyle(Paint.Style.FILL); glow.setColor(0xFF9D35FF); glow.setShadowLayer(14,0,0,0xCC8B20FF);
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF8E2DFF);
        for(int i=0;i<values.length;i++) {
            float x=left+gap*(i+.5f);
            float bh=(values[i]/max)*(chartH-4);
            float bw=Math.max(10,gap*.42f);
            RectF r=new RectF(x-bw/2,bottom-bh,x+bw/2,bottom);
            c.drawRoundRect(r,4,4,glow); c.drawRoundRect(r,4,4,p);
        }
        text.setTextAlign(Paint.Align.CENTER);
        // Label selalu Senin -> Minggu agar sinkron dengan data minggu kalender.
        String[] days={"Sen","Sel","Rab","Kam","Jum","Sab","Min"};
        for(int i=0;i<7;i++) c.drawText(days[i], left+gap*(i+.5f), h-5, text);
    }

    private String formatAxis(float value) {
        if (value >= 1000000f) return String.format(java.util.Locale.US, "%.1fM", value / 1000000f);
        if (value >= 1000f) return String.format(java.util.Locale.US, "%.1fk", value / 1000f);
        if (value >= 100f) return String.valueOf(Math.round(value));
        return String.valueOf(Math.round(value));
    }
}
