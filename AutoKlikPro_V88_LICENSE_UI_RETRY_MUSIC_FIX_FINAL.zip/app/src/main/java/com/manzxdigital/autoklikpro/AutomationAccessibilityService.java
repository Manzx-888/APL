package com.manzxdigital.autoklikpro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.app.KeyguardManager;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Bitmap;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.view.WindowManager;
import android.view.Gravity;
import android.view.View;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.util.Locale;
import java.util.List;
import com.manzxdigital.autoklikpro.engine.AppState;
import com.manzxdigital.autoklikpro.engine.Task;
import com.manzxdigital.autoklikpro.engine.TaskParser;

/**
 * Single-threaded state machine for Mutualan -> TikTok -> Mutualan.
 *
 * Contract:
 *  - LIKE +10 is locked and opened at most once per task.
 *  - FOLLOW +20 is locked and opened at most once per task.
 *  - TikTok is waited for; no timeout causes a blind BACK.
 *  - LIKE and FOLLOW first check whether the action is already complete.
 *  - An action is clicked only when it is still incomplete.
 *  - After a click, TikTok state is re-checked; incomplete state can be retried.
 *  - Return to Mutualan happens only after the TikTok action is verified.
 *  - Return to Mutualan refreshes the task list, then waits 2s before scanning again.
 *  - PAUSE cancels timers without destroying the state; PLAY resumes it.
 */
public class AutomationAccessibilityService extends AccessibilityService {
    private static volatile boolean running = false;
    private static volatile AutomationAccessibilityService instance;
    private static volatile boolean serviceConnected = false;

    private static final String TIKTOK_1 = "com.zhiliaoapp.musically";
    private static final String TIKTOK_2 = "com.ss.android.ugc.trill";
    private static final String MUTUALAN_PACKAGE = "com.mutualan";

    private static final long TIKTOK_TIMEOUT = 60000L;
    private long lastMusicResumeAt = 0L;
    private static final long RETURN_TIMEOUT = 12000L;
    private static final long FOLLOW_VERIFY_TIMEOUT = 15000L;
    private static final long LIKE_VERIFY_TIMEOUT = 15000L;
    private static final long MUTUALAN_RESUME_DELAY = 1200L;
    private static final long MUTUALAN_STABLE_DELAY = 2000L;
    private static final long MUTUALAN_REFRESH_WAIT = 2500L;
    private static final long ACTION_RETRY_DELAY = 2500L;
    private static final int MAX_ACTION_RETRIES = 5;
    private static final int PENDING_AUTO_OPEN_THRESHOLD = 25;
    private boolean pendingAutoOpenTriggered = false;
    // After leaving Tugas Tertunda, give Mutualan time to refresh its counter.
    // This prevents a stale "Ada 1 tugas tertunda" from immediately reopening
    // the pending page after the row has already disappeared.
    private long pendingMainRecheckBlockedUntil = 0L;
    private boolean pendingReturnInProgress = false;

    // Pending task recovery flow. Permanent verification errors are NOT deleted
    // immediately: open the task, open TikTok, perform the requested action,
    // verify it, swipe back to Mutualan, tap the detail to refresh verification,
    // and only delete after 3 failed verification attempts.
    private boolean pendingActionActive = false;
    private Task pendingActionTask = null;
    private int pendingActionAttempts = 0;
    private long pendingActionStartedAt = 0L;
    private long pendingActionToken = 0L;
    // One tap per pending verification cycle. Accessibility events can fire many times.
    private boolean pendingVerificationTapDone = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PendingRetryEngine pendingRetryEngine;

    // In-Mutualan control: the automation must be controllable without opening
    // MainActivity over Mutualan. Accessibility overlays do not need a separate
    // SYSTEM_ALERT_WINDOW permission.
    private WindowManager overlayManager;
    private WindowManager.LayoutParams overlayParams;
    private View overlayView;
    private TextView overlayAction;
    private boolean overlayMinimized = false;
    private float overlayDownX, overlayDownY;
    private int overlayStartX, overlayStartY;
    private float resizeDownX, resizeDownY;
    private int resizeStartW, resizeStartH;

    // The floating controller must never be visible on the lock screen.
    // Accessibility services can otherwise keep an accessibility overlay alive
    // while the device is locked. The receiver also hard-stops automation when
    // the screen is turned off so no task continues behind the lock screen.
    private final BroadcastReceiver screenStateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent == null ? "" : intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                running = false;
                ++stateToken;
                try { cancelScheduledWork(); } catch (Throwable ignored) {}
                try { if (pendingRetryEngine != null) pendingRetryEngine.pause(); } catch (Throwable ignored) {}
                removeControlOverlay();
                MainActivity.log("LOCK SCREEN — overlay ditutup dan automation dihentikan");
                MainActivity a = MainActivity.getInstance();
                if (a != null) a.refreshUi();
            }
        }
    };

    private enum State { IDLE, SCANNING, OPENING_TIKTOK, WAITING_FOLLOW, WAITING_LIKE, RETURNING, PENDING_OPENING, PENDING_VERIFYING }
    private enum MainFlowState { IDLE, START, SCAN_MAIN_TASK, EXEC_FOLLOW, EXEC_LIKE, OPEN_TIKTOK, WAIT_TIKTOK, FIND_ACTION, CLICK_ACTION, VERIFY_ACTION, RETURN_MUTUALAN, WAIT_MAIN_TASK_CHANGE, SAFE_STOP }
    private enum PendingFlowState { NONE, DETECTED, SCANNING, TASK_FOUND, PROCESSING, RETRYING, VERIFYING, EMPTY, SKIPPED, RETURN_BACK, STOPPED }
    private State state = State.IDLE;
    private MainFlowState mainFlowState = MainFlowState.IDLE;
    private PendingFlowState pendingFlowState = PendingFlowState.NONE;
    private boolean strictResumeScan = false;
    private int strictResumeMisses = 0;

    private String mutualanPackage = "";
    private long flowStartedAt = 0L;
    private long taskOpenStartedAt = 0L;
    private long stateToken = 0L;
    private long nextScanAt = 0L;
    private boolean scanPending = false;
    private long lastPullRefreshAt = 0L;
    private boolean refreshInProgress = false;
    private boolean ocrScanInProgress = false;
    private long lastOcrScanAt = 0L;

    private boolean taskLocked = false;
    private boolean followClicked = false;
    private Rect clickedFollowBounds = null;
    private boolean likeClicked = false;
    private Rect clickedLikeBounds = null;
    private boolean likeTaskActive = false;
    // Runtime diagnostics / legacy verification compatibility.
    private long lastLikeWaitLogAt = 0L;
    private long likeInitialCount = -1L;
    private int returnAttempts = 0;
    private int likeRetries = 0;
    private int followRetries = 0;
    private String activeTaskKey = "";
    private boolean activeTaskLike = false;
    private String activeTaskUsername = "";
    private String activeTaskFingerprint = "";
    private int taskVerifyRetries = 0;
    private String failedTaskKey = "";

    // Safe-mode / reset state. Safe mode is a terminal guard for a broken task:
    // recover to Mutualan, stop clicking, and leave PLAY/RESET usable.
    private boolean safeMode = false;
    private String safeReason = "";
    private long failedTaskUntil = 0L;

    public static void resetAutomation() {
        // RESET AWAL is a real state-machine reset, not a UI/log action.
        // It cancels every pending callback, clears safe-mode/retry guards,
        // returns to the neutral state, and explicitly re-enters Mutualan.
        running = false;
        AutomationAccessibilityService s = instance;
        if (s != null) {
            s.handler.post(s::resetInternal);
        }
        MainActivity.log("RESET AWAL — state automation dibersihkan");
        MainActivity a = MainActivity.getInstance();
        if (a != null) a.refreshUi();
    }

    public static boolean isSafeMode() {
        AutomationAccessibilityService s = instance;
        return s != null && s.safeMode;
    }

    public static String getStateLabel() {
        AutomationAccessibilityService s = instance;
        if (s == null) return "OFFLINE";
        if (s.safeMode) return "MODE AMAN";
        if (AppState.getMode() == AppState.Mode.RETRY && running) return "AUTOKLIK RETRY";
        switch (s.state) {
            case SCANNING: return "SCANNING";
            case OPENING_TIKTOK: return "MEMBUKA TIKTOK";
            case WAITING_FOLLOW: return "VERIFIKASI FOLLOW";
            case WAITING_LIKE: return "VERIFIKASI LIKE";
            case RETURNING: return "KEMBALI MUTUALAN";
            default: return running ? "READY" : "PAUSED";
        }
    }

    private void resetInternal() {
        ++stateToken;
        cancelScheduledWork();
        if (pendingRetryEngine != null) pendingRetryEngine.reset();
        AppState.resetAll();
        state = State.IDLE;
        mainFlowState = MainFlowState.IDLE;
        pendingFlowState = PendingFlowState.NONE;
        strictResumeScan = false;
        strictResumeMisses = 0;
        taskLocked = false;
        followClicked = false;
        clickedFollowBounds = null;
        likeClicked = false;
        clickedLikeBounds = null;
        likeTaskActive = false;
        refreshInProgress = false;
        ocrScanInProgress = false;
        returnAttempts = 0;
        likeRetries = 0;
        followRetries = 0;
        activeTaskKey = "";
        activeTaskLike = false;
        activeTaskUsername = "";
        activeTaskFingerprint = "";
        taskVerifyRetries = 0;
        failedTaskKey = "";
        AppState.setActiveTaskKey("");
        AppState.setRetryAttempt(0);
        flowStartedAt = 0L;
        taskOpenStartedAt = 0L;
        nextScanAt = 0L;
        scanPending = false;
        failedTaskUntil = 0L;
        pendingAutoOpenTriggered = false;
        pendingMainRecheckBlockedUntil = 0L;
        pendingReturnInProgress = false;
        clearPendingAction();
        safeMode = false;
        safeReason = "";
        running = false;
        updateOverlay();
        MainActivity.log("State siap dari awal — Mutualan akan dibuka ulang");
        // Force a fresh entry into the known Mutualan package. This removes the
        // common condition where the service state is reset but the foreground
        // screen remains TikTok/another app, making RESET look ineffective.
        handler.postDelayed(() -> {
            if (serviceConnected && launchMutualanPackage()) {
                MainActivity.log("RESET AWAL — Mutualan dibuka ulang");
            }
            MainActivity a = MainActivity.getInstance();
            if (a != null) a.refreshUi();
        }, 250L);
        MainActivity a = MainActivity.getInstance();
        if (a != null) a.refreshUi();
    }

    public static void setRunning(boolean value) {
        AutomationAccessibilityService s = instance;

        if (!value) {
            // STOP must be a hard, immediate state change. Do not wait for a
            // retry timer, TikTok verification timeout, or pending callback.
            running = false;
            if (s != null) {
                ++s.stateToken;
                s.taskLocked = false;
                s.followClicked = false;
                s.clickedFollowBounds = null;
                s.likeClicked = false;
                s.clickedLikeBounds = null;
                s.likeTaskActive = false;
                s.refreshInProgress = false;
                s.ocrScanInProgress = false;
                s.clearPendingAction();
                s.state = State.IDLE;
                s.mainFlowState = MainFlowState.IDLE;
                s.pendingFlowState = PendingFlowState.STOPPED;
                s.strictResumeScan = false;
                s.strictResumeMisses = 0;
                try { s.cancelScheduledWork(); } catch (Throwable ignored) {}
                try { if (s.pendingRetryEngine != null) s.pendingRetryEngine.pause(); } catch (Throwable ignored) {}
                try { s.updateOverlay(); } catch (Throwable ignored) {}
            }
            MainActivity.log("■ STOP — automation dihentikan segera");
            MainActivity a = MainActivity.getInstance();
            if (a != null) a.refreshUi();
            return;
        }

        if (s != null && s.isDeviceLocked()) {
            MainActivity.log("PLAY ditolak — layar sedang terkunci");
            return;
        }

        running = true;
        MainActivity.log("PLAY — automation aktif");
        if (s != null) { try { SpotifyMediaNotificationService.keepSpotifyPlaying(); } catch (Throwable ignored) {} }
        MainActivity a = MainActivity.getInstance();
        if (a != null) a.refreshUi();

        if (s != null) {
            s.cancelScheduledWork();
            s.refreshInProgress = false;
            s.safeMode = false;
            s.safeReason = "";
            s.failedTaskUntil = 0L;
            s.pendingAutoOpenTriggered = false;
            s.pendingMainRecheckBlockedUntil = 0L;
            s.pendingReturnInProgress = false;
            s.clearPendingAction();
            s.taskLocked = false;
            s.followClicked = false;
            s.clickedFollowBounds = null;
            s.likeClicked = false;
            s.clickedLikeBounds = null;
            s.likeTaskActive = false;
            s.returnAttempts = 0;
            s.likeRetries = 0;
            s.followRetries = 0;
            s.activeTaskKey = "";
            s.activeTaskUsername = "";
            s.activeTaskFingerprint = "";
            s.activeTaskLike = false;
            s.state = State.IDLE;
            s.mainFlowState = MainFlowState.START;
            s.pendingFlowState = PendingFlowState.NONE;
            s.strictResumeScan = false;
            s.strictResumeMisses = 0;
            ++s.stateToken;
            s.updateOverlay();
            if (s.pendingRetryEngine != null) { try { s.pendingRetryEngine.start(); } catch (Throwable t) { MainActivity.log("Retry engine gagal start: " + t.getClass().getSimpleName()); } }
            s.handler.post(s::resumeFromCurrentScreen);
        }
    }

    public static boolean isRunning() { return running; }
    public static boolean isTaskAutomationEnabled() {
        AutomationAccessibilityService s = instance;
        return true;
    }

    public static boolean isRetryAutomationEnabled() {
        AutomationAccessibilityService s = instance;
        return true;
    }
    public static boolean isServiceConnected() { return serviceConnected && instance != null; }

    public static void showOverlayFromUi() {
        AutomationAccessibilityService s = instance;
        if (s != null) s.handler.post(() -> {
            if (s.isDeviceLocked()) {
                MainActivity.log("Overlay tidak ditampilkan saat layar terkunci");
                return;
            }
            s.showControlOverlay();
            s.updateOverlay();
        });
    }


    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        serviceConnected = true;
        pendingRetryEngine = new PendingRetryEngine(this);
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(Intent.ACTION_USER_PRESENT);
            registerReceiver(screenStateReceiver, filter);
        } catch (Throwable ignored) {}
        MainActivity.log("Accessibility: TERHUBUNG");
        // Do NOT create the floating overlay automatically when the accessibility
        // service reconnects. It is shown only after the user explicitly requests
        // it from the Home screen. This prevents surprise overlays after reboot,
        // service reconnect, or returning from Android settings.
        if (running && !isDeviceLocked()) handler.post(this::resumeFromCurrentScreen);
    }

    private boolean isDeviceLocked() {
        try {
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            return km != null && km.isKeyguardLocked();
        } catch (Throwable ignored) {
            return true;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int fill, float radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }

    private TextView overlayText(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setFontFeatureSettings("kern");
        return v;
    }

    private void showControlOverlay() {
        if (overlayView != null || isDeviceLocked()) return;
        try {
            overlayManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (overlayManager == null) return;

            FrameLayout root = new FrameLayout(this);
            root.setPadding(dp(10), dp(8), dp(10), dp(10));
            root.setBackground(rounded(Color.rgb(11, 10, 21), 24, Color.rgb(143, 67, 255), 2));

            LinearLayout all = new LinearLayout(this);
            all.setOrientation(LinearLayout.VERTICAL);
            root.addView(all, new FrameLayout.LayoutParams(-1, -1));

            LinearLayout header = new LinearLayout(this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);

            ImageView bolt = new ImageView(this);
            bolt.setImageResource(R.drawable.ic_lightning);
            bolt.setColorFilter(Color.rgb(156, 74, 255));
            bolt.setContentDescription("AutoKlik Pro");
            bolt.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            header.addView(bolt, new LinearLayout.LayoutParams(dp(44), dp(42)));

            LinearLayout brand = new LinearLayout(this);
            brand.setOrientation(LinearLayout.VERTICAL);
            brand.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = overlayText("AutoKlik Pro", 19, Color.WHITE);
            title.setTypeface(getResources().getFont(R.font.blaka), android.graphics.Typeface.BOLD);
            android.text.SpannableString brandText = new android.text.SpannableString("AutoKlik Pro");
            brandText.setSpan(new android.text.style.ForegroundColorSpan(Color.WHITE), 0, 9, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            brandText.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(151, 54, 255)), 9, 12, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            title.setText(brandText);
            TextView subtitle = overlayText("BY MANZX DIGITAL", 8, Color.rgb(191, 116, 255));
            subtitle.setTypeface(getResources().getFont(R.font.climate_crisis), android.graphics.Typeface.NORMAL);
            subtitle.setLetterSpacing(0.18f);
            brand.addView(title, new LinearLayout.LayoutParams(-1, dp(26)));
            brand.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(15)));
            header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

            ImageView minimize = new ImageView(this);
            minimize.setImageResource(R.drawable.ic_minimize);
            minimize.setContentDescription("Minimalkan overlay");
            minimize.setScaleType(ImageView.ScaleType.CENTER);
            minimize.setOnClickListener(v -> {
                overlayMinimized = !overlayMinimized;
                overlayAction.setVisibility(overlayMinimized ? View.GONE : View.VISIBLE);
                minimize.setImageResource(overlayMinimized ? R.drawable.ic_add : R.drawable.ic_minimize);
                resizeOverlayWindow(dp(280), overlayMinimized ? dp(62) : dp(150));
            });
            header.addView(minimize, new LinearLayout.LayoutParams(dp(40), dp(42)));

            ImageView close = new ImageView(this);
            close.setImageResource(R.drawable.ic_close);
            close.setContentDescription("Tutup overlay");
            close.setScaleType(ImageView.ScaleType.CENTER);
            close.setOnClickListener(v -> removeControlOverlay());
            header.addView(close, new LinearLayout.LayoutParams(dp(40), dp(42)));
            all.addView(header, new LinearLayout.LayoutParams(-1, dp(44)));

            overlayAction = overlayText("", 1, Color.WHITE);
            overlayAction.setGravity(Gravity.CENTER);
            overlayAction.setTypeface(getResources().getFont(R.font.germania_one), android.graphics.Typeface.BOLD);
            overlayAction.setOnClickListener(v -> setRunning(!running));
            updateOverlayAction(overlayAction);
            LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, dp(78));
            actionLp.topMargin = dp(5);
            all.addView(overlayAction, actionLp);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    dp(280), dp(150),
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(90);
            overlayParams = lp;
            overlayView = root;
            attachOverlayDrag(bolt);
            attachOverlayDrag(brand);
            overlayManager.addView(overlayView, overlayParams);
        } catch (Exception e) {
            overlayView = null;
            MainActivity.log("Overlay kontrol gagal: " + e.getClass().getSimpleName());
        }
    }

    private void attachOverlayDrag(View handle) {
        handle.setOnTouchListener((v, event) -> {
            if (overlayManager == null || overlayParams == null) return false;
            switch (event.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    overlayDownX = event.getRawX();
                    overlayDownY = event.getRawY();
                    overlayStartX = overlayParams.x;
                    overlayStartY = overlayParams.y;
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    float dx=event.getRawX()-overlayDownX, dy=event.getRawY()-overlayDownY;
                    if(Math.abs(dx)<4f && Math.abs(dy)<4f) return true;
                    overlayParams.x = overlayStartX + (int)dx;
                    overlayParams.y = overlayStartY + (int)dy;
                    clampOverlayPosition();
                    try { overlayManager.updateViewLayout(overlayView, overlayParams); } catch (Throwable ignored) {}
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    return true;
                default: return true;
            }
        });
    }

    private void attachOverlayResize(View handle) {
        handle.setOnTouchListener((v, event) -> {
            if (overlayManager == null || overlayParams == null) return false;
            switch (event.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    resizeDownX = event.getRawX();
                    resizeDownY = event.getRawY();
                    resizeStartW = overlayParams.width;
                    resizeStartH = overlayParams.height;
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    int minW = dp(240), minH = dp(86);
                    int maxW = (int)(getResources().getDisplayMetrics().widthPixels * 0.92f);
                    int maxH = (int)(getResources().getDisplayMetrics().heightPixels * 0.80f);
                    overlayParams.width = Math.max(minW, Math.min(maxW, resizeStartW + (int)(event.getRawX() - resizeDownX)));
                    overlayParams.height = Math.max(minH, Math.min(maxH, resizeStartH + (int)(event.getRawY() - resizeDownY)));
                    overlayMinimized = overlayParams.height <= dp(100);
                    try { overlayManager.updateViewLayout(overlayView, overlayParams); } catch (Exception ignored) {}
                    return true;
                default:
                    return event.getActionMasked() == android.view.MotionEvent.ACTION_UP;
            }
        });
    }

    private void resizeOverlayWindow(int width, int height) {
        if (overlayManager == null || overlayParams == null || overlayView == null) return;
        overlayParams.width = width;
        overlayParams.height = height;
        try { overlayManager.updateViewLayout(overlayView, overlayParams); } catch (Exception ignored) {}
    }

    private void clampOverlayPosition() {
        if (overlayParams == null) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int maxX = Math.max(0, (dm.widthPixels - overlayParams.width) / 2);
        int minX = -maxX;
        overlayParams.x = Math.max(minX, Math.min(maxX, overlayParams.x));
        int topLimit = dp(8);
        int bottomLimit = Math.max(topLimit, dm.heightPixels - overlayParams.height - dp(8));
        overlayParams.y = Math.max(topLimit, Math.min(bottomLimit, overlayParams.y));
    }

    private void updateOverlayAction(TextView action) {
        boolean active = running;
        action.setText(active ? "■   STOP\nHentikan otomatisasi" : "▶   MULAI");
        action.setTextSize(active ? 15 : 18);
        action.setTextColor(Color.WHITE);
        action.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable actionBg = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                active
                        ? new int[]{Color.rgb(118, 24, 50), Color.rgb(186, 32, 74)}
                        : new int[]{Color.rgb(86, 28, 220), Color.rgb(158, 60, 245)});
        actionBg.setCornerRadius(dp(36));
        actionBg.setStroke(dp(2), active ? Color.rgb(255, 74, 118) : Color.rgb(169, 84, 255));
        action.setBackground(actionBg);
        action.setContentDescription(active ? "Stop, hentikan otomatisasi" : "Play, mulai otomatisasi");
    }

    private void updateOverlay() {
        if (overlayView == null) return;
        if (overlayAction != null) updateOverlayAction(overlayAction);
    }

    private void removeControlOverlay() {
        try {
            if (overlayManager != null && overlayView != null) {
                overlayManager.removeView(overlayView);
            }
        } catch (Exception ignored) {}
        overlayView = null;
        overlayAction = null;
        overlayParams = null;
        overlayManager = null;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running) return;

        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        if (isTikTok(pkg) && shouldKeepMusicPlaying()) {
            long now = System.currentTimeMillis();
            if (now - lastMusicResumeAt > 4500L) {
                lastMusicResumeAt = now;
                SpotifyMediaNotificationService.keepSpotifyPlaying();
            }
        }
        if (safeMode) return;

        // Learn the Mutualan package from the actual accessibility event even when
        // Android temporarily returns a null active-window root. Older builds lost
        // every event in that situation and therefore never detected a task.
        // Mutualan is a known package from the supplied APK. Never learn an
        // arbitrary foreground app as Mutualan; that made the return/scanner
        // state lock onto the wrong package.
        if (MUTUALAN_PACKAGE.equals(pkg)) {
            if (!MUTUALAN_PACKAGE.equals(mutualanPackage)) {
                mutualanPackage = MUTUALAN_PACKAGE;
                MainActivity.log("Mutualan package terdeteksi: " + MUTUALAN_PACKAGE);
            }
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();

        // Pending permanent-error recovery owns its own Mutualan -> TikTok ->
        // Mutualan cycle. Do not let the normal pending scanner or main-task
        // scanner steal events while this cycle is active.
        if (pendingActionActive) {
            if (root != null && isTikTok(pkg) &&
                    (state == State.OPENING_TIKTOK || state == State.WAITING_FOLLOW || state == State.WAITING_LIKE)) {
                handleTikTok(root);
            } else if (root != null && isMutualanPackage(pkg)) {
                handlePendingMutualanScreen(root);
            }
            return;
        }

        // Tugas Tertunda is handled automatically. It is not a second mode and
        // never needs an overlay switch.
        if (pendingRetryEngine != null && root != null && pendingRetryEngine.isPendingScreen(root)) {
            pendingFlowState = PendingFlowState.DETECTED;
            pendingRetryEngine.onPendingEvent(root, pkg);
            return;
        }

        if (pendingRetryEngine != null && pendingRetryEngine.isBusy() && !isTikTok(pkg) && isMutualanPackage(pkg)) {
            pendingFlowState = PendingFlowState.PROCESSING;
            pendingRetryEngine.onPendingEvent(root, pkg);
            if (pendingRetryEngine.isBusy()) return;
        }

        if (state == State.OPENING_TIKTOK || state == State.WAITING_FOLLOW || state == State.WAITING_LIKE) {
            if (isTikTok(pkg) && root != null) handleTikTok(root);
            return;
        }

        if (root == null) return;

        if (state == State.RETURNING) {
            if (isMutualanPackage(pkg)) {
                finishReturn(root);
            }
            return;
        }

        if (state != State.IDLE && state != State.SCANNING) return;
        if (isTikTok(pkg) || pkg.equals(getPackageName()) ||
                pkg.equals("android") || pkg.startsWith("com.android.")) return;

        // Mutualan WebView/PWA sering memecah label, reward, dan username menjadi
        // node Accessibility yang berbeda. Jadi event Mutualan TIDAK boleh menunggu
        // "LIKE+10" atau "FOLLOW+20" berada di node yang sama. Cukup jadwalkan satu
        // scan ter-debounce; scanner yang menentukan apakah memang ada task.
        if (MUTUALAN_PACKAGE.equals(pkg)) {
            mutualanPackage = MUTUALAN_PACKAGE;
            if (System.currentTimeMillis() >= nextScanAt && !scanPending) {
                scanPending = true;
                nextScanAt = System.currentTimeMillis() + 700L;
                handler.postDelayed(this::scanCurrentTask, 80L);
            }
        }
    }


    private void resumeFromCurrentScreen() {
        if (!running) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            schedule(500, this::resumeFromCurrentScreen);
            return;
        }

        String pkg = getCurrentPackage(root);

        if (isTikTok(pkg)) {
            if (state == State.OPENING_TIKTOK || state == State.WAITING_FOLLOW || state == State.WAITING_LIKE) {
                handleTikTok(root);
            } else {
                MainActivity.log("PLAY di TikTok tanpa task aktif — tidak klik apa pun");
            }
            return;
        }

        if (isMutualanPackage(pkg)) {
            if (pendingRetryEngine != null && pendingRetryEngine.isPendingScreen(root)) {
                pendingRetryEngine.onPendingEvent(root, pkg);
                return;
            }
            if (mutualanPackage.isEmpty()) mutualanPackage = pkg;
            if (state == State.RETURNING) {
                finishReturn(root);
                return;
            }
            if (state == State.IDLE || state == State.SCANNING) {
                state = State.SCANNING;
                schedule(MUTUALAN_RESUME_DELAY, this::scanCurrentTask);
            }
            return;
        }

        // When PLAY is pressed while the screen is somewhere else, do not click or
        // launch another application. Wait for the user/current flow to return.
        schedule(700, this::resumeFromCurrentScreen);
    }

    private boolean retryLockActive() {
        // Two independent locks: taskLocked protects the current normal Task;
        // pendingActionActive/pendingRetryEngine protect Tugas Tertunda.
        // While retry is active, NEVER start a new +20/+10 target task.
        return pendingActionActive || (pendingRetryEngine != null && pendingRetryEngine.isBusy());
    }

    private void scanCurrentTask() {
        scanPending = false;
        if (!running || taskLocked || retryLockActive()) return;
        mainFlowState = MainFlowState.SCAN_MAIN_TASK;
        try {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            schedule(700L, this::scanCurrentTask);
            return;
        }

        String pkg = getCurrentPackage(root);
        if (pendingRetryEngine != null && pendingRetryEngine.isPendingScreen(root)) {
            pendingRetryEngine.scanNow();
            return;
        }
        if (!MUTUALAN_PACKAGE.equals(pkg)) {
            schedule(700L, this::resumeFromCurrentScreen);
            return;
        }

        // Always inspect the Mutualan tree first. The task label/reward/username
        // can be split across separate Accessibility nodes, so a same-node lookup
        // is not a valid gate.
        mutualanPackage = MUTUALAN_PACKAGE;
        scan(root);
        } catch (Throwable t) {
            taskLocked = false;
            MainActivity.log("scanCurrentTask aman dari crash: " + t.getClass().getSimpleName());
            schedule(1200L, this::scanCurrentTask);
        }
    }

    private boolean isMutualanHomeScreen(AccessibilityNodeInfo root) {
        if (root == null || !isMutualanPackage(getCurrentPackage(root))) return false;
        String text = normalize(nodeTextDeep(root));
        // Pending detail contains "Tugas Tertunda" but does not expose the
        // Mutualan home header "Beranda". This keeps page ownership deterministic.
        return text.contains("beranda") && text.contains("tugas tertunda");
    }

    private boolean openPendingSection(AccessibilityNodeInfo root) {
        if (root == null) return false;
        AccessibilityNodeInfo target = findTextNode(root, "tugas tertunda");
        if (target == null) return false;
        AccessibilityNodeInfo n = target;
        for (int i = 0; i < 8 && n != null; i++) {
            if (n.isVisibleToUser() && n.isEnabled() && n.isClickable()
                    && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                MainActivity.log("Tugas Tertunda → halaman dibuka otomatis");
                return true;
            }
            n = n.getParent();
        }
        Rect b = nodeBounds(target);
        if (!b.isEmpty() && performTap(b.centerX(), b.centerY())) {
            MainActivity.log("Tugas Tertunda → dibuka via tap otomatis");
            return true;
        }
        return false;
    }

    private AccessibilityNodeInfo findTextNode(AccessibilityNodeInfo node, String wanted) {
        if (node == null) return null;
        String t = normalize(nodeTextSelf(node));
        if (t.contains(normalize(wanted)) && isVisibleNode(node)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo f = findTextNode(node.getChild(i), wanted);
            if (f != null) return f;
        }
        return null;
    }

    private void scan(AccessibilityNodeInfo root) {
        if (!running || !isMutualanPackage(getCurrentPackage(root))) return;
        if (taskLocked || retryLockActive()) return;
        try {
            state = State.SCANNING;
            AppState.setMode(AppState.Mode.TASK);
            AppState.setTaskState(AppState.TaskState.SCANNING);

            // Only read the pending counter from Mutualan's HOME/TASK page.
            // The dedicated Tugas Tertunda page must never feed this counter back
            // into the opener, otherwise a stale accessibility tree can reopen the
            // same page immediately after a successful retry.
            boolean home = isMutualanHomeScreen(root);
            // Once the threshold has opened Tugas Tertunda, NEVER interpret a
            // partially-rendered pending page as the normal task list. The retry
            // engine owns that page until it explicitly proves the page is empty
            // and performs the real Accessibility BACK.
            if (!home && pendingAutoOpenTriggered && pendingRetryEngine != null
                    && pendingRetryEngine.isPendingScreen(root)) {
                AppState.setMode(AppState.Mode.RETRY);
                AppState.setTaskState(AppState.TaskState.SCANNING);
                pendingRetryEngine.onPendingEvent(root, MUTUALAN_PACKAGE);
                return;
            }
            int pendingCount = home && pendingRetryEngine != null
                    ? pendingRetryEngine.getPendingCount(root) : 0;

            // Retry has priority once the configured batch threshold is reached.
            // After a batch has started, keep the lock until the pending page is empty.
            int pendingThreshold = MainActivity.getPendingThreshold();
            boolean retryBatchActive = pendingRetryEngine != null && pendingRetryEngine.isBatchActive();
            if (!home && pendingAutoOpenTriggered && retryBatchActive) {
                AppState.setMode(AppState.Mode.RETRY);
                AppState.setTaskState(AppState.TaskState.SCANNING);
                if (pendingRetryEngine != null) pendingRetryEngine.scanNow();
                return;
            }
            if (home && pendingCount > 0 && (pendingCount >= pendingThreshold || retryBatchActive)) {
                long now = System.currentTimeMillis();
                if (now < pendingMainRecheckBlockedUntil) {
                    schedule(Math.max(250L, pendingMainRecheckBlockedUntil - now), this::scanCurrentTask);
                    return;
                }
                if (!pendingAutoOpenTriggered) {
                    pendingAutoOpenTriggered = true;
                    MainActivity.log("[LOCK] RETRY LOCK → " + pendingCount + " tugas tertunda → buka Tugas Tertunda dulu");
                }
                if (openPendingSection(root)) {
                    taskLocked = true;
                    state = State.SCANNING;
                    schedule(800L, () -> {
                        if (running && pendingRetryEngine != null) pendingRetryEngine.scanNow();
                    });
                    return;
                }
                MainActivity.log("Retry lock aktif, tetapi tombol Tugas Tertunda belum ditemukan → tunggu");
                schedule(700L, this::scanCurrentTask);
                return;
            }
            if (home && pendingCount < pendingThreshold && !(pendingRetryEngine != null && pendingRetryEngine.isBatchActive())) pendingAutoOpenTriggered = false;

            ListTaskCandidates candidates = collectMainTaskCandidates(root);
            AppState.setRemaining(Math.min(50, candidates.items.size()));

            // After Pending is emptied and BACK succeeds, resume strictly from
            // Accessibility Follow/Like candidates. Never spatial-click/OCR a
            // random control during this safety-critical resume.
            if (strictResumeScan && candidates.items.isEmpty()) {
                strictResumeMisses++;
                if (strictResumeMisses >= 4) {
                    strictResumeScan = false;
                    strictResumeMisses = 0;
                    enterSafeMode("Task utama kembali tetapi Follow/Like tidak terdeteksi");
                    return;
                }
                MainActivity.log("STRICT SCAN → Follow/Like belum terdeteksi, tunggu refresh " + strictResumeMisses + "/4");
                schedule(700L, this::scanCurrentTask);
                return;
            }
            if (!candidates.items.isEmpty()) {
                strictResumeScan = false;
                strictResumeMisses = 0;
            }
            MainActivity.refreshUiStatic();

            String excludedKey = failedTaskUntil > System.currentTimeMillis() ? failedTaskKey : "";
            for (TaskCandidate candidate : candidates.items) {
                if (!excludedKey.isEmpty() && excludedKey.equals(candidate.key)) continue;
                AccessibilityNodeInfo task = candidate.node;
                if ("follow".equals(candidate.type)) {
                    AppState.setTaskState(AppState.TaskState.TASK_FOUND);
                    AppState.incFollow();
                    startFollowFlow(task);
                    return;
                }
                if ("like".equals(candidate.type)) {
                    AppState.setTaskState(AppState.TaskState.TASK_FOUND);
                    AppState.incLike();
                    startLikeFlow(task);
                    return;
                }
            }

            MainActivity.log("Accessibility tree belum mengikat card task — scan spatial fallback");
            AccessibilityNodeInfo spatial = findSpatialTaskNode(root, failedTaskUntil > System.currentTimeMillis() ? failedTaskKey : "");
            if (spatial != null) {
                String context = spatialTaskContext(spatial, root);
                String type = actionTypeFromSpatialContext(spatial, root);
                if ("follow".equals(type)) {
                    AppState.setTaskState(AppState.TaskState.TASK_FOUND);
                    AppState.incFollow();
                    startFollowFlow(spatial);
                    return;
                }
                if ("like".equals(type)) {
                    AppState.setTaskState(AppState.TaskState.TASK_FOUND);
                    AppState.incLike();
                    startLikeFlow(spatial);
                    return;
                }
            }

            // OCR is only a last fallback. It is deliberately not used as a
            // prerequisite for a normal Accessibility-tree task.
            scheduleOcrScan();
            schedule(1600L, this::scanCurrentTask);
        } catch (Throwable t) {
            taskLocked = false;
            state = State.SCANNING;
            MainActivity.log("Scanner error aman: " + t.getClass().getSimpleName());
            schedule(1200L, this::scanCurrentTask);
        }
    }

    private static final class TaskCandidate {
        final AccessibilityNodeInfo node;
        final String context;
        final String type;
        final String key;
        TaskCandidate(AccessibilityNodeInfo node, String context, String type, String key) {
            this.node=node; this.context=context; this.type=type; this.key=key;
        }
    }

    private static final class ListTaskCandidates {
        final java.util.ArrayList<TaskCandidate> items = new java.util.ArrayList<>();
    }

    private ListTaskCandidates collectMainTaskCandidates(AccessibilityNodeInfo root) {
        ListTaskCandidates out = new ListTaskCandidates();
        if (root == null) return out;
        java.util.ArrayList<AccessibilityNodeInfo> raw = new java.util.ArrayList<>();
        collectActionNodes(root, raw);
        raw.sort((a,b) -> {
            Rect ra = nodeBounds(a), rb = nodeBounds(b);
            int y = Integer.compare(ra.top, rb.top);
            return y != 0 ? y : Integer.compare(ra.left, rb.left);
        });
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (AccessibilityNodeInfo n : raw) {
            String context = spatialTaskContext(n, root);
            String type = actionTypeForNode(n, context);
            if (type.isEmpty()) type = actionTypeFromSpatialContext(n, root);
            if (type.isEmpty()) continue;
            String user = TaskParser.username(context);
            String key = TaskParser.key(type + " " + context);
            String dedupe = type + "|" + user + "|" + nodeBounds(n).top;
            if (seen.add(dedupe)) out.items.add(new TaskCandidate(n, context, type, key));
            if (out.items.size() >= 50) break;
        }
        return out;
    }

    private void collectActionNodes(AccessibilityNodeInfo node, java.util.List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (isVisibleNode(node) && node.isEnabled()) {
            String own = normalize(nodeTextSelf(node));
            if (containsActionWord(own)) out.add(node);
        }
        for (int i=0; i<node.getChildCount(); i++) collectActionNodes(node.getChild(i), out);
    }

    private AccessibilityNodeInfo findVisibleMainTaskNode(AccessibilityNodeInfo root, String excludedKey) {
        if (root == null) return null;
        java.util.ArrayList<AccessibilityNodeInfo> raw = new java.util.ArrayList<>();
        collectActionNodes(root, raw);
        raw.sort((a,b) -> {
            Rect ra=nodeBounds(a), rb=nodeBounds(b);
            int y=Integer.compare(ra.top, rb.top);
            return y != 0 ? y : Integer.compare(ra.left, rb.left);
        });
        AccessibilityNodeInfo fallback=null;
        for (AccessibilityNodeInfo n : raw) {
            String context=spatialTaskContext(n, root);
            String type=actionTypeForNode(n, context);
            if (type.isEmpty()) type=actionTypeFromSpatialContext(n, root);
            if (type.isEmpty()) continue;
            if (fallback==null) fallback=n;
            String key=TaskParser.key(type + " " + context);
            if (excludedKey==null || excludedKey.isEmpty() || !excludedKey.equals(key)) return n;
        }
        return (excludedKey==null || excludedKey.isEmpty()) ? fallback : null;
    }

    private String actionTypeForNode(AccessibilityNodeInfo node, String context) {
        String own=normalize(nodeTextSelf(node));
        // Own label wins. This prevents a broad parent/card containing another
        // action from turning a LIKE card into FOLLOW (or vice versa).
        if (containsAnyWord(own, "follow", "ikuti")) return hasReward(context, "20") ? "follow" : "";
        if (containsAnyWord(own, "like", "suka")) return hasReward(context, "10") ? "like" : "";
        if (containsAnyWord(context, "follow", "ikuti") && hasReward(context, "20")) return "follow";
        if (containsAnyWord(context, "like", "suka") && hasReward(context, "10")) return "like";
        return "";
    }

    private boolean containsActionWord(String s) { return containsAnyWord(s,"follow","ikuti","like","suka"); }
    private boolean containsAnyWord(String s,String... words) {
        String x=normalize(s);
        for(String w:words) if(x.matches(".*\\b"+java.util.regex.Pattern.quote(w)+"\\b.*")) return true;
        return false;
    }

    private boolean hasReward(String text, String reward) {
        String x=normalize(text);
        return x.matches(".*(?<![0-9])\\+?"+reward+"(?![0-9]).*");
    }

    private Rect nodeBounds(AccessibilityNodeInfo n) {
        Rect r=new Rect(); if(n!=null)n.getBoundsInScreen(r); return r;
    }

    /**
     * Mutualan sometimes exposes a WebView card as unrelated Accessibility nodes:
     *   Follow
     *   @username
     *   +20 coin
     * with no useful parent/child relationship. Build a small spatial card from
     * every visible text node instead of assuming the Accessibility hierarchy is
     * faithful to the rendered card.
     */
    private String spatialTaskContext(AccessibilityNodeInfo action, AccessibilityNodeInfo root) {
        if (action == null || root == null) return taskContextText(action);
        Rect a = nodeBounds(action);
        StringBuilder s = new StringBuilder();
        java.util.ArrayList<AccessibilityNodeInfo> texts = new java.util.ArrayList<>();
        collectVisibleTextNodes(root, texts);
        texts.sort((x,y) -> {
            Rect rx=nodeBounds(x), ry=nodeBounds(y);
            int dy=Math.abs(a.centerY()-rx.centerY()) - Math.abs(a.centerY()-ry.centerY());
            return dy!=0 ? dy : Integer.compare(rx.top, ry.top);
        });
        for (AccessibilityNodeInfo n : texts) {
            String t=nodeTextSelf(n);
            if (t.isEmpty()) continue;
            Rect b=nodeBounds(n);
            int dy=Math.abs(a.centerY()-b.centerY());
            int dx=Math.abs(a.centerX()-b.centerX());
            boolean sameBand = dy <= dp(280);
            boolean horizontal = dx <= dp(520);
            if (sameBand && horizontal) appendOwn(s,n);
        }
        String local=taskContextText(action);
        if (!local.isEmpty()) {
            if (s.length()>0) s.append(' ');
            s.append(local);
        }
        return s.toString().trim();
    }

    private void collectVisibleTextNodes(AccessibilityNodeInfo node, java.util.List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (isVisibleNode(node) && !nodeTextSelf(node).isEmpty()) out.add(node);
        for (int i=0;i<node.getChildCount();i++) collectVisibleTextNodes(node.getChild(i),out);
    }

    private String actionTypeFromSpatialContext(AccessibilityNodeInfo action, AccessibilityNodeInfo root) {
        if (action == null || root == null) return "";
        String own=normalize(nodeTextSelf(action));
        String context=spatialTaskContext(action, root);
        if (containsAnyWord(own,"follow","ikuti") && hasReward(context,"20")) return "follow";
        if (containsAnyWord(own,"like","suka") && hasReward(context,"10")) return "like";
        return "";
    }

    private AccessibilityNodeInfo findSpatialTaskNode(AccessibilityNodeInfo root, String excludedKey) {
        if (root == null) return null;
        java.util.ArrayList<AccessibilityNodeInfo> raw=new java.util.ArrayList<>();
        collectActionNodes(root,raw);
        raw.sort((a,b)->{
            Rect ra=nodeBounds(a),rb=nodeBounds(b);
            int y=Integer.compare(ra.top,rb.top); return y!=0?y:Integer.compare(ra.left,rb.left);
        });
        for(AccessibilityNodeInfo n:raw){
            String type=actionTypeFromSpatialContext(n,root);
            if(type.isEmpty())continue;
            String ctx=spatialTaskContext(n,root);
            String key=TaskParser.key(type+" "+ctx);
            if(excludedKey==null||excludedKey.isEmpty()||!excludedKey.equals(key))return n;
        }
        return null;
    }

    private String taskContextText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder s=new StringBuilder();
        AccessibilityNodeInfo cur=node;
        for(int i=0;i<7&&cur!=null;i++){
            appendOwn(s,cur);
            Rect b=nodeBounds(cur);
            if(i>0&&b.height()>70&&b.height()<520&&b.width()>180){
                appendDescendantTextLimited(s,cur,2); break;
            }
            cur=cur.getParent();
        }
        AccessibilityNodeInfo parent=node.getParent();
        if(parent!=null) for(int i=0;i<parent.getChildCount();i++){
            AccessibilityNodeInfo c=parent.getChild(i); if(c!=null&&c!=node)appendOwn(s,c);
        }
        return s.toString().trim();
    }

    private void appendOwn(StringBuilder s, AccessibilityNodeInfo n){
        String x=nodeTextSelf(n); if(!x.isEmpty()){if(s.length()>0)s.append(' ');s.append(x);}
    }

    private void appendDescendantTextLimited(StringBuilder s, AccessibilityNodeInfo n, int depth){
        if(n==null||depth<0)return;
        for(int i=0;i<n.getChildCount();i++){
            AccessibilityNodeInfo c=n.getChild(i); if(c==null||!isVisibleNode(c))continue;
            appendOwn(s,c); if(depth>0)appendDescendantTextLimited(s,c,depth-1);
        }
    }

    private void scheduleOcrScan() {
        if (!running || taskLocked || state == State.RETURNING || state == State.OPENING_TIKTOK ||
                state == State.WAITING_FOLLOW || state == State.WAITING_LIKE) return;
        long now = System.currentTimeMillis();
        if (ocrScanInProgress || now - lastOcrScanAt < 1200L) return;
        lastOcrScanAt = now;
        handler.postDelayed(this::ocrScanMutualan, 250L);
    }

    private void ocrScanMutualan() {
        if (!running || taskLocked || android.os.Build.VERSION.SDK_INT < 30) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        String pkg = getCurrentPackage(root);
        // OCR is a fallback ONLY for Mutualan. The old code accepted every
        // non-TikTok package, so text from another foreground app could be
        // mistaken for a Mutualan task and lock the state machine.
        if (!MUTUALAN_PACKAGE.equals(pkg)) return;
        if (ocrScanInProgress) return;
        ocrScanInProgress = true;
        try {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY,
                    handler::post,
                    new AccessibilityService.TakeScreenshotCallback() {
                        @Override public void onSuccess(AccessibilityService.ScreenshotResult result) {
                            try {
                                android.hardware.HardwareBuffer hb = result.getHardwareBuffer();
                                android.graphics.ColorSpace cs = result.getColorSpace();
                                Bitmap bitmap = Bitmap.wrapHardwareBuffer(hb, cs);
                                if (bitmap == null) { finishOcr(); return; }
                                Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
                                bitmap.recycle();
                                hb.close();
                                runOcr(copy);
                            } catch (Exception e) {
                                MainActivity.log("OCR screenshot tidak tersedia — lanjut tree scan");
                                finishOcr();
                            }
                        }
                        @Override public void onFailure(int errorCode) {
                            MainActivity.log("OCR screenshot tidak tersedia (SecurityException/permission) — lanjut tree scan");
                            finishOcr();
                        }
                    });
        } catch (Exception e) {
            MainActivity.log("OCR tidak tersedia: " + e.getClass().getSimpleName());
            finishOcr();
        }
    }

    private void runOcr(Bitmap bitmap) {
        TextRecognizer recognizer = TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener(text -> {
                    try {
                        Text.Element bestLike = null;
                        Text.Element bestFollow = null;
                        java.util.ArrayList<Text.Element> els = new java.util.ArrayList<>();
                        for (Text.TextBlock block : text.getTextBlocks()) {
                            for (Text.Line line : block.getLines()) {
                                for (Text.Element el : line.getElements()) els.add(el);
                            }
                        }
                        for (Text.Element el : els) {
                            String t = compact(el.getText());
                            if (isOcrTaskLike(t)) bestLike = chooseTaskElement(bestLike, el);
                            if (isOcrTaskFollow(t)) bestFollow = chooseTaskElement(bestFollow, el);
                        }
                        // OCR sometimes splits "Follow" and "+20" into two elements
                        // or even two lines. Match an action element with a nearby
                        // reward element instead of requiring one combined token.
                        for (Text.Element el : els) {
                            String t=compact(el.getText());
                            if (containsActionWord(t)) {
                                Rect a=el.getBoundingBox();
                                for(Text.Element rEl:els){
                                    String rt=compact(rEl.getText());
                                    Rect rb=rEl.getBoundingBox();
                                    int dy=Math.abs(a.centerY()-rb.centerY());
                                    int dx=Math.abs(a.centerX()-rb.centerX());
                                    if(dy<=120 && dx<=420){
                                        if((containsAnyWord(t,"follow","ikuti") && hasReward(rt,"20")) || (containsAnyWord(t,"like","suka") && hasReward(rt,"10"))){
                                            if(containsAnyWord(t,"follow","ikuti")) bestFollow=chooseTaskElement(bestFollow,el);
                                            else bestLike=chooseTaskElement(bestLike,el);
                                        }
                                    }
                                }
                            }
                        }
                        // Select the uppermost actual task, not a global Follow priority.
                        Text.Element target = chooseUpper(bestLike, bestFollow);
                        if (target != null && !taskLocked) {
                            AccessibilityNodeInfo currentRoot = getRootInActiveWindow();
                            String currentPkg = getCurrentPackage(currentRoot);
                            if (!MUTUALAN_PACKAGE.equals(currentPkg)) {
                                return;
                            }
                            mutualanPackage = MUTUALAN_PACKAGE;
                            Rect r = target.getBoundingBox();
                            boolean targetFollow = target == bestFollow;
                            MainActivity.log((targetFollow ? "FOLLOW +20" : "LIKE +10") +
                                    " terdeteksi via OCR — TASK DI-LOCK");
                            taskLocked = true;
                            state = State.OPENING_TIKTOK;
                            likeTaskActive = !targetFollow;
                            AccessibilityNodeInfo ocrTaskNode = findTaskAny(currentRoot,
                                    targetFollow ? "follow" : "like",
                                    targetFollow ? "ikuti" : "suka",
                                    targetFollow ? "20" : "10");
                            activeTaskUsername = ocrTaskNode == null ? "" :
                                    TaskParser.username(spatialTaskContext(ocrTaskNode, currentRoot));
                            likeClicked = false;
                            followClicked = false;
                            clickedLikeBounds = null;
                            clickedFollowBounds = null;
                            likeRetries = 0;
                            followRetries = 0;
                            flowStartedAt = System.currentTimeMillis();
                            taskOpenStartedAt = flowStartedAt;
                            final long token = ++stateToken;
                            schedule(getDelayMs(), () -> {
                                if (!running || token != stateToken || state != State.OPENING_TIKTOK) return;
                                Rect click = expandOcrTaskButton(r);
                                if (tapScreen(click.centerX(), click.centerY())) {
                                    MainActivity.log("Task dibuka via OCR 1X — TUNGGU TikTok");
                                    waitForTikTok(token);
                                } else {
                                    MainActivity.log("Klik task via OCR gagal — unlock dan scan ulang");
                                    unlockAndScan();
                                }
                            });
                            return;
                        }
                        MainActivity.log("OCR: task LIKE/FOLLOW belum terlihat");
                    } finally {
                        bitmap.recycle();
                        finishOcr();
                    }
                })
                .addOnFailureListener(e -> {
                    bitmap.recycle();
                    MainActivity.log("OCR proses gagal");
                    finishOcr();
                });
    }

    private Text.Element chooseUpper(Text.Element a, Text.Element b) {
        if(a==null)return b; if(b==null)return a;
        return b.getBoundingBox().top < a.getBoundingBox().top ? b : a;
    }

    private Text.Element chooseTaskElement(Text.Element current, Text.Element candidate) {
        if (current == null) return candidate;
        Rect a = current.getBoundingBox();
        Rect b = candidate.getBoundingBox();
        return b.centerY() > a.centerY() ? candidate : current;
    }

    private boolean isOcrTaskLike(String t) {
        return "like10".equals(t) || "suka10".equals(t) || t.contains("like10") || t.contains("suka10");
    }

    private boolean isOcrTaskFollow(String t) {
        return "follow20".equals(t) || "ikuti20".equals(t) || t.contains("follow20") || t.contains("ikuti20");
    }

    private Rect expandOcrTaskButton(Rect textBounds) {
        // The OCR label sits inside the large task button. Use a conservative
        // center point with a wider hit area, avoiding the page edges.
        int cx = textBounds.centerX();
        int cy = textBounds.centerY();
        return new Rect(Math.max(0, cx - 260), Math.max(0, cy - 90),
                cx + 260, cy + 90);
    }

    private void finishOcr() {
        ocrScanInProgress = false;
        if (running && !taskLocked && (state == State.IDLE || state == State.SCANNING)) {
            schedule(1000L, this::scanCurrentTask);
        }
    }

    private void startLikeFlow(AccessibilityNodeInfo taskNode) {
        if (!running || taskLocked) return;

        taskLocked = true;
        mainFlowState = MainFlowState.EXEC_LIKE;
        state = State.OPENING_TIKTOK;
        mainFlowState = MainFlowState.OPEN_TIKTOK;
        likeClicked = false;
        clickedLikeBounds = null;
        likeTaskActive = true;
        activeTaskLike = true;
        String taskContext = spatialTaskContext(taskNode, getRootInActiveWindow());
        if (taskContext.isEmpty()) taskContext = taskContextText(taskNode);
        activeTaskUsername = TaskParser.username(taskContext);
        activeTaskFingerprint = buildTaskFingerprint(taskNode, taskContext, "like");
        String newTaskKey = TaskParser.key("like " + taskContext);
        if (!newTaskKey.equals(activeTaskKey)) taskVerifyRetries = 0;
        activeTaskKey = newTaskKey;
        AppState.setActiveTaskKey(activeTaskKey);
        likeRetries = 0;
        followClicked = false;
        clickedFollowBounds = null;
        flowStartedAt = System.currentTimeMillis();
        taskOpenStartedAt = flowStartedAt;
        returnAttempts = 0;
        final long token = ++stateToken;

        MainActivity.log("LIKE +10 terdeteksi — TASK DI-LOCK");

        schedule(getDelayMs(), () -> {
            if (!running || token != stateToken || state != State.OPENING_TIKTOK) return;

            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !isMutualanPackage(getCurrentPackage(root))) {
                MainActivity.log("Mutualan hilang sebelum klik task LIKE — TIDAK ulangi klik");
                waitForTikTok(token);
                return;
            }

            AccessibilityNodeInfo current = findTaskAny(root, "like", "suka", "10");
            if (current == null) {
                MainActivity.log("LIKE +10 hilang — unlock dan scan ulang");
                unlockAndScan();
                return;
            }

            AccessibilityNodeInfo action = findTaskAction(current);
            if (action == null || !clickNodeOnce(action)) {
                MainActivity.log("Klik task LIKE gagal — unlock dan scan ulang");
                unlockAndScan();
                return;
            }

            MainActivity.log("Task LIKE dibuka 1X — TUNGGU TikTok");
            waitForTikTok(token);
        });
    }

    private void startFollowFlow(AccessibilityNodeInfo taskNode) {
        if (!running || taskLocked) return;

        // Lock BEFORE scheduling or clicking. Accessibility events cannot start the
        // same task twice while the first click is being processed.
        taskLocked = true;
        mainFlowState = MainFlowState.EXEC_FOLLOW;
        state = State.OPENING_TIKTOK;
        mainFlowState = MainFlowState.OPEN_TIKTOK;
        followClicked = false;
        clickedFollowBounds = null;
        likeTaskActive = false;
        activeTaskLike = false;
        String taskContext = spatialTaskContext(taskNode, getRootInActiveWindow());
        if (taskContext.isEmpty()) taskContext = taskContextText(taskNode);
        activeTaskUsername = TaskParser.username(taskContext);
        activeTaskFingerprint = buildTaskFingerprint(taskNode, taskContext, "follow");
        String newTaskKey = TaskParser.key("follow " + taskContext);
        if (!newTaskKey.equals(activeTaskKey)) taskVerifyRetries = 0;
        activeTaskKey = newTaskKey;
        AppState.setActiveTaskKey(activeTaskKey);
        likeClicked = false;
        clickedLikeBounds = null;
        followRetries = 0;
        flowStartedAt = System.currentTimeMillis();
        taskOpenStartedAt = flowStartedAt;
        returnAttempts = 0;
        final long token = ++stateToken;

        MainActivity.log("FOLLOW +20 terdeteksi — TASK DI-LOCK");

        schedule(getDelayMs(), () -> {
            if (!running || token != stateToken || state != State.OPENING_TIKTOK) return;

            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !isMutualanPackage(getCurrentPackage(root))) {
                MainActivity.log("Mutualan hilang sebelum klik task — TIDAK ulangi klik");
                waitForTikTok(token);
                return;
            }

            AccessibilityNodeInfo current = findTaskAny(root, "follow", "ikuti", "20");
            if (current == null) {
                MainActivity.log("FOLLOW +20 hilang — unlock dan scan ulang");
                unlockAndScan();
                return;
            }

            AccessibilityNodeInfo action = findTaskAction(current);
            if (action == null || !clickNodeOnce(action)) {
                MainActivity.log("Klik task FOLLOW gagal — unlock dan scan ulang");
                unlockAndScan();
                return;
            }

            MainActivity.log("Task FOLLOW dibuka 1X — TUNGGU TikTok");
            waitForTikTok(token);
        });
    }

    private void waitForTikTok(long token) {
        if (!running || token != stateToken || state != State.OPENING_TIKTOK) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        String pkg = getCurrentPackage(root);

        if (isTikTok(pkg)) {
            mainFlowState = MainFlowState.WAIT_TIKTOK;
            state = likeTaskActive ? State.WAITING_LIKE : State.WAITING_FOLLOW;
            if (MainActivity.getInstance() != null
                    && MainActivity.getInstance().getPreferences(android.app.Activity.MODE_PRIVATE).getBoolean("keep_music", false)) {
                SpotifyMediaNotificationService.keepSpotifyPlaying();
                MainActivity.log("Kontrol musik → minta Spotify tetap PLAY");
            }
            MainActivity.log("TikTok aktif — tunggu profil/video siap");
            schedule(getActionDelayMs(), () -> {
                if (running && token == stateToken &&
                        (state == State.WAITING_FOLLOW || state == State.WAITING_LIKE)) {
                    handleTikTok(getRootInActiveWindow());
                }
            });
            return;
        }

        long elapsed = System.currentTimeMillis() - flowStartedAt;
        if (elapsed >= TIKTOK_TIMEOUT) {
            // Critical safety rule: NEVER press BACK when TikTok never opened.
            // Unlock instead so a stuck/failed Mutualan task cannot block the
            // other task type forever.
            MainActivity.log("TikTok tidak terbuka — unlock dan scan ulang, TIDAK BACK");
            unlockAndScan();
            return;
        }

        schedule(350L, () -> waitForTikTok(token));
    }

    private void handleTikTok(AccessibilityNodeInfo root) {
        if (!running || root == null || !isTikTok(getCurrentPackage(root))) return;

        if (likeTaskActive) {
            mainFlowState = MainFlowState.FIND_ACTION;
            // Existing liked state is accepted only when it is attached to the
            // exact Like control currently being processed.
            if (likeClicked && hasVerifiedLikeState(root)) {
                MainActivity.log("LIKE BERHASIL — status video terverifikasi");
                returnToMutualan();
                return;
            }

            if (!likeClicked) {
                AccessibilityNodeInfo existingLike = findTikTokLikeStateWithButton(root);
                if (existingLike != null) {
                    Rect b = new Rect();
                    existingLike.getBoundsInScreen(b);
                    clickedLikeBounds = b;
                    MainActivity.log("LIKE SUDAH AKTIF — status video terverifikasi");
                    returnToMutualan();
                    return;
                }

                AccessibilityNodeInfo button = findTikTokLikeButton(root);
                if (button != null) {
                    Rect bounds = new Rect();
                    button.getBoundsInScreen(bounds);

                    // Guard is set before the click because TikTok may emit an
                    // accessibility event immediately after ACTION_CLICK.
                    likeClicked = true;
                    clickedLikeBounds = bounds;

                    // Pure Accessibility target: no fixed screen coordinates,
                    // no like-count inference, no rail-position guessing.
                    if (clickExactTikTokLikeButton(button)) {
                        mainFlowState = MainFlowState.CLICK_ACTION;
                        state = State.WAITING_LIKE;
                        MainActivity.log("LIKE VIDEO diklik 1X — tunggu verifikasi");
                        schedule(getActionDelayMs(), this::verifyLike);
                        return;
                    }

                    likeClicked = false;
                    clickedLikeBounds = null;
                    MainActivity.log("LIKE → ACTION_CLICK gagal pada node Like");
                }
            } else {
                // Once clicked, verification owns the flow. handleTikTok must not
                // click the Like button again until verifyLike explicitly allows
                // another attempt.
                verifyLike();
                return;
            }
        } else {
            if (followClicked && hasVerifiedFollowState(root)) {
                MainActivity.log("FOLLOW BERHASIL — profil terverifikasi");
                returnToMutualan();
                return;
            }

            if (!followClicked) {
                AccessibilityNodeInfo existingFollow = findTikTokFollowVerifiedState(root);
                if (existingFollow != null) {
                    Rect b = new Rect();
                    existingFollow.getBoundsInScreen(b);
                    clickedFollowBounds = b;
                    MainActivity.log("FOLLOW SUDAH AKTIF — profil terverifikasi");
                    returnToMutualan();
                    return;
                }

                AccessibilityNodeInfo button = findTikTokFollowButton(root);
                if (button != null) {
                    Rect bounds = new Rect();
                    button.getBoundsInScreen(bounds);

                    followClicked = true;
                    clickedFollowBounds = bounds;

                    if (clickExactTikTokButton(button)) {
                        mainFlowState = MainFlowState.CLICK_ACTION;
                        state = State.WAITING_FOLLOW;
                        MainActivity.log("IKUTI TikTok diklik 1X — tunggu verifikasi");
                        schedule(getActionDelayMs(), this::verifyFollow);
                        return;
                    }

                    followClicked = false;
                    clickedFollowBounds = null;
                }
            } else {
                // Once clicked, verification owns the flow. No second click can
                // be triggered by Accessibility events.
                verifyFollow();
                return;
            }
        }

        long nowWait = System.currentTimeMillis();
        if (likeTaskActive && nowWait - lastLikeWaitLogAt >= 3000L) {
            lastLikeWaitLogAt = nowWait;
            AccessibilityNodeInfo ready = findTikTokLikeButton(root);
            if (ready == null) {
                MainActivity.log("LIKE → target hati belum terdeteksi di Accessibility, tunggu...");
            } else {
                MainActivity.log("LIKE → Button Accessibility terdeteksi, menunggu proses Like");
            }
        }

        if (nowWait - flowStartedAt >= TIKTOK_TIMEOUT) {
            MainActivity.log((likeTaskActive ? "Tombol Like" : "Tombol Ikuti")
                    + " tidak ditemukan — batalkan task dan kembali ke Mutualan");
            abortCurrentTaskToMutualan();
            return;
        }

        schedule(getPollingDelayMs(), () -> {
            if (running && (state == State.OPENING_TIKTOK ||
                    state == State.WAITING_FOLLOW || state == State.WAITING_LIKE)) {
                handleTikTok(getRootInActiveWindow());
            }
        });
    }

    private long parseLikeCount(String text) {
        if (text == null) return -1L;
        String t = normalize(text).replace(" ", "");
        if (t.isEmpty()) return -1L;

        // TikTok may expose the Like count as 21, 1.2K, 1,2K, 2M, etc.
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("^([0-9]+(?:[.,][0-9]+)?)([kKmMbB]?)$").matcher(t);
        if (!m.find()) return -1L;

        try {
            double value = Double.parseDouble(m.group(1).replace(',', '.'));
            String suffix = m.group(2).toLowerCase(Locale.ROOT);
            double multiplier = 1.0;
            if ("k".equals(suffix)) multiplier = 1_000.0;
            else if ("m".equals(suffix)) multiplier = 1_000_000.0;
            else if ("b".equals(suffix)) multiplier = 1_000_000_000.0;
            if (value < 0 || value > Long.MAX_VALUE / multiplier) return -1L;
            return Math.round(value * multiplier);
        } catch (Exception ignored) {
            return -1L;
        }
    }

    private boolean hasLikeCountIncreased(AccessibilityNodeInfo root) {
        if (root == null || likeInitialCount < 0) return false;
        long now = parseLikeCount(findCurrentTikTokLikeCountText(root));
        if (now < 0) {
            AccessibilityNodeInfo button = findTikTokLikeCountButton(root);
            if (button != null) now = parseLikeCount(nodeTextSelf(button));
        }
        return now >= 0 && now > likeInitialCount;
    }

    /**
     * Read the numeric Like count directly from the right action rail.
     * The count is deliberately allowed to be a non-clickable TextView: on
     * newer TikTok builds the clickable heart container and the count are
     * separate Accessibility nodes.
     */
    private String findCurrentTikTokLikeCountText(AccessibilityNodeInfo root) {
        if (root == null) return "";
        java.util.ArrayList<AccessibilityNodeInfo> candidates = new java.util.ArrayList<>();
        collectTikTokLikeCandidates(root, candidates);
        AccessibilityNodeInfo best = null;
        Rect bestRect = null;
        for (AccessibilityNodeInfo n : candidates) {
            String t = normalize(nodeTextSelf(n));
            if (!isNumericLikeCount(t)) continue;
            Rect r = nodeBounds(n);
            if (best == null || r.centerY() < bestRect.centerY() - 8
                    || (Math.abs(r.centerY() - bestRect.centerY()) <= 8
                    && r.centerX() > bestRect.centerX())) {
                best = n;
                bestRect = r;
            }
        }
        return best == null ? "" : normalize(nodeTextSelf(best));
    }

    private AccessibilityNodeInfo findTikTokLikeStateWithButton(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo likeButton = findTikTokLikeButton(root);
        if (likeButton == null) return null;
        // If the button itself exposes a liked-state description, use it.
        // nodeTextSelf also includes contentDescription, but keep the explicit
        // description read here because that is where TikTok exposes the state
        // on the user's device.
        String own = normalize(nodeTextSelf(likeButton));
        String desc = likeButton.getContentDescription() == null
                ? ""
                : normalize(likeButton.getContentDescription().toString());
        if (isLikedState(own) || isLikedState(desc)) return likeButton;
        Rect target = new Rect();
        likeButton.getBoundsInScreen(target);
        return findVisibleLikeStateNear(root, target);
    }

    private AccessibilityNodeInfo findTikTokFollowStateWithButton(AccessibilityNodeInfo root) {
        // Backward-compatible wrapper used by older call sites. For the current
        // TikTok UI, successful follow is verified by "Tindakan lainnya".
        return findTikTokFollowVerifiedState(root);
    }

    /**
     * Successful FOLLOW indicator for the TikTok UI shown by the user.
     * Before following the profile action row contains "Ikuti". After following
     * it changes to "Pesan" + "Tindakan lainnya". The latter is our primary
     * verification signal.
     */
    private AccessibilityNodeInfo findTikTokFollowVerifiedState(AccessibilityNodeInfo root) {
        if (root == null) return null;

        // Primary success signal: TikTok shows "Tindakan lainnya" in the
        // profile action row after a successful follow.
        if (isVisibleTikTokMoreActions(root)) return root;

        // Secondary signal: the SAME profile action row changes to "Mengikuti".
        // Never accept a global "Mengikuti" navigation item.
        if (isTikTokFollowingControl(root)) return root;

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTikTokFollowVerifiedState(root.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private boolean isVisibleTikTokMoreActions(AccessibilityNodeInfo node) {
        if (node == null || !isVisibleNode(node) || !node.isEnabled()) return false;
        String label = normalize(nodeTextSelf(node));
        if (!"tindakan lainnya".equals(label) && !"more actions".equals(label)) return false;

        Rect r = nodeBounds(node);
        if (!isValidScreenBounds(r)) return false;

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int h = dm.heightPixels;
        int w = dm.widthPixels;

        // Profile action row only. Recommendation cards are lower; top
        // navigation is higher. This also matches the user's screenshots.
        return r.centerY() >= h * 0.17f
                && r.centerY() <= h * 0.50f
                && r.centerX() >= w * 0.20f
                && r.centerX() <= w * 0.95f;
    }

    private boolean isTikTokFollowingControl(AccessibilityNodeInfo node) {
        if (node == null || !node.isEnabled()) return false;
        String label = normalize(nodeTextSelf(node));
        if (!isStrictFollowingState(label)) return false;

        Rect r = nodeBounds(node);
        if (!isValidScreenBounds(r)) return false;

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int h = dm.heightPixels;
        int w = dm.widthPixels;

        // The profile action row is directly below the profile header.
        // The unrelated TikTok "Mengikuti" navigation control is outside this
        // region, while the profile button is inside it.
        if (r.centerY() < h * 0.17f || r.centerY() > h * 0.50f) return false;
        if (r.centerX() < w * 0.45f || r.centerX() > w * 0.95f) return false;
        if (r.width() < w * 0.10f || r.width() > w * 0.92f) return false;

        String cls = node.getClassName() == null ? "" : node.getClassName().toString();
        return node.isClickable()
                || "android.widget.Button".equals(cls)
                || cls.endsWith("Button")
                || cls.contains("Button")
                || isVisibleNode(node);
    }

    private AccessibilityNodeInfo findTikTokExistingLikeState(AccessibilityNodeInfo root) {
        if (root == null) return null;
        if (isVisibleNode(root) && isLikedState(normalize(nodeTextSelf(root)))) {
            return root;
        }
        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTikTokExistingLikeState(root.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    /**
     * Search only the profile/action area for an existing Following state.
     * The top TikTok navigation has an unrelated "Mengikuti" item, so a global
     * text search is explicitly forbidden here.
     */
    private AccessibilityNodeInfo findTikTokExistingFollowState(AccessibilityNodeInfo root) {
        if (root == null) return null;
        if (isTikTokFollowingControl(root)) return root;
        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTikTokExistingFollowState(root.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    /**
     * TikTok's Accessibility tree on some builds exposes the heart control as a
     * clickable Button whose text is only the current like count (for example
     * "21" / "22"). The visible label is therefore NOT "Like". Prefer that
     * exact right-rail count button before any spatial fallback. This prevents
     * the generic fallback from landing on the three-dot/report control.
     */
    private AccessibilityNodeInfo findTikTokLikeCountButton(AccessibilityNodeInfo root) {
        if (root == null) return null;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();

        // TikTok on the affected device exposes the Like count as a numeric
        // text node. The safe way to resolve the heart is to use that exact
        // node and walk ONLY its own Accessibility parents. Do not scan nearby
        // clickable nodes: that was the bug that selected the profile avatar.
        java.util.ArrayList<AccessibilityNodeInfo> candidates = new java.util.ArrayList<>();
        collectTikTokLikeCandidates(root, candidates);

        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : candidates) {
            String t = normalize(nodeTextSelf(n));
            if (!isNumericLikeCount(t)) continue;

            Rect r = nodeBounds(n);
            if (r.centerX() < dm.widthPixels * 0.60f
                    || r.centerY() < dm.heightPixels * 0.30f
                    || r.centerY() > dm.heightPixels * 0.92f) continue;

            AccessibilityNodeInfo control = resolveLikeClickableNode(n);
            if (control == null) continue;

            Rect cr = nodeBounds(control);
            // The Like control must be directly associated with this count.
            // Reject large/profile-sized containers and anything below the count.
            if (cr.centerX() < dm.widthPixels * 0.60f) continue;
            if (cr.width() > dm.widthPixels * 0.30f || cr.height() > dm.heightPixels * 0.18f) continue;
            if (cr.centerY() > r.centerY() + 40) continue;
            if (r.centerY() - cr.centerY() > Math.max(220, (int)(dm.heightPixels * 0.16f))) continue;

            // Prefer a control whose bounds actually contain/overlap the count
            // node; otherwise prefer the nearest ancestor with the smallest area.
            boolean contains = cr.contains(r.centerX(), r.centerY()) || Rect.intersects(cr, r);
            int score = (contains ? 0 : 100000)
                    + Math.abs(cr.centerX() - r.centerX())
                    + Math.abs(cr.centerY() - r.centerY()) * 4
                    + (cr.width() * cr.height()) / 100;
            if (score < bestScore) {
                best = control;
                bestScore = score;
            }
        }

        if (best != null) {
            MainActivity.log("LIKE Accessibility exact heart target ditemukan");
        }
        return best;
    }

    private void collectTikTokLikeCountButtons(AccessibilityNodeInfo node, java.util.List<AccessibilityNodeInfo> out) {
        collectTikTokLikeCandidates(node, out);
    }

    private void collectTikTokLikeCandidates(AccessibilityNodeInfo node, java.util.List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (isVisibleNode(node) && node.isEnabled()) {
            String t = normalize(nodeTextSelf(node));
            Rect r = nodeBounds(node);
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            boolean numeric = isNumericLikeCount(t);
            boolean whiteHeart = isWhiteLikeIcon(t);
            boolean rightSide = r.centerX() >= dm.widthPixels * 0.60f;
            boolean belowTopBar = r.centerY() >= dm.heightPixels * 0.15f;
            boolean aboveBottom = r.centerY() <= dm.heightPixels * 0.92f;
            boolean usable = r.width() >= 8 && r.height() >= 8;
            boolean compact = r.width() <= dm.widthPixels * 0.30f
                    && r.height() <= dm.heightPixels * 0.18f;

            // TikTok versions differ: the Like count may be exposed as a
            // clickable Button, a non-clickable text node inside the control,
            // or contentDescription/stateDescription. Do NOT require the
            // numeric node itself to be a Button/clickable. The resolver below
            // maps it to the nearest exact clickable control.
            if (usable && compact && rightSide && belowTopBar && aboveBottom
                    && (numeric || whiteHeart)) {
                out.add(node);
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectTikTokLikeCandidates(node.getChild(i), out);
        }
    }

    private AccessibilityNodeInfo resolveLikeClickableNode(AccessibilityNodeInfo node) {
        if (node == null) return null;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        Rect target = nodeBounds(node);

        // Prefer the node itself when it is already the exact control.
        if (node.isVisibleToUser() && node.isEnabled() && node.isClickable()
                && target.centerX() >= dm.widthPixels * 0.60f) {
            return node;
        }

        // Some TikTok builds expose the count as a text/description child of
        // the actual clickable heart container. Walk only a few parents and
        // accept one whose bounds tightly contain/overlap the count node and
        // remain on the Like action rail. This is NOT a generic parent climb.
        AccessibilityNodeInfo parent = node.getParent();
        for (int i = 0; i < 3 && parent != null; i++) {
            if (parent.isVisibleToUser() && parent.isEnabled() && parent.isClickable()) {
                Rect r = nodeBounds(parent);
                boolean rail = r.centerX() >= dm.widthPixels * 0.60f;
                boolean sizeSafe = r.width() <= dm.widthPixels * 0.30f
                        && r.height() <= dm.heightPixels * 0.18f;
                boolean containsCenter = r.contains(target.centerX(), target.centerY())
                        || Rect.intersects(r, target);
                if (rail && sizeSafe && containsCenter) return parent;
            }
            parent = parent.getParent();
        }
        return null;
    }

    private boolean isNumericLikeCount(String text) {
        if (text == null) return false;
        return normalize(text).matches("[0-9]{1,9}(?:[.,][0-9]+)?[kKmMbB]?");
    }

    private boolean isWhiteLikeIcon(String text) {
        if (text == null) return false;
        String t = normalize(text);
        String whiteHeart = new String(Character.toChars(0x1F90D));
        return t.equals(whiteHeart) || t.equals("♡") || t.equals("white heart")
                || t.equals("white heart suit") || t.contains(whiteHeart);
    }

    private boolean isRedLikeIcon(String text) {
        if (text == null) return false;
        String t = normalize(text);
        return t.equals("❤️") || t.equals("❤") || t.equals("♥")
                || t.equals("red heart") || t.equals("red heart suit")
                || t.contains("❤️") || t.contains("red heart");
    }

    /**
     * TikTok on the target device exposes the Like control as an
     * android.widget.Button whose TEXT is empty. The useful label is in
     * contentDescription, for example:
     *
     *   "Sukai video. 21 suka"
     *
     * Therefore do not require an exact text match. Match the semantic Like
     * description while requiring a visible, enabled, clickable Button.
     * This deliberately avoids fixed coordinates, Like-count selection and
     * rail-order heuristics.
     */
    private AccessibilityNodeInfo findTikTokLikeButton(AccessibilityNodeInfo root) {
        if (root == null) return null;

        if (isTikTokLikeControl(root)) {
            return root;
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTikTokLikeButton(root.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private boolean clickByBounds(AccessibilityNodeInfo node) {
        if (node == null) return false;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        return r.width() > 0 && r.height() > 0 && tapScreen(r.centerX(), r.centerY());
    }

    private boolean clickExactTikTokLikeButton(AccessibilityNodeInfo node) {
        if (!isTikTokLikeControl(node)) return false;

        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 5 && n != null; i++) {
            if (isVisibleNode(n) && n.isEnabled() && n.isClickable()) {
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK) || clickByBounds(n);
            }
            n = n.getParent();
        }
        return clickByBounds(node);
    }

    private boolean isExactLikeText(AccessibilityNodeInfo node) {
        // Kept as a compatibility helper for existing call sites.
        return isTikTokLikeControl(node);
    }

    private boolean isTikTokLikeControl(AccessibilityNodeInfo node) {
        if (node == null || !isVisibleNode(node) || !node.isEnabled() || !node.isClickable()) {
            return false;
        }

        String className = node.getClassName() == null
                ? ""
                : node.getClassName().toString();

        // TikTok's exposed Like control on the supplied device is a Button.
        // Accept subclasses/other clickable controls as a safe compatibility
        // fallback, but reject ordinary non-clickable text/container nodes.
        boolean buttonLike = "android.widget.Button".equals(className)
                || className.endsWith("Button")
                || className.contains("Button");
        if (!buttonLike) return false;

        String raw = node.getContentDescription() == null
                ? ""
                : node.getContentDescription().toString();
        String desc = normalize(raw);

        // Unliked state seen on the user's device:
        // "Sukai video. 21 suka" / "Sukai video. 73,6 rb suka"
        // English builds commonly expose "Like video ...".
        if (desc.startsWith("sukai video")
                || desc.startsWith("suka video")
                || desc.startsWith("like video")
                || desc.startsWith("like this video")) {
            return true;
        }

        // Also recognize the same Like button after it has already been liked.
        // This is necessary so a manual Like can be verified without clicking
        // it again.
        return desc.contains("batal suka")
                || desc.contains("hapus suka")
                || desc.contains("tidak suka")
                || desc.contains("sudah menyukai")
                || desc.contains("already liked")
                || desc.contains("unlike");
    }

    private void verifyLike() {
        if (!running || !likeTaskActive || state != State.WAITING_LIKE) return;
        mainFlowState = MainFlowState.VERIFY_ACTION;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isTikTok(getCurrentPackage(root))) {
            schedule(500L, this::verifyLike);
            return;
        }

        if (hasVerifiedLikeState(root)) {
            AppState.setTaskState(AppState.TaskState.VERIFYING);
            MainActivity.log("LIKE BERHASIL — status TikTok terverifikasi; cek task Mutualan setelah kembali");
            returnToMutualan();
            return;
        }

        long elapsed = System.currentTimeMillis() - flowStartedAt;
        if (elapsed < LIKE_VERIFY_TIMEOUT) {
            schedule(500L, this::verifyLike);
            return;
        }

        // Pending recovery uses the global 5-attempt retry rule. One pending attempt = one complete
        // TikTok action + verification cycle; do not nest a second retry counter inside it.
        if (pendingActionActive) {
            pendingTikTokVerificationFailed("LIKE");
            return;
        }

        if (likeRetries < MAX_ACTION_RETRIES) {
            likeRetries++;
            likeClicked = false;
            clickedLikeBounds = null;
            flowStartedAt = System.currentTimeMillis();
            AppState.setTaskState(AppState.TaskState.RETRY);
            MainActivity.log("LIKE belum terverifikasi — percobaan " +
                    likeRetries + "/" + MAX_ACTION_RETRIES);
            schedule(ACTION_RETRY_DELAY, () -> {
                if (running && state == State.WAITING_LIKE) {
                    handleTikTok(getRootInActiveWindow());
                }
            });
            return;
        }

        finishActionAfterFiveRetries("LIKE");
    }

    private boolean hasVerifiedLikeState(AccessibilityNodeInfo root) {
        if (clickedLikeBounds == null) return false;
        if (findVisibleLikeStateNear(root, clickedLikeBounds) != null) return true;
        return hasSelectedStateNear(root, clickedLikeBounds, true);
    }

    private AccessibilityNodeInfo findTikTokRedLikeIcon(AccessibilityNodeInfo root) {
        if (root == null) return null;
        if (isVisibleNode(root) && root.isEnabled()) {
            String t = normalize(nodeTextSelf(root));
            if (isRedLikeIcon(t)) {
                Rect r = nodeBounds(root);
                android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
                if (r.centerX() >= dm.widthPixels * 0.60f
                        && r.width() >= 10 && r.height() >= 8) {
                    return root;
                }
            }
        }
        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTikTokRedLikeIcon(root.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private boolean hasSelectedStateNear(AccessibilityNodeInfo root, Rect target, boolean like) {
        if (root == null || target == null) return false;
        if (isVisibleNode(root)) {
            Rect r = new Rect();
            root.getBoundsInScreen(r);
            if (nearActionState(target, r) && (root.isSelected() || root.isChecked())) {
                return true;
            }
            String desc = normalize(nodeTextSelf(root));
            if (nearActionState(target, r)) {
                if (like && (desc.contains("liked") || desc.contains("disukai") || desc.contains("tidak suka"))) return true;
                if (!like && (desc.contains("following") || desc.contains("mengikuti"))) return true;
            }
        }
        for (int i = 0; i < root.getChildCount(); i++) {
            if (hasSelectedStateNear(root.getChild(i), target, like)) return true;
        }
        return false;
    }

    private boolean nearActionState(Rect a, Rect b) {
        if (a == null || b == null) return false;
        int dx = Math.abs(a.centerX() - b.centerX());
        int dy = Math.abs(a.centerY() - b.centerY());
        return dx <= Math.max(220, a.width() * 3) && dy <= Math.max(220, a.height() * 4);
    }

    /**
     * TikTok may expose the liked state on the clicked button, its content
     * description, or a nearby child. Only accept a liked-state node that is
     * spatially close to the exact button we clicked.
     */
    private AccessibilityNodeInfo findVisibleLikeStateNear(AccessibilityNodeInfo root, Rect target) {
        if (root == null || target == null) return null;

        if (isVisibleNode(root)) {
            String text = normalize(nodeTextSelf(root));
            if (isLikedState(text)) {
                Rect r = new Rect();
                root.getBoundsInScreen(r);
                if (nearLikeState(target, r)) return root;
            }
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findVisibleLikeStateNear(root.getChild(i), target);
            if (found != null) return found;
        }
        return null;
    }

    private boolean isLikedState(String text) {
        String t = normalize(text);
        if (t.isEmpty()) return false;

        // TikTok may put the state and the Like count in the same
        // contentDescription, e.g. "Batal suka video. 21 suka".
        return t.contains("tidak suka")
                || t.contains("batal suka")
                || t.contains("hapus suka")
                || t.contains("disukai")
                || t.contains("sudah menyukai")
                || t.contains("liked")
                || t.contains("already liked")
                || t.contains("remove like")
                || t.contains("unlike");
    }

    private boolean nearLikeState(Rect button, Rect stateRect) {
        if (button == null || stateRect == null) return false;
        int dx = Math.abs(button.centerX() - stateRect.centerX());
        int dy = Math.abs(button.centerY() - stateRect.centerY());
        // Like state is normally the icon itself or its content-description node.
        return dx <= Math.max(120, button.width() * 2)
                && dy <= Math.max(120, button.height() * 3);
    }

    private void finishActionAfterFiveRetries(String action) {
        // Five failed action/verification cycles are a generic failure. Do not
        // enter SAFE MODE and do not reset the retry counter. Return to Mutualan
        // and remove the same task when its delete control is available.
        MainActivity.log("[DEL] " + action + " gagal 5x → task dianggap gagal permanen");
        final String failedKey = activeTaskKey;
        abortCurrentTaskToMutualan();
        schedule(1800L, () -> deleteFailedMainTask(failedKey));
    }

    private void deleteFailedMainTask(String failedKey) {
        if (!running || failedKey == null || failedKey.isEmpty()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isMutualanPackage(getCurrentPackage(root))) return;
        List<Task> tasks = com.manzxdigital.autoklikpro.engine.TaskScanner.scan(root);
        for (Task t : tasks) {
            if (failedKey.equals(t.key)) {
                if (t.deleteNode != null && clickNodeOnce(t.deleteNode)) {
                    MainActivity.log("[DEL] " + t.username + " → gagal 5x → HAPUS task");
                    taskLocked = true;
                    schedule(1200L, this::unlockAndScan);
                } else {
                    MainActivity.log("[WARN] " + t.username + " → gagal 5x tetapi tombol HAPUS tidak ditemukan");
                    unlockAndScan();
                }
                return;
            }
        }
        unlockAndScan();
    }

    private void verifyFollow() {
        if (!running || state != State.WAITING_FOLLOW) return;
        mainFlowState = MainFlowState.VERIFY_ACTION;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isTikTok(getCurrentPackage(root))) {
            schedule(500L, this::verifyFollow);
            return;
        }

        if (hasVerifiedFollowState(root)) {
            AppState.setTaskState(AppState.TaskState.VERIFYING);
            MainActivity.log("FOLLOW BERHASIL — status TikTok terverifikasi; cek task Mutualan setelah kembali");
            returnToMutualan();
            return;
        }

        long elapsed = System.currentTimeMillis() - flowStartedAt;
        if (elapsed < FOLLOW_VERIFY_TIMEOUT) {
            schedule(500L, this::verifyFollow);
            return;
        }

        // Pending recovery uses the global 5-attempt retry rule. One pending attempt = one complete
        // TikTok action + verification cycle; do not nest a second retry counter inside it.
        if (pendingActionActive) {
            pendingTikTokVerificationFailed("FOLLOW");
            return;
        }

        if (followRetries < MAX_ACTION_RETRIES) {
            followRetries++;
            followClicked = false;
            clickedFollowBounds = null;
            flowStartedAt = System.currentTimeMillis();
            AppState.setTaskState(AppState.TaskState.RETRY);
            MainActivity.log("FOLLOW belum terverifikasi — percobaan " +
                    followRetries + "/" + MAX_ACTION_RETRIES);
            schedule(ACTION_RETRY_DELAY, () -> {
                if (running && state == State.WAITING_FOLLOW) {
                    handleTikTok(getRootInActiveWindow());
                }
            });
            return;
        }

        finishActionAfterFiveRetries("FOLLOW");
    }

    private boolean hasVerifiedFollowState(AccessibilityNodeInfo root) {
        // On the user's TikTok build, a successful follow is represented by the
        // profile action row changing to the exact visible label "Tindakan lainnya".
        // This is stronger than looking for a generic "Mengikuti" node because
        // TikTok also exposes unrelated "Mengikuti" navigation labels.
        return findTikTokFollowVerifiedState(root) != null;
    }

    private AccessibilityNodeInfo findVisibleFollowStateNear(AccessibilityNodeInfo root, Rect target) {
        if (root == null || target == null) return null;

        if (isVisibleNode(root)) {
            String text = normalize(nodeTextSelf(root));
            if (isStrictFollowingState(text)) {
                Rect r = new Rect();
                root.getBoundsInScreen(r);
                if (nearFollowState(target, r)) return root;
            }
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findVisibleFollowStateNear(root.getChild(i), target);
            if (found != null) return found;
        }
        return null;
    }

    private boolean nearFollowState(Rect button, Rect stateRect) {
        if (button == null || stateRect == null) return false;
        int dx = Math.abs(button.centerX() - stateRect.centerX());
        int dy = Math.abs(button.centerY() - stateRect.centerY());
        return dx <= Math.max(180, button.width() * 2)
                && dy <= Math.max(160, button.height() * 3);
    }

    private boolean near(Rect a, Rect b) {
        if (a == null || b == null) return false;
        int dx = Math.abs(a.centerX() - b.centerX());
        int dy = Math.abs(a.centerY() - b.centerY());
        int toleranceX = Math.max(180, a.width() * 3);
        int toleranceY = Math.max(180, a.height() * 3);
        return dx <= toleranceX && dy <= toleranceY;
    }

    /** Start the special recovery flow for a permanent pending error. */
    public void beginPendingTask(Task task) {
        if (!running || task == null || pendingActionActive || taskLocked) return;
        if (task.type != Task.Type.FOLLOW && task.type != Task.Type.LIKE) return;

        pendingActionActive = true;
        pendingFlowState = PendingFlowState.TASK_FOUND;
        pendingActionTask = task;
        pendingActionAttempts = 0;
        pendingActionStartedAt = System.currentTimeMillis();
        pendingActionToken = ++stateToken;
        pendingVerificationTapDone = false;
        taskLocked = true;
        safeMode = false;
        safeReason = "";
        activeTaskKey = task.key;
        activeTaskUsername = task.username;
        activeTaskLike = task.type == Task.Type.LIKE;
        likeTaskActive = activeTaskLike;
        likeClicked = false;
        followClicked = false;
        clickedLikeBounds = null;
        clickedFollowBounds = null;
        likeRetries = 0;
        followRetries = 0;
        AppState.setActiveTaskKey(task.key);
        AppState.setRetryAttempt(0);
        AppState.setTaskState(AppState.TaskState.EXECUTING);
        MainActivity.log("PENDING " + task.type.name() + " " + task.username +
                " → jangan hapus; buka task untuk verifikasi ulang");
        clickPendingTaskRow(task, pendingActionToken);
    }

    private void clickPendingTaskRow(Task task, long token) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isMutualanPackage(getCurrentPackage(root))) {
            pendingActionFailedToStart("Mutualan tidak aktif");
            return;
        }
        AccessibilityNodeInfo target = task.container;
        boolean clicked = clickNodeOnce(target);
        if (!clicked) {
            AccessibilityNodeInfo title = findTextNode(root, task.title);
            if (title != null) clicked = clickNodeOnce(title);
        }
        if (!clicked) {
            pendingActionFailedToStart("task tidak bisa dibuka");
            return;
        }
        pendingFlowState = PendingFlowState.PROCESSING;
        state = State.PENDING_OPENING;
        pendingActionStartedAt = System.currentTimeMillis();
        MainActivity.log("PENDING → task dibuka 1X → cari tombol Buka TikTok");
        schedule(350L, () -> waitForPendingTikTokButton(token));
    }

    private void waitForPendingTikTokButton(long token) {
        if (!running || !pendingActionActive || token != pendingActionToken) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isMutualanPackage(getCurrentPackage(root))) {
            if (isTikTok(getCurrentPackage(root))) {
                startPendingTikTokStage(token);
                return;
            }
            if (System.currentTimeMillis() - pendingActionStartedAt > 12000L) {
                pendingActionFailedToStart("detail task tidak terbuka");
                return;
            }
            schedule(350L, () -> waitForPendingTikTokButton(token));
            return;
        }

        AccessibilityNodeInfo button = findTextNode(root, "buka tiktok");
        if (button != null && clickNodeOnce(button)) {
            MainActivity.log("PENDING → Buka TikTok diklik");
            startPendingTikTokStage(token);
            return;
        }
        if (System.currentTimeMillis() - pendingActionStartedAt > 12000L) {
            pendingActionFailedToStart("tombol Buka TikTok tidak ditemukan");
            return;
        }
        schedule(350L, () -> waitForPendingTikTokButton(token));
    }

    private void startPendingTikTokStage(long token) {
        if (!running || !pendingActionActive || token != pendingActionToken) return;
        pendingFlowState = PendingFlowState.PROCESSING;
        state = State.OPENING_TIKTOK;
        mainFlowState = MainFlowState.OPEN_TIKTOK;
        flowStartedAt = System.currentTimeMillis();
        taskOpenStartedAt = flowStartedAt;
        likeTaskActive = pendingActionTask != null && pendingActionTask.type == Task.Type.LIKE;
        activeTaskLike = likeTaskActive;
        activeTaskUsername = pendingActionTask == null ? "" : pendingActionTask.username;
        likeClicked = false;
        followClicked = false;
        clickedLikeBounds = null;
        clickedFollowBounds = null;
        likeRetries = 0;
        followRetries = 0;
        schedule(300L, () -> waitForTikTok(token));
    }

    private void pendingTikTokVerificationFailed(String action) {
        if (!pendingActionActive) return;
        MainActivity.log("PENDING " + action + " belum terverifikasi di TikTok");
        pendingVerificationTapDone = false;
        // One pending attempt = one complete TikTok verification cycle. Do not
        // nest another retry counter inside the pending 5-attempt rule.
        returnPendingToMutualanByBack();
    }

    private void returnPendingToMutualanByBack() {
        if (!running || !pendingActionActive) return;
        pendingFlowState = PendingFlowState.RETURN_BACK;
        state = State.RETURNING;
        final long token = ++stateToken;
        pendingActionToken = token;
        pendingVerificationTapDone = false;
        flowStartedAt = System.currentTimeMillis();
        // Do NOT use a gesture/swipe. TikTok was opened from Mutualan, so a
        // normal Android BACK returns directly to the already-open Mutualan
        // pending page/activity.
        boolean dispatched = performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
        MainActivity.log(dispatched
                ? "PENDING → BACK → kembali ke halaman Tugas Tertunda"
                : "PENDING → BACK gagal → buka Mutualan tanpa swipe");
        if (!dispatched) launchMutualanPackageForPending();
        schedule(500L, () -> waitForPendingMutualanReturn(token));
    }


    private void waitForPendingMutualanReturn(long token) {
        if (!running || !pendingActionActive || token != pendingActionToken || state != State.RETURNING) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        String pkg = getCurrentPackage(root);
        if (isMutualanPackage(pkg)) {
            pendingFlowState = PendingFlowState.VERIFYING;
            state = State.PENDING_VERIFYING;
            pendingActionStartedAt = System.currentTimeMillis();
            schedule(650L, () -> verifyPendingResultOnMutualan(token));
            return;
        }
        if (System.currentTimeMillis() - flowStartedAt > RETURN_TIMEOUT) {
            MainActivity.log("PENDING → Mutualan belum kembali, fallback launch tanpa CLEAR_TASK");
            if (launchMutualanPackageForPending()) {
                flowStartedAt = System.currentTimeMillis();
                schedule(700L, () -> waitForPendingMutualanReturn(token));
                return;
            }
        }
        schedule(400L, () -> waitForPendingMutualanReturn(token));
    }

    private boolean launchMutualanPackageForPending() {
        try {
            Intent intent = new Intent();
            intent.setClassName(MUTUALAN_PACKAGE, "com.mutualan.MainActivity");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            return true;
        } catch (Throwable ignored) { return false; }
    }

    private void handlePendingMutualanScreen(AccessibilityNodeInfo root) {
        if (!pendingActionActive || root == null) return;
        if (state == State.RETURNING) return;
        if (state == State.PENDING_OPENING) {
            schedule(100L, () -> waitForPendingTikTokButton(pendingActionToken));
            return;
        }
        if (state == State.PENDING_VERIFYING) {
            verifyPendingResultOnMutualan(pendingActionToken);
        }
    }

    private void verifyPendingResultOnMutualan(long token) {
        if (!running || !pendingActionActive || token != pendingActionToken || state != State.PENDING_VERIFYING) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !isMutualanPackage(getCurrentPackage(root))) {
            schedule(450L, () -> verifyPendingResultOnMutualan(token));
            return;
        }

        // User-specified re-verification: tap the current pending page once after
        // returning from TikTok. Do NOT repeat this on every Accessibility event.
        if (!pendingVerificationTapDone) {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            int x = dm.widthPixels / 2;
            int y = (int)(dm.heightPixels * 0.58f);
            pendingVerificationTapDone = performTap(x, y);
            MainActivity.log("PENDING → tap halaman untuk verifikasi ulang" +
                    (pendingVerificationTapDone ? " (1X)" : " gagal"));
            schedule(1000L, () -> verifyPendingResultOnMutualan(token));
            return;
        }

        // We are already in the dedicated pending cycle. Do not require the
        // generic page detector here; WebView updates can temporarily hide the
        // words 'verifikasi'/'gagal' while the task row is refreshing.

        List<Task> tasks = com.manzxdigital.autoklikpro.engine.TaskScanner.scan(root);
        Task same = null;
        for (Task t : tasks) {
            if (pendingActionTask != null && pendingActionTask.key.equals(t.key)) { same = t; break; }
        }
        if (same == null) {
            MainActivity.log("[OK] PENDING " + pendingActionTask.username + " → verifikasi Mutualan berhasil, task hilang");
            AppState.incSuccess();
            finishPendingActionAndContinue();
            return;
        }

        pendingActionAttempts++;
        AppState.setRetryAttempt(pendingActionAttempts);
        MainActivity.log("[RETRY] PENDING " + pendingActionTask.username + " → masih gagal, percobaan " + pendingActionAttempts + "/5");
        if (pendingActionAttempts >= 5) {
            MainActivity.log("[DEL] PENDING " + pendingActionTask.username + " → 5x tetap gagal → HAPUS");
            pendingRetryEngine.deleteFromService(same);
            return;
        }

        // Refresh the current pending list before the next attempt. The next
        // attempt again clicks the task row -> Buka TikTok -> action -> verify.
        pendingActionStartedAt = System.currentTimeMillis();
        clickPendingTaskRow(same, ++pendingActionToken);
    }

    private void pendingActionFailedToStart(String reason) {
        MainActivity.log("[WARN] PENDING → " + reason + " → tidak menghapus task");
        pendingActionAttempts++;
        if (pendingActionAttempts >= 5 && pendingActionTask != null && pendingRetryEngine != null) {
            MainActivity.log("[DEL] PENDING " + pendingActionTask.username + " → 5x gagal membuka/verifikasi → HAPUS");
            pendingRetryEngine.deleteFromService(pendingActionTask);
            return;
        }
        returnPendingToMutualanByBack();
    }

    private void finishPendingActionAndContinue() {
        if (!pendingActionActive) return;
        Task finished = pendingActionTask;
        clearPendingAction();
        pendingFlowState = PendingFlowState.NONE;
        taskLocked = false;
        state = State.SCANNING;
        AppState.setActiveTaskKey("");
        AppState.setRetryAttempt(0);
        AppState.setTaskState(AppState.TaskState.SUCCESS);
        if (pendingRetryEngine != null) pendingRetryEngine.resumeAfterExternalAction();
        schedule(350L, () -> {
            if (running && pendingRetryEngine != null) pendingRetryEngine.scanNow();
            else if (running) scanCurrentTask();
        });
    }

    private void clearPendingAction() {
        pendingActionActive = false;
        pendingActionTask = null;
        pendingActionAttempts = 0;
        pendingActionStartedAt = 0L;
        pendingActionToken = 0L;
        pendingVerificationTapDone = false;
    }

    private boolean containsText(AccessibilityNodeInfo root, String wanted) {
        if (root == null) return false;
        String w = normalize(wanted);
        if (normalize(nodeTextSelf(root)).contains(w)) return true;
        for (int i = 0; i < root.getChildCount(); i++) if (containsText(root.getChild(i), wanted)) return true;
        return false;
    }

    private void returnToMutualan() {
        if (!running || !isTikTok(getCurrentPackage())) return;

        if (pendingActionActive) {
            returnPendingToMutualanByBack();
            return;
        }

        state = State.RETURNING;
        mainFlowState = MainFlowState.RETURN_MUTUALAN;
        final long token = ++stateToken;
        flowStartedAt = System.currentTimeMillis();
        returnAttempts = 0;

        MainActivity.log((likeTaskActive ? "LIKE" : "FOLLOW") +
                " selesai → kembali ke Mutualan");

        if (launchMutualanPackage()) {
            MainActivity.log("Mutualan → LAUNCH langsung");
        } else {
            MainActivity.log("Launch Mutualan gagal → retry langsung");
            schedule(800L, () -> {
                if (running && token == stateToken && state == State.RETURNING) {
                    launchMutualanPackage();
                }
            });
        }

        schedule(getTransitionDelayMs(), () -> waitForMutualanReturn(token));
    }

    private void waitForMutualanReturn(long token) {
        if (!running || token != stateToken || state != State.RETURNING) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        String pkg = getCurrentPackage(root);

        // Package match is enough to know we reached the Mutualan app. We do NOT
        // require a task label here because the task list can be empty/loading.
        if (isMutualanPackage(pkg)) {
            finishReturn(root);
            return;
        }

        long elapsed = System.currentTimeMillis() - flowStartedAt;
        if (elapsed >= RETURN_TIMEOUT) {
            if (returnAttempts < 2) {
                returnAttempts++;
                MainActivity.log("Mutualan belum aktif → recovery " +
                        returnAttempts + "/2");

                launchMutualanPackage();
                flowStartedAt = System.currentTimeMillis();
                schedule(900L, () -> waitForMutualanReturn(token));
                return;
            }

            MainActivity.log("MODE AMAN — gagal kembali ke Mutualan setelah recovery");
            state = State.IDLE;
            taskLocked = false;
            running = false;
            cancelScheduledWork();
            updateOverlay();
            MainActivity a = MainActivity.getInstance();
            if (a != null) a.refreshUi();
            return;
        }

        schedule(getTransitionDelayMs(), () -> waitForMutualanReturn(token));
    }

    private void finishReturn(AccessibilityNodeInfo root) {
        if (!running || !isMutualanPackage(getCurrentPackage(root))) return;

        if (safeMode) {
            state = State.IDLE;
            taskLocked = false;
            running = false;
            cancelScheduledWork();
            MainActivity.log("MODE AMAN — Mutualan sudah aktif");
            MainActivity.log("Automation dijeda untuk mencegah task gagal diulang");
            MainActivity.log("RESET AWAL → PLAY untuk memulai lagi");
            updateOverlay();
            MainActivity a = MainActivity.getInstance();
            if (a != null) a.refreshUi();
            return;
        }

        state = State.SCANNING;
        mainFlowState = MainFlowState.WAIT_MAIN_TASK_CHANGE;
        taskLocked = true;
        followClicked = false;
        clickedFollowBounds = null;
        likeClicked = false;
        clickedLikeBounds = null;
        likeTaskActive = false;
        returnAttempts = 0;
        taskOpenStartedAt = 0L;
        likeRetries = 0;
        followRetries = 0;

        final long token = ++stateToken;
        MainActivity.log("Mutualan aktif → tunggu daftar Task stabil");
        schedule(MUTUALAN_STABLE_DELAY, () -> waitForNextTaskAfterAction(token));
    }

    /**
     * Main Task and Tugas Tertunda are different Mutualan pages.
     * For the main Task page, do NOT retry the same task based on disappearance.
     * After returning from TikTok we wait until the task username changes, then
     * unlock and process the next task. If the task moved to Tugas Tertunda,
     * the separate PendingRetryEngine owns that page.
     */
    private void waitForNextTaskAfterAction(long token) {
        if (!running || token != stateToken || !isMutualanPackage(getCurrentPackage())) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            schedule(getTransitionDelayMs(), () -> waitForNextTaskAfterAction(token));
            return;
        }

        if (pendingRetryEngine != null && pendingRetryEngine.isPendingScreen(root)) {
            MainActivity.log("Task masuk Tugas Tertunda → diserahkan ke Pending Engine");
            AppState.setTaskState(AppState.TaskState.RETRY);
            AppState.setActiveTaskKey("");
            AppState.setRetryAttempt(0);
            activeTaskKey = "";
            activeTaskUsername = "";
            activeTaskFingerprint = "";
            activeTaskLike = false;
            taskLocked = false;
            state = State.SCANNING;
            pendingRetryEngine.onPendingEvent(root, MUTUALAN_PACKAGE);
            return;
        }

        AccessibilityNodeInfo current = findMainTaskNode(root);
        if (current == null) {
            schedule(getTransitionDelayMs(), () -> waitForNextTaskAfterAction(token));
            return;
        }

        String currentContext = spatialTaskContext(current, root);
        if (currentContext.isEmpty()) currentContext = taskContextText(current);
        String username = TaskParser.username(currentContext);
        String currentType = actionTypeForNode(current, currentContext);
        if (currentType.isEmpty()) currentType = actionTypeFromSpatialContext(current, root);
        String currentFingerprint = buildTaskFingerprint(current, currentContext, currentType);

        boolean usernameChanged = !activeTaskUsername.isEmpty() && !username.isEmpty()
                && !activeTaskUsername.equalsIgnoreCase(username);
        boolean fingerprintChanged = !activeTaskFingerprint.isEmpty()
                && !currentFingerprint.isEmpty()
                && !activeTaskFingerprint.equals(currentFingerprint);
        boolean keyChanged = !activeTaskKey.isEmpty() && !currentType.isEmpty()
                && !TaskParser.key(currentType + " " + currentContext).equals(activeTaskKey);

        if (usernameChanged || fingerprintChanged || keyChanged) {
            AppState.incSuccess();
            AppState.setTaskState(AppState.TaskState.SUCCESS);
            MainActivity.log("[OK] Task selesai → task berikutnya terdeteksi"
                    + (usernameChanged ? " (username berubah)" : " (card/fingerprint berubah)"));
            activeTaskKey = "";
            activeTaskUsername = "";
            activeTaskFingerprint = "";
            activeTaskLike = false;
            AppState.setActiveTaskKey("");
            AppState.setRetryAttempt(0);
            taskLocked = false;
            state = State.SCANNING;
            schedule(250L, this::scanCurrentTask);
            return;
        }

        MainActivity.log("Task masih sama → tunggu daftar Task berubah, TANPA klik ulang");
        schedule(700L, () -> waitForNextTaskAfterAction(token));
    }

    private String buildTaskFingerprint(AccessibilityNodeInfo node, String context, String type) {
        Rect b = nodeBounds(node);
        String user = TaskParser.username(context);
        String normalized = normalize(context);
        return (type == null ? "" : type) + "|" + user + "|" + b.top + "|" + b.bottom + "|" + normalized;
    }

    private AccessibilityNodeInfo findMainTaskNode(AccessibilityNodeInfo root) {
        return findVisibleMainTaskNode(root, "");
    }

    private AccessibilityNodeInfo findTaskByKey(AccessibilityNodeInfo root, String key) {
        if (root==null || key==null || key.isEmpty()) return null;
        String own=TaskParser.ownText(root);
        if (TaskParser.isTaskTitle(own) && key.equals(TaskParser.key(own))) return root;
        for(int i=0;i<root.getChildCount();i++) { AccessibilityNodeInfo f=findTaskByKey(root.getChild(i),key); if(f!=null)return f; }
        return null;
    }

    private int countTaskLabels(AccessibilityNodeInfo root) {
        return collectMainTaskCandidates(root).items.size();
    }

    private AccessibilityNodeInfo findTaskAction(AccessibilityNodeInfo node) {
        if (node == null) return null;

        // Flutter/WebView task labels are often exposed as NON-clickable text
        // nodes even though the visible task card itself is tappable. The old
        // implementation returned null in that case, so the task was locked and
        // then immediately unlocked without ever opening TikTok.
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 6 && n != null; i++) {
            if (isVisibleNode(n) && n.isEnabled() && n.isClickable()) return n;
            n = n.getParent();
        }

        // Keep the original matched text node as a final bounds-tap target.
        // clickNodeOnce() will perform ACTION_CLICK when possible and otherwise
        // dispatch a single gesture at its center.
        if (isVisibleNode(node) && node.isEnabled()) return node;

        return null;
    }

    private boolean clickNodeOnce(AccessibilityNodeInfo node) {
        if (!isVisibleNode(node) || !node.isEnabled()) return false;
        if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;

        Rect r = new Rect();
        node.getBoundsInScreen(r);
        return r.width() > 0 && r.height() > 0 && tapScreen(r.centerX(), r.centerY());
    }

    private boolean tapScreen(int x, int y) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.N) return false;
        if (x < 0 || y < 0) return false;

        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 90);
        return dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    /**
     * Performs Mutualan's pull-to-refresh gesture.
     * Direction is explicitly TOP -> BOTTOM; there is no refresh-button search.
     */
    private boolean pullToRefresh(AccessibilityNodeInfo root) {
        if (root == null || !isMutualanPackage(getCurrentPackage(root))) {
            return false;
        }
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.N) {
            return false;
        }

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenW = dm.widthPixels;
        int screenH = dm.heightPixels;

        // Start near the upper content area and drag downward.
        // Keep clear of the status bar while still being high enough to trigger
        // a standard SwipeRefreshLayout/WebView pull-to-refresh.
        int x = screenW / 2;
        int startY = Math.max(140, (int)(screenH * 0.16f));
        int endY = Math.min(screenH - 260, (int)(screenH * 0.55f));
        if (endY <= startY + 120) return false;

        Path p = new Path();
        p.moveTo(x, startY);
        p.lineTo(x, endY);

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 550);

        return dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                null,
                null
        );
    }

    /**
     * FOLLOW resolver for the TikTok profile page.
     *
     * TikTok exposes several "Ikuti" controls at once (recommendation cards,
     * profile action row, etc.). Do NOT rely on a fixed Y coordinate. Collect
     * all exact follow controls and choose the large profile action button.
     *
     * The user's TikTok tree can report the real profile Button with
     * isVisibleToUser=false, so visibility is deliberately not required here.
     */
    private AccessibilityNodeInfo findTikTokFollowButton(AccessibilityNodeInfo root) {
        if (root == null) return null;

        java.util.ArrayList<AccessibilityNodeInfo> labels = new java.util.ArrayList<>();
        collectTikTokFollowLabels(root, labels);

        AccessibilityNodeInfo best = null;
        long bestScore = Long.MIN_VALUE;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenW = dm.widthPixels;
        int screenH = dm.heightPixels;

        for (AccessibilityNodeInfo label : labels) {
            AccessibilityNodeInfo target = findBestFollowClickableAncestor(label, screenW, screenH);
            if (target == null) target = label;
            Rect r = nodeBounds(target);
            if (!isValidScreenBounds(r)) continue;

            long score = (long) r.width() * 1000L;
            if (r.width() >= screenW * 0.50f) score += 2_000_000L;
            if (r.width() >= screenW * 0.65f) score += 1_000_000L;
            if (r.centerY() < screenH * 0.55f) score += 500_000L;
            if (r.centerY() < screenH * 0.35f) score += 250_000L;
            if (target.isClickable()) score += 750_000L;

            if (score > bestScore) {
                bestScore = score;
                best = target;
            }
        }

        if (best != null) {
            Rect r = nodeBounds(best);
            MainActivity.log("FOLLOW → tombol IKUTI profil terdeteksi Accessibility ("
                    + r.width() + "x" + r.height() + ")");
        }
        return best;
    }

    private void collectTikTokFollowLabels(AccessibilityNodeInfo node,
                                           java.util.ArrayList<AccessibilityNodeInfo> out) {
        if (node == null) return;
        if (isTikTokFollowLabel(node)) out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) {
            collectTikTokFollowLabels(node.getChild(i), out);
        }
    }

    private AccessibilityNodeInfo findBestFollowClickableAncestor(AccessibilityNodeInfo node,
                                                                    int screenW, int screenH) {
        AccessibilityNodeInfo n = node;
        AccessibilityNodeInfo best = null;
        for (int i = 0; i < 8 && n != null; i++) {
            Rect r = nodeBounds(n);
            if (isValidScreenBounds(r) && n.isEnabled()) {
                boolean clickable = n.isClickable();
                boolean buttonClass = "android.widget.Button".equals(
                        n.getClassName() == null ? "" : n.getClassName().toString());
                if (clickable || buttonClass) {
                    if (r.width() >= screenW * 0.25f &&
                            r.centerY() < screenH * 0.65f) {
                        if (best == null || r.width() > nodeBounds(best).width()) {
                            best = n;
                        }
                    }
                }
            }
            n = n.getParent();
        }
        return best;
    }

    private boolean isTikTokFollowLabel(AccessibilityNodeInfo node) {
        if (node == null || !node.isEnabled()) return false;
        String text = normalize(node.getText() == null ? "" : node.getText().toString());
        String desc = node.getContentDescription() == null ? ""
                : normalize(node.getContentDescription().toString());
        return "ikuti".equals(text) || "follow".equals(text)
                || text.startsWith("ikuti ") || text.startsWith("follow ")
                || "ikuti".equals(desc) || "follow".equals(desc)
                || desc.startsWith("ikuti ") || desc.startsWith("follow ");
    }

    private boolean isTikTokFollowControl(AccessibilityNodeInfo node) {
        if (node == null || !node.isEnabled()) return false;
        return isTikTokFollowLabel(node);
    }

    private boolean clickExactTikTokButton(AccessibilityNodeInfo node) {
        if (node == null) return false;

        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 6 && n != null; i++) {
            Rect r = nodeBounds(n);
            if (isValidScreenBounds(r) && n.isEnabled() && n.isClickable()) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                if (clickByBounds(n)) return true;
            }
            n = n.getParent();
        }

        return clickByBounds(node);
    }

    private boolean isExactFollowText(AccessibilityNodeInfo node) {
        return isTikTokFollowControl(node);
    }

    private boolean isTargetFollowLabel(String label, String target) {
        if (label == null || target == null || target.isEmpty()) return false;
        String t = normalize(label);
        return t.equals("ikuti " + target)
                || t.equals("follow " + target)
                || t.equals("ikuti @" + target)
                || t.equals("follow @" + target);
    }

    private boolean isValidScreenBounds(Rect r) {
        if (r == null || r.width() <= 0 || r.height() <= 0) return false;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        return r.right > 0 && r.bottom > 0
                && r.left < dm.widthPixels
                && r.top < dm.heightPixels;
    }

    private boolean isStrictFollowingState(String text) {
        String t = normalize(text);
        return "mengikuti".equals(t) || "following".equals(t);
    }

    private AccessibilityNodeInfo findTaskAny(AccessibilityNodeInfo root, String word1, String word2, String number) {
        AccessibilityNodeInfo n = findTask(root, word1, number);
        if (n != null) return n;
        n = findTask(root, word2, number);
        if (n != null) return n;
        n = findTaskSplit(root, word1, word2, number);
        if (n != null) return n;
        return findTaskSpatial(root, word1, word2, number);
    }

    private AccessibilityNodeInfo findTaskSpatial(AccessibilityNodeInfo root, String word1, String word2, String number) {
        if(root==null)return null;
        java.util.ArrayList<AccessibilityNodeInfo> raw=new java.util.ArrayList<>();
        collectActionNodes(root,raw);
        raw.sort((a,b)->Integer.compare(nodeBounds(a).top,nodeBounds(b).top));
        for(AccessibilityNodeInfo n:raw){
            String own=normalize(nodeTextSelf(n));
            if(!containsAnyWord(own,word1,word2))continue;
            String ctx=spatialTaskContext(n,root);
            if(hasReward(ctx,number))return n;
        }
        return null;
    }

    private AccessibilityNodeInfo findTaskSplit(AccessibilityNodeInfo root, String word1, String word2, String number) {
        if(root==null)return null;
        java.util.ArrayList<AccessibilityNodeInfo> raw=new java.util.ArrayList<>();
        collectActionNodes(root,raw);
        raw.sort((a,b)->Integer.compare(nodeBounds(a).top,nodeBounds(b).top));
        for(AccessibilityNodeInfo n:raw){
            String own=normalize(nodeTextSelf(n));
            if(!(containsAnyWord(own,word1,word2)))continue;
            String ctx=taskContextText(n);
            if(hasReward(ctx,number))return n;
        }
        return null;
    }

    private AccessibilityNodeInfo findTask(AccessibilityNodeInfo root, String word, String number) {
        if (root == null) return null;

        String own = normalize(nodeTextSelf(root));
        String compact = compact(own);
        String wanted = compact(word + number);

        // Mutualan can expose the task through text, content-description, or a
        // short HTML/WebView accessibility label. Never require page-level text
        // such as "mutualan.com" before attempting task detection.
        if (isTaskLabel(compact, wanted)) return root;

        String viewId = normalize(root.getViewIdResourceName());
        String viewIdCompact = compact(viewId);
        if (viewIdCompact.contains(compact(word)) && viewIdCompact.contains(number)) {
            return root;
        }

        for (int i = 0; i < root.getChildCount(); i++) {
            AccessibilityNodeInfo found = findTask(root.getChild(i), word, number);
            if (found != null) return found;
        }
        return null;
    }

    private boolean isTaskLabel(String compactText, String wanted) {
        if (compactText == null || wanted == null || compactText.isEmpty()) return false;
        if (compactText.equals(wanted)) return true;
        // Avoid matching a whole page/card aggregate. Allow a short label with
        // optional coin/extra accessibility text around it.
        return compactText.length() <= wanted.length() + 32 && compactText.contains(wanted);
    }

    private String compact(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private boolean isMutualanPage(AccessibilityNodeInfo root) {
        // Kept for compatibility with older builds. Task scanning no longer depends
        // on this page-name check because WebView accessibility trees may omit it.
        if (root == null) return false;
        return hasContains(root, "mutualan.com")
                || findTask(root, "like", "10") != null
                || findTask(root, "follow", "20") != null;
    }

    private boolean hasContains(AccessibilityNodeInfo root, String target) {
        if (root == null) return false;
        if (normalize(nodeTextSelf(root)).contains(normalize(target))) return true;
        for (int i = 0; i < root.getChildCount(); i++) {
            if (hasContains(root.getChild(i), target)) return true;
        }
        return false;
    }

    private String nodeTextDeep(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder s = new StringBuilder();
        appendNodeTextDeep(node, s);
        return s.toString();
    }

    private void appendNodeTextDeep(AccessibilityNodeInfo node, StringBuilder out) {
        if (node == null) return;
        if (node.isVisibleToUser()) {
            String own = nodeTextSelf(node);
            if (!own.isEmpty()) {
                if (out.length() > 0) out.append(' ');
                out.append(own);
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) appendNodeTextDeep(child, out);
        }
    }

    private String nodeTextSelf(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder s = new StringBuilder();
        if (node.getText() != null) s.append(node.getText());
        if (node.getContentDescription() != null) {
            if (s.length() > 0) s.append(' ');
            s.append(node.getContentDescription());
        }
        if (android.os.Build.VERSION.SDK_INT >= 30 && node.getStateDescription() != null) {
            if (s.length() > 0) s.append(' ');
            s.append(node.getStateDescription());
        }
        return s.toString();
    }

    private boolean isVisibleNode(AccessibilityNodeInfo node) {
        if (node == null || !node.isVisibleToUser()) return false;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        return r.width() > 0 && r.height() > 0 && r.left >= 0 && r.top >= 0;
    }

    private boolean isCandidateMutualanPackage(String pkg) {
        return MUTUALAN_PACKAGE.equals(pkg);
    }

    private boolean isMutualanPackage(String pkg) {
        return MUTUALAN_PACKAGE.equals(pkg);
    }

    private boolean shouldKeepMusicPlaying() {
        MainActivity a = MainActivity.getInstance();
        return a != null && a.getPreferences(android.app.Activity.MODE_PRIVATE).getBoolean("keep_music", false);
    }

    private boolean isTikTok(String pkg) {
        return TIKTOK_1.equals(pkg) || TIKTOK_2.equals(pkg);
    }

    private String getCurrentPackage() { return getCurrentPackage(getRootInActiveWindow()); }

    private String getCurrentPackage(AccessibilityNodeInfo root) {
        return root != null && root.getPackageName() != null
                ? root.getPackageName().toString() : "";
    }

    /**
     * Open the supplied Mutualan APK directly. This is deliberately based on the
     * verified package name, not on the last foreground package and not on BACK.
     */
    private boolean performTap(int x, int y) {
        if (android.os.Build.VERSION.SDK_INT < 24) return false;
        try {
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 80);
            return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
        } catch (Throwable ignored) { return false; }
    }

    /** Return from an EMPTY pending page using only its real Accessibility Back button. */
    public void leavePendingScreenAndResumeMain() {
        if (!running || pendingReturnInProgress) return;
        pendingReturnInProgress = true;
        pendingFlowState = PendingFlowState.EMPTY;
        pendingMainRecheckBlockedUntil = System.currentTimeMillis() + 2600L;
        taskLocked = true;
        mainFlowState = MainFlowState.RETURN_MUTUALAN;
        state = State.SCANNING;
        handler.postDelayed(() -> recoverFromPendingPageBack(0), 250L);
    }

    private void recoverFromPendingPageBack(int attempt) {
        if (!running) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();

        // Never use Android BACK, swipe, coordinates, or relaunch as a fallback
        // here. If the exact Accessibility Back is unavailable, stop safely.
        if (root != null && isMutualanMainTaskScreen(root)) {
            pendingReturnInProgress = false;
            confirmMainAfterPendingReturn();
            return;
        }

        if (attempt >= 3) {
            pendingReturnInProgress = false;
            pendingFlowState = PendingFlowState.STOPPED;
            enterSafeMode("BACK Tugas Tertunda tidak terdeteksi via Accessibility");
            return;
        }

        MainActivity.log("Tugas Tertunda kosong → cari Accessibility BACK " + (attempt + 1) + "/3");
        if (tapMutualanPageBack(root)) {
            handler.postDelayed(() -> recoverFromPendingPageBack(attempt + 1), 900L);
        } else {
            handler.postDelayed(() -> recoverFromPendingPageBack(attempt + 1), 500L);
        }
    }

    private boolean tapMutualanPageBack(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo back = findMutualanBackButton(root);
        if (back == null) return false;
        AccessibilityNodeInfo n = back;
        for (int i = 0; i < 6 && n != null; i++) {
            if (isVisibleNode(n) && n.isEnabled() && n.isClickable()
                    && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                MainActivity.log("[OK] Accessibility BACK diklik");
                return true;
            }
            n = n.getParent();
        }
        return false;
    }

    private AccessibilityNodeInfo findMutualanBackButton(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (isVisibleNode(node)) {
            String text = normalize(nodeTextSelf(node));
            String desc = node.getContentDescription() == null ? "" : normalize(node.getContentDescription().toString());
            String id = node.getViewIdResourceName() == null ? "" : normalize(node.getViewIdResourceName());
            Rect b = nodeBounds(node);
            boolean topLeft = !b.isEmpty()
                    && b.centerX() < getResources().getDisplayMetrics().widthPixels * 0.20f
                    && b.centerY() < getResources().getDisplayMetrics().heightPixels * 0.20f;
            boolean back = text.equals("back") || text.equals("kembali")
                    || desc.equals("back") || desc.equals("kembali")
                    || desc.contains("navigate up") || id.contains("back") || id.contains("navigate_up");
            if (topLeft && back) return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findMutualanBackButton(node.getChild(i));
            if (found != null) return found;
        }
        return null;
    }

    private boolean isMutualanMainTaskScreen(AccessibilityNodeInfo root) {
        if (root == null || !isMutualanPackage(getCurrentPackage(root))) return false;
        if (pendingRetryEngine != null && pendingRetryEngine.isPendingScreen(root)) return false;
        if (normalize(nodeTextDeep(root)).contains("beranda")) return true;
        return !collectMainTaskCandidates(root).items.isEmpty();
    }

    private void confirmMainAfterPendingReturn() {
        if (!running) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null && isMutualanMainTaskScreen(root)) {
            taskLocked = false;
            pendingAutoOpenTriggered = false;
            pendingReturnInProgress = false;
            pendingFlowState = PendingFlowState.NONE;
            strictResumeScan = true;
            strictResumeMisses = 0;
            mainFlowState = MainFlowState.WAIT_MAIN_TASK_CHANGE;
            MainActivity.log("[OK] Accessibility BACK berhasil → tunggu Task utama → STRICT SCAN Follow/Like");
            long wait = Math.max(700L, pendingMainRecheckBlockedUntil - System.currentTimeMillis());
            schedule(wait, this::scanCurrentTask);
            return;
        }
        // Wait for the Accessibility tree to settle. Do not relaunch Mutualan
        // and do not issue another BACK here: the previous Accessibility click
        // may already have succeeded while the WebView is still rebuilding.
        if (System.currentTimeMillis() - pendingMainRecheckBlockedUntil < 6000L) {
            schedule(500L, this::confirmMainAfterPendingReturn);
            return;
        }
        pendingFlowState = PendingFlowState.STOPPED;
        enterSafeMode("Task utama tidak terdeteksi setelah Accessibility BACK");
    }

    /**
     * Legacy entry point kept for binary/source compatibility. Returning from
     * Tugas Tertunda must NEVER swipe the Mutualan task page. The page is allowed
     * to refresh itself; then the normal scanner selects the next visible target.
     */
    private void swipeToNextMainTaskAndScan() {
        if (!running) return;
        taskLocked = true;
        state = State.SCANNING;
        MainActivity.log("↩ Resume Task utama → tanpa swipe, tunggu daftar refresh");
        schedule(getActionDelayMs(), () -> {
            taskLocked = false;
            scanCurrentTask();
        });
    }

    private boolean launchMutualanPackage() {
        try {
            // Mutualan APK supplied for this project exposes:
            // com.mutualan.MainActivity
            // Use the explicit component so Android cannot resolve a stale or
            // different launcher target. CLEAR_TASK forces a real re-entry into
            // Mutualan instead of merely revealing an already-running screen.
            Intent intent = new Intent();
            intent.setClassName(MUTUALAN_PACKAGE, "com.mutualan.MainActivity");
            intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            );

            startActivity(intent);
            mutualanPackage = MUTUALAN_PACKAGE;
            MainActivity.log("Mutualan MainActivity → dibuka ulang");
            return true;
        } catch (Exception e) {
            MainActivity.log("Launch Mutualan error: " + e.getClass().getSimpleName());
            return false;
        }
    }

    public AccessibilityNodeInfo findMutualanRootForEngine() {
        return findMutualanRootInternal();
    }

    private AccessibilityNodeInfo findMutualanRootInternal() {
        try {
            AccessibilityNodeInfo active = getRootInActiveWindow();
            if (active != null && isMutualanPackage(getCurrentPackage(active))) return active;
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                for (AccessibilityWindowInfo window : getWindows()) {
                    AccessibilityNodeInfo r = window.getRoot();
                    if (r != null && isMutualanPackage(getCurrentPackage(r))) return r;
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public boolean isMutualanPackagePublic(String pkg) { return isMutualanPackage(pkg); }

    public void scheduleEngine(long delay, Runnable action) { schedule(delay, action); }

    public void pendingActionFinishedDelete() {
        clearPendingAction();
        taskLocked = false;
        state = State.SCANNING;
        AppState.setActiveTaskKey("");
        AppState.setRetryAttempt(0);
        schedule(350L, () -> { if (running && pendingRetryEngine != null) pendingRetryEngine.scanNow(); });
    }

    public void refreshMainUi() {
        MainActivity a = MainActivity.getInstance();
        if (a != null) a.refreshUi();
    }

    public String currentPackageName() { return getCurrentPackage(); }

    private void unlockAndScan() {
        final long token = ++stateToken;
        taskLocked = false;
        followClicked = false;
        clickedFollowBounds = null;
        likeClicked = false;
        clickedLikeBounds = null;
        likeTaskActive = false;
        activeTaskUsername = "";
        refreshInProgress = false;
        taskOpenStartedAt = 0L;
        likeRetries = 0;
        followRetries = 0;
        state = State.SCANNING;
        mainFlowState = MainFlowState.SCAN_MAIN_TASK;
        schedule(700L, () -> {
            if (running && token == stateToken && !taskLocked) scanCurrentTask();
        });
    }

    /**
     * Stop only the current task. PLAY remains enabled. If TikTok is still
     * visible, route deterministically back to Mutualan instead of leaving the
     * automation inert on TikTok.
     */
    private void enterSafeMode(String reason) {
        ++stateToken;
        taskLocked = true;
        safeMode = true;
        safeReason = reason;
        failedTaskKey = activeTaskKey == null ? "" : activeTaskKey;
        failedTaskUntil = System.currentTimeMillis() + 30000L;
        followClicked = false;
        clickedFollowBounds = null;
        likeClicked = false;
        clickedLikeBounds = null;
        likeTaskActive = false;
        refreshInProgress = false;
        returnAttempts = 0;
        state = State.RETURNING;
        flowStartedAt = System.currentTimeMillis();
        final long token = ++stateToken;

        MainActivity.log("MODE AMAN — " + reason);
        MainActivity.log("Aksi otomatis dihentikan sementara — pulihkan Mutualan");

        if (!launchMutualanPackage()) {
            MainActivity.log("Mode aman: launch Mutualan gagal — coba lagi");
            schedule(1000L, () -> {
                if (token == stateToken && safeMode) launchMutualanPackage();
            });
        }
        schedule(getTransitionDelayMs(), () -> waitForMutualanReturn(token));
        updateOverlay();
    }

    private void abortCurrentTaskToMutualan() {
        ++stateToken;
        taskLocked = true;

        followClicked = false;
        clickedFollowBounds = null;
        likeClicked = false;
        clickedLikeBounds = null;
        likeTaskActive = false;
        refreshInProgress = false;
        returnAttempts = 0;

        if (!running) {
            state = State.IDLE;
            return;
        }

        if (isTikTok(getCurrentPackage())) {
            state = State.RETURNING;
            flowStartedAt = System.currentTimeMillis();
            final long token = ++stateToken;

            MainActivity.log("Task dibatalkan → kembali ke Mutualan");

            if (!launchMutualanPackage()) {
                MainActivity.log("Launch Mutualan gagal → retry langsung");
                schedule(800L, () -> {
                    if (running && token == stateToken && state == State.RETURNING) {
                        launchMutualanPackage();
                    }
                });
            }

            schedule(getTransitionDelayMs(), () -> waitForMutualanReturn(token));
        } else {
            state = State.SCANNING;
            schedule(MUTUALAN_STABLE_DELAY, () -> {
                if (running && !taskLocked) scanCurrentTask();
                else if (running) {
                    taskLocked = false;
                    scanCurrentTask();
                }
            });
        }
    }

    private void safeStopCurrentFlow() {
        ++stateToken;
        taskLocked = false;
        followClicked = false;
        clickedFollowBounds = null;
        likeClicked = false;
        clickedLikeBounds = null;
        likeTaskActive = false;
        refreshInProgress = false;
        state = State.IDLE;
        cancelScheduledWork();

        // STOP AMAN stops only the current task. PLAY remains active.
        // If Mutualan is already visible, immediately resume scanning after the
        // normal 2-second settle delay; this fixes the "PLAY but does nothing" bug.
        if (running) {
            schedule(MUTUALAN_STABLE_DELAY, this::resumeFromCurrentScreen);
        }
    }

    private void schedule(long delay, Runnable action) {
        handler.postDelayed(action, Math.max(50L, delay));
    }

    private void cancelScheduledWork() {
        handler.removeCallbacksAndMessages(null);
    }

    private long getDelayMs() {
        MainActivity a = MainActivity.getInstance();
        return a != null ? Math.max(300L, Math.min(3000L, a.getDelayMs())) : 700L;
    }

    // Delay Pengerjaan: deliberate waits before/after an actual automation action.
    private long getActionDelayMs() {
        return getDelayMs();
    }

    // Keep accessibility polling responsive even when the user chooses a long work delay.
    private long getPollingDelayMs() {
        return Math.max(400L, Math.min(900L, getDelayMs()));
    }

    // Page transitions need a little settling time, but should still follow the user's setting.
    private long getTransitionDelayMs() {
        return Math.max(700L, getDelayMs());
    }

    private String normalize(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }

    @Override public void onInterrupt() {
        cancelScheduledWork();
    }

    @Override
    public void onDestroy() {
        running = false;
        try { unregisterReceiver(screenStateReceiver); } catch (Throwable ignored) {}
        if (pendingRetryEngine != null) pendingRetryEngine.stop();
        cancelScheduledWork();
        removeControlOverlay();
        if (instance == this) {
            instance = null;
            serviceConnected = false;
        } else {
            serviceConnected = false;
        }
        super.onDestroy();
    }

}
