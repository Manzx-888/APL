package com.manzxdigital.autoklikpro.engine;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class AppState {
    public enum Mode { IDLE, TASK, RETRY }
    public enum TaskState { IDLE, SCANNING, TASK_FOUND, EXECUTING, VERIFYING, SUCCESS, RETRY, FAILED_AFTER_5_RETRIES }

    private static volatile Mode mode = Mode.IDLE;
    private static volatile TaskState taskState = TaskState.IDLE;
    private static volatile String activeTaskKey = "";
    private static volatile int retryAttempt = 0;
    private static volatile int success = 0;
    private static volatile int failed = 0;
    private static volatile int skipped = 0;
    private static volatile int deleted = 0;
    private static volatile int retryTotal = 0;
    private static volatile int followTotal = 0;
    private static volatile int likeTotal = 0;
    private static volatile int remaining = 0;
    private static SharedPreferences persistent;

    public static synchronized void init(Context context) {
        if (context != null && persistent == null) {
            persistent = context.getApplicationContext().getSharedPreferences("autoklik_totals", Context.MODE_PRIVATE);
            // Load persisted counters into the runtime cache. Without this, the
            // first increment after an app/service restart started from zero and
            // overwrote thousands of previously recorded tasks with 1.
            success = persistent.getInt("success", 0);
            deleted = persistent.getInt("deleted", 0);
            retryTotal = persistent.getInt("retry", 0);
            followTotal = persistent.getInt("follow", 0);
            likeTotal = persistent.getInt("like", 0);
        }
    }

    private static void persist(String key, int value) {
        if (persistent != null) persistent.edit().putInt(key, value).apply();
    }

    private static void recordDaily(String type) {
        if (persistent == null) return;
        String day = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        String key = "daily_" + day;
        persistent.edit().putInt(key, persistent.getInt(key, 0) + 1).apply();
    }

    public static int getPersistent(String key) { return persistent == null ? 0 : persistent.getInt(key, 0); }
    public static int getDaily(String day) { return persistent == null ? 0 : persistent.getInt("daily_" + day, 0); }

    private AppState() {}

    public static synchronized void resetAll() {
        // Reset automation state only. Statistics are persistent and must never
        // be erased by pressing RESET/starting a new automation session.
        mode = Mode.IDLE; taskState = TaskState.IDLE; activeTaskKey = ""; retryAttempt = 0;
        failed = skipped = remaining = 0;
        if (persistent != null) {
            success = persistent.getInt("success", success);
            deleted = persistent.getInt("deleted", deleted);
            retryTotal = persistent.getInt("retry", retryTotal);
            followTotal = persistent.getInt("follow", followTotal);
            likeTotal = persistent.getInt("like", likeTotal);
        }
    }
    public static Mode getMode() { return mode; }
    public static void setMode(Mode value) { mode = value; }
    public static TaskState getTaskState() { return taskState; }
    public static void setTaskState(TaskState value) { taskState = value; }
    public static String getActiveTaskKey() { return activeTaskKey; }
    public static void setActiveTaskKey(String value) { activeTaskKey = value == null ? "" : value; }
    public static int getRetryAttempt() { return retryAttempt; }
    public static void setRetryAttempt(int value) { retryAttempt = Math.max(0, value); }
    public static int getSuccess() { return persistent == null ? success : persistent.getInt("success", success); }
    public static int getFailed() { return failed; }
    public static int getSkipped() { return skipped; }
    public static int getDeleted() { return persistent == null ? deleted : persistent.getInt("deleted", deleted); }
    public static int getRetryTotal() { return persistent == null ? retryTotal : persistent.getInt("retry", retryTotal); }
    public static int getFollowTotal() { return persistent == null ? followTotal : persistent.getInt("follow", followTotal); }
    public static int getLikeTotal() { return persistent == null ? likeTotal : persistent.getInt("like", likeTotal); }
    public static int getRemaining() { return remaining; }
    public static void setRemaining(int value) { remaining = Math.max(0, value); }
    public static synchronized void incSuccess() {
        success = getPersistent("success") + 1;
        persist("success", success);
        recordDaily("success");
    }
    public static synchronized void incFailed() { failed++; }
    public static synchronized void incSkipped() { skipped++; }
    public static synchronized void incDeleted() {
        deleted = getPersistent("deleted") + 1;
        persist("deleted", deleted);
        recordDaily("deleted");
    }
    public static synchronized void incRetry() {
        retryTotal = getPersistent("retry") + 1;
        persist("retry", retryTotal);
        recordDaily("retry");
    }
    public static synchronized void incFollow() {
        followTotal = getPersistent("follow") + 1;
        persist("follow", followTotal);
    }
    public static synchronized void incLike() {
        likeTotal = getPersistent("like") + 1;
        persist("like", likeTotal);
    }
}
