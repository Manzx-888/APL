package com.manzxdigital.autoklikpro;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Calendar;
import com.manzxdigital.autoklikpro.engine.AppState;

public class MainActivity extends Activity {
    private static MainActivity instance;
    private static final String PREF = "autoklik_pro";
    private final List<String> logs = new ArrayList<>();
    private TextView accessStatus, automationStatus, currentTask, currentState, modeTitle, modeDetail;
    private TextView settingsAccess, retryDelayValue, workDelayValue, pendingThresholdValue, mediaStatus, homeLicenseStatus, homeLicenseExpiry;
    private TextView logText, retryCount, deletedCount, successCount, followCount, likeCount, totalTaskCount, activeDuration, successRate;
    private NeonChartView activityChart;
    private long sessionStartedAt = System.currentTimeMillis();
    private int lastSuccess = 0, lastRetry = 0, lastDeleted = 0;
    private ScrollView logScroll;
    private String currentLogFilter = "all";
    private String lastRenderedLog = "";
    private View pageHome, pageLog, pageStats, pageSettings;
    private int currentPage = 0;
    private long retryDelayMs = 3000L;
    private long workDelayMs = 700L;
    private int pendingThreshold = 25;
    private ObjectAnimator accessPulseAnimator;
    private boolean loadingShown = false;
    private ObjectAnimator scanningPulseAnimator;
    private String lastModeDetail = "";

    public static MainActivity getInstance() { return instance; }
    public static boolean isRunning() { return AutomationAccessibilityService.isRunning(); }
    public static long getRetryDelayMs() { return instance == null ? 3000L : instance.retryDelayMs; }
    public static long getWorkDelayMs() { return instance == null ? 700L : instance.workDelayMs; }
    public static int getPendingThreshold() { return instance == null ? 25 : instance.pendingThreshold; }
    public static void refreshUiStatic() { if (instance != null) instance.runOnUiThread(instance::refreshUi); }

    public static void log(String message) {
        if (instance != null) instance.runOnUiThread(() -> instance.appendLog(message));
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        instance = this;
        AppState.init(this);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            // Draw edge-to-edge ourselves and apply safe-area padding manually below,
            // instead of relying on windowOptOutEdgeToEdgeEnforcement (ignored on API 35+).
            getWindow().setDecorFitsSystemWindows(false);
        }
        getWindow().setStatusBarColor(Color.rgb(5,4,13));
        getWindow().setNavigationBarColor(Color.rgb(5,4,13));
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            getWindow().setStatusBarContrastEnforced(false);
            getWindow().setNavigationBarContrastEnforced(false);
        }
        getWindow().getDecorView().setSystemUiVisibility(0);
        if (!LicenseManager.isActivated(this)) {
            showLicensePage();
            return;
        }
        setContentView(R.layout.activity_main);
        applyTypography();
        applySystemBarInsets();
        bindViews();
        styleHeader();
        applyDisplayFonts();
        loadPrefs();
        wireClicks();
        showPage(0, false);
        refreshUi();
        refreshMediaUi();
        updateLogFilterUi();
        playStartupLoading();
        animateEntry(findViewById(R.id.header), 0);
    }


    private void applyTypography() {
        View root = findViewById(R.id.root);
        if (root == null) return;
        applyTypographyRecursive(root);
    }

    private void applyTypographyRecursive(View view) {
        Typeface germania = getResources().getFont(R.font.germania_one);
        if (view instanceof android.widget.TextView) {
            android.widget.TextView tv = (android.widget.TextView) view;
            int id = view.getId();
            boolean customDisplayFont = id == R.id.headerTitle
                    || id == R.id.loadingManzx
                    || id == R.id.loadingDigital
                    || id == R.id.pageTitleHome
                    || id == R.id.pageTitleLog
                    || id == R.id.pageTitleStats
                    || id == R.id.pageTitleSettings;

            // Preserve bold declared by the XML for every card/section title.
            // Previously this recursive pass replaced those typefaces with normal
            // old condensed fallback, which made the headings look too thin.
            if (!customDisplayFont && id != R.id.logText) {
                boolean originallyBold = tv.getTypeface() != null
                        && (tv.getTypeface().getStyle() & Typeface.BOLD) != 0;
                if (view instanceof Button) {
                    tv.setTypeface(Typeface.create(germania, Typeface.BOLD));
                } else {
                    tv.setTypeface(Typeface.create(germania, originallyBold ? Typeface.BOLD : Typeface.NORMAL));
                }
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) applyTypographyRecursive(group.getChildAt(i));
        }
    }

    private void applySystemBarInsets() {
        View root = findViewById(R.id.root);
        View container = findViewById(R.id.appContainer);
        View loadingOverlay = findViewById(R.id.loadingOverlay);
        if (root == null || container == null) return;

        // Header and bottomNav have fixed heights, so we never pad them directly
        // (that would squeeze their content). Instead we grow the padding of the
        // match_parent-height column that wraps them — this pushes the header down
        // below the status bar and lifts the nav bar above the gesture area without
        // clipping anything inside either one.
        final int containerBaseLeft = container.getPaddingLeft();
        final int containerBaseTop = container.getPaddingTop();
        final int containerBaseRight = container.getPaddingRight();
        final int containerBaseBottom = container.getPaddingBottom();
        final int loadingBaseLeft = loadingOverlay != null ? loadingOverlay.getPaddingLeft() : 0;
        final int loadingBaseTop = loadingOverlay != null ? loadingOverlay.getPaddingTop() : 0;
        final int loadingBaseRight = loadingOverlay != null ? loadingOverlay.getPaddingRight() : 0;
        final int loadingBaseBottom = loadingOverlay != null ? loadingOverlay.getPaddingBottom() : 0;

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int left, top, right, bottom;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = bars.left; top = bars.top; right = bars.right; bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            container.setPadding(containerBaseLeft + left, containerBaseTop + top, containerBaseRight + right, containerBaseBottom + bottom);
            // Loading screen is drawn full-bleed behind the system bars too, so it needs the same safe area.
            if (loadingOverlay != null) {
                loadingOverlay.setPadding(loadingBaseLeft + left, loadingBaseTop + top, loadingBaseRight + right, loadingBaseBottom + bottom);
            }
            return insets;
        });
        root.requestApplyInsets();
    }

    private void styleHeader() {
        TextView title = findViewById(R.id.headerTitle);
        SpannableString ss = new SpannableString("AutoKlik Pro");
        ss.setSpan(new ForegroundColorSpan(Color.parseColor("#F8F5FF")), 0, 8, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(new ForegroundColorSpan(Color.parseColor("#C56CFF")), 9, 12, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        title.setText(ss);
    }

    private void applyDisplayFonts() {
        Typeface climate = getResources().getFont(R.font.climate_crisis);
        Typeface germania = getResources().getFont(R.font.germania_one);
        Typeface newRocker = getResources().getFont(R.font.new_rocker);

        TextView home = findViewById(R.id.pageTitleHome);
        TextView log = findViewById(R.id.pageTitleLog);
        TextView stats = findViewById(R.id.pageTitleStats);
        TextView settings = findViewById(R.id.pageTitleSettings);
        TextView loadingManzx = findViewById(R.id.loadingManzx);
        TextView loadingDigital = findViewById(R.id.loadingDigital);

        if (home != null) home.setTypeface(getResources().getFont(R.font.blaka), Typeface.BOLD);
        if (log != null) log.setTypeface(getResources().getFont(R.font.blaka), Typeface.BOLD);
        if (stats != null) stats.setTypeface(getResources().getFont(R.font.blaka), Typeface.BOLD);
        if (settings != null) settings.setTypeface(getResources().getFont(R.font.blaka), Typeface.BOLD);
        if (loadingManzx != null) loadingManzx.setTypeface(newRocker, Typeface.BOLD);
        if (loadingDigital != null) loadingDigital.setTypeface(newRocker, Typeface.BOLD);
    }

    private void bindViews() {
        accessStatus=findViewById(R.id.accessStatus); automationStatus=findViewById(R.id.automationStatus);
        currentTask=findViewById(R.id.currentTask); currentState=findViewById(R.id.currentState);
        modeTitle=findViewById(R.id.modeTitle); modeDetail=findViewById(R.id.modeDetail);
        settingsAccess=findViewById(R.id.settingsAccess); homeLicenseStatus=findViewById(R.id.homeLicenseStatus); homeLicenseExpiry=findViewById(R.id.homeLicenseExpiry); mediaStatus=findViewById(R.id.mediaStatus); retryDelayValue=findViewById(R.id.retryDelayValue); workDelayValue=findViewById(R.id.workDelayValue); pendingThresholdValue=findViewById(R.id.pendingThresholdValue);
        logText=findViewById(R.id.logText); logScroll=findViewById(R.id.logScroll); retryCount=findViewById(R.id.retryCount); deletedCount=findViewById(R.id.deletedCount); successCount=findViewById(R.id.successCount); followCount=findViewById(R.id.followCount); likeCount=findViewById(R.id.likeCount); totalTaskCount=findViewById(R.id.totalTaskCount); activeDuration=findViewById(R.id.activeDuration); successRate=findViewById(R.id.successRate); activityChart=findViewById(R.id.activityChart);
        pageHome=findViewById(R.id.pageHome); pageLog=findViewById(R.id.pageLog); pageStats=findViewById(R.id.pageStats); pageSettings=findViewById(R.id.pageSettings);
    }

    private void wireClicks() {
        findViewById(R.id.startButton).setOnClickListener(v -> showOverlayOnly());
                findViewById(R.id.resetButton).setOnClickListener(v -> AutomationAccessibilityService.resetAutomation());
        findViewById(R.id.openMutualan).setOnClickListener(v -> openMutualan());
        findViewById(R.id.openAccessibility).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.clearLog).setOnClickListener(v -> { logs.clear(); lastRenderedLog=""; renderLog(currentLogFilter); refreshUi(); });
        findViewById(R.id.saveSettings).setOnClickListener(v -> { getPreferences(MODE_PRIVATE).edit().putLong("retry",retryDelayMs).putLong("work",workDelayMs).putInt("pending_threshold",pendingThreshold).apply(); toast("Pengaturan disimpan"); refreshUi(); });
        findViewById(R.id.navHome).setOnClickListener(v -> showPage(0));
        findViewById(R.id.navLog).setOnClickListener(v -> showPage(1));
        findViewById(R.id.navStats).setOnClickListener(v -> showPage(2));
        findViewById(R.id.navSettings).setOnClickListener(v -> showPage(3));
        findViewById(R.id.retryMinus).setOnClickListener(v -> { retryDelayMs=Math.max(500,retryDelayMs-500); refreshUi(); });
        findViewById(R.id.retryPlus).setOnClickListener(v -> { retryDelayMs=Math.min(10000,retryDelayMs+500); refreshUi(); });
        findViewById(R.id.workMinus).setOnClickListener(v -> { workDelayMs=Math.max(300,workDelayMs-100); refreshUi(); });
        findViewById(R.id.workPlus).setOnClickListener(v -> { workDelayMs=Math.min(3000,workDelayMs+100); refreshUi(); });
        findViewById(R.id.pendingMinus).setOnClickListener(v -> { pendingThreshold=Math.max(1,pendingThreshold-1); refreshUi(); });
        findViewById(R.id.pendingPlus).setOnClickListener(v -> { pendingThreshold=Math.min(999,pendingThreshold+1); refreshUi(); });
        findViewById(R.id.filterAll).setOnClickListener(v -> selectLogFilter("all"));
        findViewById(R.id.filterSuccess).setOnClickListener(v -> selectLogFilter("success"));
        findViewById(R.id.filterDelete).setOnClickListener(v -> selectLogFilter("delete"));
        findViewById(R.id.filterRetry).setOnClickListener(v -> selectLogFilter("retry"));
        findViewById(R.id.mediaToggle).setOnClickListener(v -> {
            if (!hasMediaControlAccess()) {
                openMediaControlSettings();
                refreshMediaUi();
                return;
            }
            boolean enabled = !getPreferences(MODE_PRIVATE).getBoolean("keep_music", false);
            getPreferences(MODE_PRIVATE).edit().putBoolean("keep_music", enabled).apply();
            toast(enabled ? "Spotify akan dijaga tetap berjalan saat TikTok dibuka" : "Kontrol musik dimatikan");
            refreshMediaUi();
        });
        findViewById(R.id.mediaAccess).setOnClickListener(v -> {
            if (!hasMediaControlAccess()) openMediaControlSettings();
            else {
                getPreferences(MODE_PRIVATE).edit().putBoolean("keep_music", true).apply();
                toast("Kontrol musik aktif");
                refreshMediaUi();
            }
        });

        findViewById(R.id.helpOwner).setOnClickListener(v -> openWhatsAppOwner());

        applySmoothPressAnimations(findViewById(R.id.root));
    }

    private void applySmoothPressAnimations(View root) {
        if (root == null) return;
        if (root instanceof android.widget.Button || root instanceof android.widget.Switch || root.isClickable()) {
            root.setOnTouchListener((v, event) -> {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    v.animate().scaleX(0.90f).scaleY(0.90f).setDuration(120).setInterpolator(new AccelerateDecelerateInterpolator()).start();
                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(new DecelerateInterpolator()).start();
                }
                return false;
            });
        }
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) applySmoothPressAnimations(group.getChildAt(i));
        }
    }

    private void openWhatsAppOwner() {
        try {
            Intent wa = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/62881026448545"));
            startActivity(wa);
        } catch (Exception e) {
            toast("WhatsApp tidak tersedia");
        }
    }

    private void showLicensePage() {
        setContentView(R.layout.activity_license);
        applyLicenseInsets();
        TextView device = findViewById(R.id.licenseDeviceId);
        EditText input = findViewById(R.id.licenseInput);
        input.setSingleLine(true);
        input.setHorizontallyScrolling(true);
        input.setMaxLines(1);
        TextView status = findViewById(R.id.licenseStatus);
        TextView expiry = findViewById(R.id.licenseExpiry);
        device.setText(LicenseManager.getDeviceId(this));
        Button copy = findViewById(R.id.copyDevice);
        copy.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Device ID", LicenseManager.getDeviceId(this)));
            toast("Device ID disalin");
        });
        findViewById(R.id.activateLicense).setOnClickListener(v -> {
            LicenseManager.Result result = LicenseManager.activate(this, input.getText().toString());
            if (!result.valid) {
                status.setText(result.message);
                status.setTextColor(Color.parseColor("#FF477E"));
                return;
            }
            status.setText("✓ LISENSI AKTIF");
            status.setTextColor(Color.parseColor("#19E7A0"));
            expiry.setText(result.lifetime ? "LIFETIME" : "Berlaku sampai " + formatLicenseDay(result.expiryDay));
            expiry.setTextColor(Color.parseColor("#C56CFF"));
            Toast.makeText(this, "Lisensi berhasil diaktifkan", Toast.LENGTH_SHORT).show();
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> recreate(), 450);
        });
        findViewById(R.id.licenseWhatsapp).setOnClickListener(v -> openWhatsAppOwner());
    }

    private void applyLicenseInsets() {
        final ScrollView page = findViewById(R.id.licensePage);
        if (page == null) return;
        final int baseL = page.getPaddingLeft();
        final int baseT = page.getPaddingTop();
        final int baseR = page.getPaddingRight();
        final int baseB = page.getPaddingBottom();
        page.setOnApplyWindowInsetsListener((v, insets) -> {
            int left, top, right, bottom;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = Math.max(bars.bottom, ime.bottom);
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = Math.max(insets.getSystemWindowInsetBottom(), 0);
            }
            v.setPadding(baseL + left, baseT + top, baseR + right, baseB + bottom);
            return insets;
        });
        page.requestApplyInsets();
    }

    private String formatLicenseDay(long day) {
        return new SimpleDateFormat("dd MMM yyyy", Locale.US).format(new Date(day * 86400000L));
    }

    private boolean hasMediaControlAccess() {
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (enabled == null) return false;
        String me = getPackageName() + "/" + SpotifyMediaNotificationService.class.getName();
        return enabled.contains(me);
    }

    private boolean isKeepMusicEnabled() {
        return getPreferences(MODE_PRIVATE).getBoolean("keep_music", false);
    }

    private void openMediaControlSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            toast("Aktifkan akses notifikasi untuk kontrol Spotify");
        } catch (Exception e) {
            toast("Pengaturan kontrol media tidak tersedia");
        }
    }

    private void refreshMediaUi() {
        if (mediaStatus == null) return;
        boolean access = hasMediaControlAccess();
        boolean enabled = access && isKeepMusicEnabled();
        mediaStatus.setText(enabled ? "Status musik: TERJAGA" : (access ? "Status musik: SIAP DIKONTROL" : "Status musik: AKSES BELUM AKTIF"));
        mediaStatus.setTextColor(Color.parseColor(enabled ? "#19E7A0" : (access ? "#C56CFF" : "#FF477E")));
        android.widget.Switch sw = findViewById(R.id.mediaToggle);
        if (sw != null) sw.setChecked(enabled);
        Button btn = findViewById(R.id.mediaAccess);
        if (btn != null) btn.setText(access ? (enabled ? "MATIKAN KONTROL MUSIK" : "AKTIFKAN KONTROL MUSIK") : "BUKA AKSES MEDIA");
    }

    private void loadPrefs() {
        retryDelayMs=getPreferences(MODE_PRIVATE).getLong("retry",3000L);
        workDelayMs=getPreferences(MODE_PRIVATE).getLong("work",700L);
        pendingThreshold=getPreferences(MODE_PRIVATE).getInt("pending_threshold",25);
        if (pendingThreshold < 1) pendingThreshold = 25;
    }

    private void showOverlayOnly() {
        if (!isAccessibilityEnabled()) {
            toast("Aktifkan Accessibility dulu");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        AutomationAccessibilityService.showOverlayFromUi();
        appendLog("OVERLAY KONTROL DITAMPILKAN — tekan PLAY di overlay untuk memulai");
    }

    private void openMutualan() {
        Intent i=getPackageManager().getLaunchIntentForPackage("com.mutualan");
        if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(i);} else toast("Aplikasi Mutualan (com.mutualan) tidak ditemukan");
    }

    private boolean isAccessibilityEnabled() { return AutomationAccessibilityService.isServiceConnected(); }

    public long getDelayMs() { return workDelayMs; }

    public void refreshUi() {
        if(accessStatus==null)return;
        boolean connected=isAccessibilityEnabled();
        accessStatus.setText(connected?"TERHUBUNG":"BELUM TERHUBUNG"); accessStatus.setTextColor(Color.parseColor(connected?"#25E59A":"#F43F78"));
        if (connected) {
            if (accessPulseAnimator == null || !accessPulseAnimator.isRunning()) {
                accessPulseAnimator = ObjectAnimator.ofFloat(accessStatus, View.ALPHA, 0.55f, 1f);
                accessPulseAnimator.setDuration(900); accessPulseAnimator.setRepeatMode(ValueAnimator.REVERSE); accessPulseAnimator.setRepeatCount(ValueAnimator.INFINITE); accessPulseAnimator.start();
            }
        } else if (accessPulseAnimator != null) { accessPulseAnimator.cancel(); accessStatus.setAlpha(1f); }
        boolean running=AutomationAccessibilityService.isRunning();
        String state=AutomationAccessibilityService.getStateLabel();
        if(AppState.getMode()==AppState.Mode.RETRY && running) state="AUTOKLIK RETRY";
        automationStatus.setText(running?state:"IDLE"); automationStatus.setTextColor(Color.parseColor(running?"#C19BFF":"#AAA9B9"));
        String active=AppState.getActiveTaskKey();
        currentTask.setText(active.isEmpty()?"Belum ada task aktif":active);
        currentState.setText("State: "+AppState.getTaskState().name()+"  •  Retry "+AppState.getRetryAttempt()+"/5");
        boolean scanning = running || AppState.getTaskState().name().contains("SCAN");
        if (scanning) {
            if (scanningPulseAnimator == null || !scanningPulseAnimator.isRunning()) {
                scanningPulseAnimator = ObjectAnimator.ofFloat(currentState, View.ALPHA, 0.45f, 1f);
                scanningPulseAnimator.setDuration(850); scanningPulseAnimator.setRepeatMode(ValueAnimator.REVERSE); scanningPulseAnimator.setRepeatCount(ValueAnimator.INFINITE); scanningPulseAnimator.start();
            }
        } else if (scanningPulseAnimator != null) { scanningPulseAnimator.cancel(); currentState.setAlpha(1f); }
        String newModeDetail;
        if(AppState.getMode()==AppState.Mode.RETRY){modeTitle.setText("Mode aktif • AUTOKLIK RETRY"); newModeDetail="Tugas Tertunda → retry 1/5…5/5 → verifikasi task hilang/berubah → lanjut.";}
        else if(running){modeTitle.setText("Mode aktif • AUTOKLIK TASK"); newModeDetail="Task → Follow/Like → TikTok → verifikasi aksi → kembali Mutualan.";}
        else {modeTitle.setText("Mode aktif • OTOMATIS"); newModeDetail="Scanner memilih Task atau Tugas Tertunda berdasarkan halaman yang terlihat.";}
        if (!newModeDetail.equals(lastModeDetail)) {
            lastModeDetail = newModeDetail;
            modeDetail.animate().alpha(0f).setDuration(100).withEndAction(() -> {
                modeDetail.setText(newModeDetail);
                modeDetail.animate().alpha(1f).setDuration(180).start();
            }).start();
        }
        if (homeLicenseStatus != null && homeLicenseExpiry != null) {
            LicenseManager.Result lr = LicenseManager.getCurrent(this);
            if (lr.valid) {
                homeLicenseStatus.setText("✓ LISENSI AKTIF");
                homeLicenseStatus.setTextColor(Color.parseColor("#19E7A0"));
                homeLicenseExpiry.setText(lr.lifetime ? "LIFETIME" : "S/D " + formatLicenseDay(lr.expiryDay));
            } else {
                homeLicenseStatus.setText("⚠ LISENSI BERMASALAH");
                homeLicenseStatus.setTextColor(Color.parseColor("#FF477E"));
                homeLicenseExpiry.setText("AKTIVASI");
            }
        }
        settingsAccess.setText(connected?"TERHUBUNG":"BELUM TERHUBUNG"); settingsAccess.setTextColor(Color.parseColor(connected?"#25E59A":"#F43F78"));
        retryDelayValue.setText(String.valueOf(retryDelayMs)); workDelayValue.setText(String.valueOf(workDelayMs));
        if (pendingThresholdValue != null) pendingThresholdValue.setText(String.valueOf(pendingThreshold));
        retryCount.setText(String.valueOf(AppState.getRetryTotal()));
        deletedCount.setText(String.valueOf(AppState.getDeleted()));
        successCount.setText(String.valueOf(AppState.getSuccess()));
        followCount.setText(String.valueOf(AppState.getFollowTotal()));
        likeCount.setText(String.valueOf(AppState.getLikeTotal()));
        int totalProcessed = AppState.getSuccess() + AppState.getFailed() + AppState.getSkipped() + AppState.getDeleted();
        totalTaskCount.setText(String.valueOf(totalProcessed));
        long elapsed = Math.max(0L, System.currentTimeMillis() - sessionStartedAt);
        long mins = elapsed / 60000L;
        activeDuration.setText(mins + "m");
        int rate = totalProcessed == 0 ? 0 : Math.round((AppState.getSuccess() * 100f) / totalProcessed);
        successRate.setText(rate + "%");
        updateActivityHistory();
        renderLog(currentLogFilter);
    }


    private void updateActivityHistory() {
        int success = AppState.getSuccess();
        int retry = AppState.getRetryTotal();
        int deleted = AppState.getDeleted();
        int delta = Math.max(0, success - lastSuccess)
                + Math.max(0, retry - lastRetry)
                + Math.max(0, deleted - lastDeleted);
        lastSuccess = success;
        lastRetry = retry;
        lastDeleted = deleted;
        if (delta > 0) {
            android.content.SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
            String key = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
            int today = sp.getInt("activity_" + key, 0) + delta;
            sp.edit().putInt("activity_" + key, today).apply();
        }
        if (activityChart != null) {
            android.content.SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
            // Data harian dicatat permanen oleh AppState, termasuk saat UI tidak sedang terbuka.
            float[] values = new float[7];
            Calendar monday = Calendar.getInstance();
            int day = monday.get(Calendar.DAY_OF_WEEK);
            int daysFromMonday = (day == Calendar.SUNDAY) ? 6 : day - Calendar.MONDAY;
            monday.add(Calendar.DAY_OF_YEAR, -daysFromMonday);
            for (int i = 0; i < 7; i++) {
                Calendar d = (Calendar) monday.clone();
                d.add(Calendar.DAY_OF_YEAR, i);
                String key = new SimpleDateFormat("yyyyMMdd", Locale.US).format(d.getTime());
                values[i] = AppState.getDaily(key);
            }
            activityChart.setValues(values);
        }
    }
    private void appendLog(String message) {
        String time=new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date());
        logs.add("["+time+"] "+message);
        if(logs.size()>200) logs.remove(0);
        renderLog(currentLogFilter);
        refreshUi();
        if(logScroll!=null) logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void selectLogFilter(String filter) {
        currentLogFilter = filter;
        updateLogFilterUi();
        renderLog(filter);
    }

    private void updateLogFilterUi() {
        int active = Color.parseColor("#FFFFFF");
        int muted = Color.parseColor("#A9A5B8");
        int[] ids = {R.id.filterAll, R.id.filterSuccess, R.id.filterDelete, R.id.filterRetry};
        String[] filters = {"all", "success", "delete", "retry"};
        for (int i = 0; i < ids.length; i++) {
            Button b = findViewById(ids[i]);
            if (b != null) {
                boolean selected = filters[i].equals(currentLogFilter);
                b.setBackgroundResource(selected ? R.drawable.chip_active : R.drawable.chip);
                b.setTextColor(selected ? active : muted);
            }
        }
    }

    private void renderLog(String filter) {
        if(logText==null)return;
        StringBuilder s=new StringBuilder();
        for(String line:logs){
            String x=line.toLowerCase(Locale.ROOT);
            boolean ok="all".equals(filter)
                    || ("success".equals(filter) && (x.contains("[ok]")||x.contains("berhasil")))
                    || ("delete".equals(filter) && (x.contains("[del]")||x.contains("dihapus")))
                    || ("retry".equals(filter) && (x.contains("retry")||x.contains("[RETRY]")));
            if(ok)s.append(line).append('\n');
        }
        String rendered=s.length()==0?"Belum ada aktivitas.":s.toString();
        if(rendered.equals(lastRenderedLog)) return;
        lastRenderedLog=rendered;
        logText.setAlpha(0.45f);
        logText.setText(rendered);
        logText.setTextColor(Color.parseColor("#A9A5B8"));
        logText.animate().alpha(1f).setDuration(180).start();
    }

    private void showPage(int page) { showPage(page, true); }

    private void showPage(int page, boolean animate) {
        currentPage=page;
        View target = page==0?pageHome:page==1?pageLog:page==2?pageStats:pageSettings;
        View[] pages = new View[]{pageHome,pageLog,pageStats,pageSettings};
        for (View p : pages) {
            if (p != target) p.setVisibility(View.GONE);
        }
        target.setVisibility(View.VISIBLE);
        if (animate) {
            target.setAlpha(0f); target.setTranslationY(22f);
            target.animate().alpha(1f).translationY(0f).setDuration(600).setInterpolator(new DecelerateInterpolator()).start();
            animateEntry(target, 40);
        } else { target.setAlpha(1f); target.setTranslationY(0f); }
        int muted=Color.parseColor("#A9A5B8"), active=Color.parseColor("#C56CFF");
        Button navHome = (Button)findViewById(R.id.navHome);
        Button navLog = (Button)findViewById(R.id.navLog);
        Button navStats = (Button)findViewById(R.id.navStats);
        Button navSettings = (Button)findViewById(R.id.navSettings);
        navHome.setTextColor(page==0?active:muted);
        navLog.setTextColor(page==1?active:muted);
        navStats.setTextColor(page==2?active:muted);
        navSettings.setTextColor(page==3?active:muted);
        navHome.setBackgroundResource(page==0?R.drawable.nav_active:android.R.color.transparent);
        navLog.setBackgroundResource(page==1?R.drawable.nav_active:android.R.color.transparent);
        navStats.setBackgroundResource(page==2?R.drawable.nav_active:android.R.color.transparent);
        navSettings.setBackgroundResource(page==3?R.drawable.nav_active:android.R.color.transparent);
        tintBottomNavIcon(navHome, page==0 ? active : muted);
        tintBottomNavIcon(navLog, page==1 ? active : muted);
        tintBottomNavIcon(navStats, page==2 ? active : muted);
        tintBottomNavIcon(navSettings, page==3 ? active : muted);
    }

    private void tintBottomNavIcon(Button button, int color) {
        if (button == null) return;
        android.graphics.drawable.Drawable[] drawables = button.getCompoundDrawables();
        if (drawables.length > 1 && drawables[1] != null) {
            drawables[1].mutate().setTint(color);
        }
    }

    private void animateEntry(View view, long baseDelay) {
        if (!(view instanceof ViewGroup)) return;
        ViewGroup group = (ViewGroup) view;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            if (child.getId() == R.id.loadingOverlay) continue;
            child.setAlpha(0f);
            child.setTranslationY(16f);
            child.animate().alpha(1f).translationY(0f)
                    .setStartDelay(baseDelay + (i * 45L))
                    .setDuration(260)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        }
    }

    private void playStartupLoading() {
        if (loadingShown) return;
        loadingShown = true;
        final View overlay = findViewById(R.id.loadingOverlay);
        final View logo = findViewById(R.id.loadingLogo);
        final View progress = findViewById(R.id.loadingProgress);
        final TextView percent = findViewById(R.id.loadingPercent);
        final TextView status = findViewById(R.id.loadingStatus);
        overlay.setVisibility(View.VISIBLE);
        overlay.setAlpha(1f);
        progress.setScaleX(0f);
        progress.setPivotX(0f);
        ObjectAnimator pulse = ObjectAnimator.ofFloat(logo, View.ALPHA, 0.68f, 1f);
        pulse.setDuration(900); pulse.setRepeatMode(ValueAnimator.REVERSE); pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setInterpolator(new AccelerateDecelerateInterpolator()); pulse.start();
        ObjectAnimator scale = ObjectAnimator.ofPropertyValuesHolder(logo,
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 0.985f, 1.02f),
                android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.985f, 1.02f));
        scale.setDuration(1100); scale.setRepeatMode(ValueAnimator.REVERSE); scale.setRepeatCount(ValueAnimator.INFINITE);
        scale.setInterpolator(new AccelerateDecelerateInterpolator()); scale.start();

        ValueAnimator progressAnim = ValueAnimator.ofInt(0, 100);
        progressAnim.setDuration(5000L);
        progressAnim.setInterpolator(new DecelerateInterpolator());
        progressAnim.addUpdateListener(a -> {
            int value = (Integer)a.getAnimatedValue();
            progress.setScaleX(value / 100f);
            percent.setText(value + "%");
            if (value < 30) status.setText("Menyiapkan antarmuka...");
            else if (value < 65) status.setText("Memuat modul UI...");
            else if (value < 90) status.setText("Menyiapkan status aplikasi...");
            else status.setText("Hampir selesai...");
        });
        progressAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                pulse.cancel();
                scale.cancel();
                overlay.animate().alpha(0f).setDuration(420).setInterpolator(new DecelerateInterpolator()).withEndAction(() -> overlay.setVisibility(View.GONE)).start();
            }
        });
        progressAnim.start();
    }

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onResume(){
        super.onResume();
        if (!LicenseManager.isActivated(this)) {
            if (findViewById(R.id.licensePage) == null) showLicensePage();
            return;
        }
        refreshUi(); refreshMediaUi();
    }
    @Override protected void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
}
