package com.manzxdigital.autoklikpro;

import android.app.Notification;
import android.app.PendingIntent;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.content.ComponentName;
import android.os.Handler;
import android.os.Looper;

import java.util.List;

/**
 * Optional media-control bridge. It does not capture or record audio.
 * When enabled by the user, AutoKlik Pro can send PLAY to an active Spotify
 * media session after TikTok takes focus, so Spotify can continue/resume.
 */
public class SpotifyMediaNotificationService extends NotificationListenerService {
    private static SpotifyMediaNotificationService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final String SPOTIFY = "com.spotify.music";
    private static final long[] RESUME_DELAYS_MS = {0L, 700L, 1400L, 2400L, 4000L, 6500L, 9000L};
    private int resumeGeneration = 0;
    private StatusBarNotification lastSpotifyNotification;

    public static boolean isConnected() { return instance != null; }

    @Override public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
        // onListenerConnected() does not replay old notifications through
        // onNotificationPosted(). Seed the cached Spotify notification from the
        // current notification list so the first PLAY request can work immediately.
        try {
            StatusBarNotification[] active = getActiveNotifications();
            if (active != null) {
                for (StatusBarNotification sbn : active) {
                    if (sbn != null && SPOTIFY.equals(sbn.getPackageName())) {
                        lastSpotifyNotification = sbn;
                        break;
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    @Override public void onListenerDisconnected() {
        if (instance == this) instance = null;
        super.onListenerDisconnected();
    }

    public static void keepSpotifyPlaying() {
        SpotifyMediaNotificationService s = instance;
        if (s != null) s.resumeSpotifyBurst();
    }

    private void resumeSpotifyBurst() {
        final int generation = ++resumeGeneration;
        // TikTok can take/re-take audio focus several times while its video player
        // is starting. Keep trying for a few seconds instead of issuing PLAY once.
        for (long delay : RESUME_DELAYS_MS) {
            handler.postDelayed(() -> {
                if (generation != resumeGeneration) return;
                if (resumeSpotifyOnce()) {
                    // Once PLAY has been accepted, one later verification is enough.
                    handler.postDelayed(() -> {
                        if (generation == resumeGeneration) resumeSpotifyOnce();
                    }, 1200L);
                }
            }, delay);
        }
    }

    /**
     * @return true when a Spotify media session/notification accepted a PLAY command.
     */
    private boolean resumeSpotifyOnce() {
        try {
            MediaSessionManager manager = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            if (manager == null) return false;

            List<MediaController> sessions = manager.getActiveSessions(new ComponentName(this, getClass()));
            if (sessions != null) {
                for (MediaController controller : sessions) {
                    if (controller == null || !SPOTIFY.equals(controller.getPackageName())) continue;

                    MediaController.TransportControls controls = controller.getTransportControls();
                    if (controls == null) continue;

                    android.media.session.PlaybackState state = controller.getPlaybackState();
                    int playback = state == null ? android.media.session.PlaybackState.STATE_NONE : state.getState();

                    if (playback != android.media.session.PlaybackState.STATE_PLAYING) {
                        controls.play();
                    }
                    return true;
                }
            }

            // If Spotify's session is temporarily absent, use the notification action.
            // Do not launch Spotify over TikTok: that breaks the automation flow and
            // is the opposite of the requested "music tetap play" behavior.
            if (sendSpotifyPlayNotificationAction()) return true;
        } catch (Throwable ignored) {
            // Notification-listener/media-session availability can change while
            // another app is taking audio focus. The next scheduled attempt retries.
        }
        return false;
    }

    private boolean sendSpotifyPlayNotificationAction() {
        StatusBarNotification sbn = lastSpotifyNotification;
        if (sbn == null || !SPOTIFY.equals(sbn.getPackageName())) return false;

        Notification notification = sbn.getNotification();
        if (notification == null || notification.actions == null) return false;

        for (Notification.Action action : notification.actions) {
            if (action == null || action.actionIntent == null || action.title == null) continue;
            String title = String.valueOf(action.title).toLowerCase(java.util.Locale.ROOT);
            if (title.contains("play") || title.contains("putar") || title.contains("resume") || title.contains("lanjut")) {
                try {
                    action.actionIntent.send();
                    return true;
                } catch (PendingIntent.CanceledException ignored) {
                }
            }
        }
        return false;
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn != null && SPOTIFY.equals(sbn.getPackageName())) {
            lastSpotifyNotification = sbn;
        }
    }
    @Override public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn != null && SPOTIFY.equals(sbn.getPackageName())
                && lastSpotifyNotification != null
                && sbn.getId() == lastSpotifyNotification.getId()) {
            lastSpotifyNotification = null;
        }
    }
}
