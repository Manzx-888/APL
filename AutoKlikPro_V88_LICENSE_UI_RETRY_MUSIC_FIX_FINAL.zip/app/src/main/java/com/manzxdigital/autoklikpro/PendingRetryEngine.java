package com.manzxdigital.autoklikpro;

import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityNodeInfo;
import com.manzxdigital.autoklikpro.engine.AppState;
import com.manzxdigital.autoklikpro.engine.Logger;
import com.manzxdigital.autoklikpro.engine.RetryManager;
import com.manzxdigital.autoklikpro.engine.Task;
import com.manzxdigital.autoklikpro.engine.TaskParser;
import com.manzxdigital.autoklikpro.engine.TaskScanner;
import com.manzxdigital.autoklikpro.engine.TaskVerifier;
import java.util.List;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Owns ONLY Mutualan's "Tugas Tertunda" section.
 * Permanent follow/like verification errors are handed to the service for a
 * full task -> TikTok -> verification -> Mutualan cycle. Other permanent
 * conditions are deleted immediately; generic errors keep the 5x retry/skip rule.
 */
public final class PendingRetryEngine {
    private static final long POLL_MS = 450L;
    private static final long RESULT_TIMEOUT_MS = 45000L;
    private final AutomationAccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final RetryManager retries = new RetryManager(5);
    private volatile boolean running;
    private volatile boolean busy;
    private String activeKey = "";
    private long waitingSince;
    private boolean emptyLogged;
    private int scanMisses;
    private final Set<String> skippedKeys = new HashSet<>();
    private volatile boolean batchActive;

    public PendingRetryEngine(AutomationAccessibilityService service) { this.service = service; }

    public void start() {
        running = true; busy = false; batchActive = false; emptyLogged = false; scanMisses = 0;
        handler.removeCallbacksAndMessages(null);
        // Dormant until the service sees the real pending-detail page. This avoids
        // polling the normal Mutualan home screen hundreds of times per minute.
    }
    public void pause() { running = false; busy = false; handler.removeCallbacksAndMessages(null); }
    public void reset() { running = false; busy = false; batchActive = false; activeKey = ""; waitingSince=0; emptyLogged=false; skippedKeys.clear(); retries.clearAll(); handler.removeCallbacksAndMessages(null); }
    public void stop() { reset(); }
    public boolean isBusy() { return busy; }
    public boolean isBatchActive() { return batchActive; }

    public boolean isPendingScreen(AccessibilityNodeInfo root) {
        if (root == null) return false;
        String text = collectText(root).toLowerCase(Locale.ROOT);
        // The main Mutualan page also contains the words "Tugas Tertunda".
        // Therefore the header alone is NOT enough to classify the current page.
        // A real pending-detail page exposes task failure/verification rows or
        // retry/delete controls.
        boolean hasVerificationRow = text.contains("verifikasi follow")
                || text.contains("verifikasi like")
                || text.contains("aplikasi tertutup sebelum tugas selesai");
        boolean hasPendingControls = text.contains("retry")
                || text.contains("coba lagi")
                || text.contains("hapus")
                || text.contains("gagal:");
        boolean hasPendingHeader = text.contains("tugas tertunda");
        boolean hasBackToolbar = hasPendingHeader && (text.contains("back") || text.contains("kembali") || text.contains("navigate up"));
        boolean explicitEmpty = hasPendingHeader
                && (text.contains("tidak ada tugas tertunda")
                || text.contains("tidak ada tugas")
                || text.contains("belum ada tugas tertunda")
                || text.contains("tugas tertunda kosong"));
        // Mutualan's WebView can temporarily expose only the page header while
        // rows/buttons are still attaching to the accessibility tree. The old
        // detector treated that state as the normal Task page, released the retry
        // lock, and FOLLOW/LIKE started again. A dedicated pending page is any
        // "Tugas Tertunda" page that is not the Mutualan home/beranda.
        boolean dedicatedPendingPage = hasPendingHeader && !text.contains("beranda");
        return dedicatedPendingPage || (hasVerificationRow && hasPendingControls) || explicitEmpty || hasBackToolbar;
    }

    /** Reads Mutualan's visible counter, e.g. "Ada 60 tugas tertunda". */
    public int getPendingCount(AccessibilityNodeInfo root) {
        if (root == null) return 0;
        String text = collectText(root).replaceAll("\\s+", " ").trim().toLowerCase(Locale.ROOT);
        Matcher m = Pattern.compile("(?:ada\\s+)?(\\d{1,6})\\s+tugas\\s+tertunda", Pattern.CASE_INSENSITIVE).matcher(text);
        int best = 0;
        while (m.find()) {
            try { best = Math.max(best, Integer.parseInt(m.group(1))); } catch (Throwable ignored) {}
        }
        return best;
    }

    public void onPendingEvent(AccessibilityNodeInfo root, String pkg) {
        if (!running || !MainActivity.isRunning()) return;
        if (!service.isMutualanPackagePublic(pkg)) return;
        if (!isPendingScreen(root)) return;
        if (!busy) handler.removeCallbacks(scanRunnable);
        handler.postDelayed(scanRunnable, 100L);
    }
    private final Runnable scanRunnable = this::scanNow;

    public void scanNow() {
        if (!running || !MainActivity.isRunning() || busy) return;
        AccessibilityNodeInfo root = service.findMutualanRootForEngine();
        if (root == null) { handler.postDelayed(scanRunnable, POLL_MS); return; }
        String rootText = collectText(root).toLowerCase(Locale.ROOT);
        boolean pendingLikePage = isPendingScreen(root)
                || (rootText.contains("tugas tertunda") && (rootText.contains("verifikasi") || rootText.contains("gagal:")));
        if (!pendingLikePage) { handler.postDelayed(scanRunnable, POLL_MS); return; }

        AppState.setMode(AppState.Mode.RETRY);
        AppState.setTaskState(AppState.TaskState.SCANNING);
        List<Task> tasks = TaskScanner.scan(root);
        AppState.setRemaining(tasks.size());
        MainActivity.refreshUiStatic();

        if (tasks.isEmpty()) {
            String visible = rootText.replaceAll("\\s+", " ").trim();
            boolean explicitEmpty = visible.contains("tidak ada tugas tertunda") || visible.contains("belum ada tugas tertunda") || visible.contains("tugas tertunda kosong");
            scanMisses++;
            if (explicitEmpty) {
                scanMisses = 0;
                busy = false;
                if (!emptyLogged) { emptyLogged=true; Logger.i("[OK] Tugas Tertunda kosong → kembali ke Task utama"); }
                activeKey=""; AppState.setActiveTaskKey(""); AppState.setRetryAttempt(0);
                handler.removeCallbacks(scanRunnable);
                service.leavePendingScreenAndResumeMain();
                return;
            }
            busy = false;
            if (scanMisses >= 60) {
                scanMisses = 0;
                Logger.i("[WAIT] Scanner pending belum membaca baris setelah 60x → tetap terkunci di Tugas Tertunda");
            } else {
                Logger.i("[WAIT] Halaman Tugas Tertunda terbuka, tetapi baris belum terbaca (" + scanMisses + "/60)");
            }
            handler.postDelayed(scanRunnable, 900L);
            return;
        }
        emptyLogged=false;
        scanMisses=0;
        batchActive = true;
        // Drop skip markers for rows that no longer exist, then choose the first
        // pending row that is not temporarily skipped after exhausting retries.
        Set<String> present = new HashSet<>();
        for (Task t : tasks) present.add(t.key);
        skippedKeys.retainAll(present);
        Task task = null;
        for (Task candidate : tasks) {
            if (!skippedKeys.contains(candidate.key)) { task = candidate; break; }
        }
        if (task == null) {
            if (!emptyLogged) { emptyLogged=true; Logger.i("[OK] Semua Tugas Tertunda sudah diproses/di-skip → kembali ke Task utama"); }
            activeKey=""; AppState.setActiveTaskKey(""); AppState.setRetryAttempt(0);
            handler.removeCallbacks(scanRunnable);
            service.leavePendingScreenAndResumeMain();
            return;
        }
        AppState.setTaskState(AppState.TaskState.TASK_FOUND);
        if (!task.key.equals(activeKey)) { activeKey=task.key; AppState.setRetryAttempt(retries.get(task.key)); }
        process(task);
    }

    public void deleteFromService(Task task) {
        if (!running || task == null) return;
        busy = true;
        AppState.setActiveTaskKey(task.key);
        AppState.setTaskState(AppState.TaskState.VERIFYING);
        Logger.i("[DEL] " + shortKey(task) + " → hapus tugas");
        delete(task);
    }

    public void resumeAfterExternalAction() {
        if (!running) return;
        busy = false;
        activeKey = "";
        AppState.setActiveTaskKey("");
        AppState.setRetryAttempt(0);
        handler.removeCallbacks(scanRunnable);
        // Retry lock is released only after the pending row is actually gone.
        handler.postDelayed(scanRunnable, 350L);
    }

    private void process(Task task) {
        if (busy) return;
        busy=true; AppState.setActiveTaskKey(task.key); AppState.setTaskState(AppState.TaskState.EXECUTING);
        // Permanent conditions ALWAYS win: they are deleted immediately and
        // must never enter the TikTok action/retry cycle.
        if (TaskParser.isPermanentDelete(task.failure)) {
            Logger.i("[DEL] " + shortKey(task) + " → kondisi permanen → hapus langsung");
            delete(task); return;
        }
        if (retries.exhausted(task.key)) {
            // Generic failures: after five retries, DELETE the row.
            // Permanent conditions are also handled by the explicit delete branch.
            AppState.setTaskState(AppState.TaskState.FAILED_AFTER_5_RETRIES);
            Logger.i("[DEL] " + shortKey(task) + " → gagal 5× → HAPUS tugas");
            delete(task);
            return;
        }
        AccessibilityNodeInfo button = task.retryNode;
        if (button == null) {
            busy=false;
            Logger.i("[WARN] " + shortKey(task) + " → tombol RETRY tidak terdeteksi, tidak klik random/detail");
            handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs());
            return;
        }
        if (!clickBest(button)) {
            busy=false; Logger.i("[WARN] " + shortKey(task) + " → tombol retry tidak ditemukan");
            handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs()); return;
        }
        int attempt=retries.next(task.key);
        AppState.setRetryAttempt(attempt); AppState.incRetry();
        AppState.setTaskState(AppState.TaskState.RETRY);
        waitingSince=System.currentTimeMillis();
        Logger.i("[RETRY] " + shortKey(task) + " → retry " + attempt + "/5");
        waitForResult(task.key);
    }

    private void delete(Task task) {
        if (!clickBest(task.deleteNode)) {
            busy=false; Logger.i("[WARN] " + shortKey(task) + " → tombol hapus tidak ditemukan");
            handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs()); return;
        }
        AppState.setTaskState(AppState.TaskState.VERIFYING);
        waitingSince=System.currentTimeMillis();
        waitForDeleteResult(task.key);
    }


    /** Accept a refreshed pending page even when Mutualan temporarily omits the
     * retry/delete labels from the accessibility tree. The old strict gate could
     * wait forever after large batches and leave the automation on the retry tab.
     */
    private boolean isRetryResultScreen(AccessibilityNodeInfo root) {
        if (root == null) return false;
        String text = collectText(root).replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        if (!text.contains("tugas tertunda")) return false;
        return !text.contains("beranda") || text.contains("verifikasi follow") || text.contains("verifikasi like")
                || text.contains("gagal:") || text.contains("retry")
                || text.contains("coba lagi") || text.contains("hapus")
                || text.contains("tidak ada tugas tertunda")
                || text.contains("belum ada tugas tertunda");
    }

    private void waitForResult(String key) {
        handler.postDelayed(() -> {
            if (!running || !MainActivity.isRunning()) { busy=false; return; }
            if (System.currentTimeMillis()-waitingSince > RESULT_TIMEOUT_MS) {
                busy=false; waitingSince=0; Logger.i("[WARN] " + key + " → timeout / aplikasi target tertutup");
                handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs()); return;
            }
            AccessibilityNodeInfo root=service.findMutualanRootForEngine();
            if (root==null || !isRetryResultScreen(root)) { handler.postDelayed(() -> waitForResult(key), POLL_MS); return; }
            List<Task> tasks=TaskScanner.scan(root); AppState.setRemaining(tasks.size());
            Task same=TaskVerifier.findSame(tasks,key);
            AppState.setTaskState(AppState.TaskState.VERIFYING);
            if (same==null) {
                busy=false; waitingSince=0; AppState.incSuccess(); AppState.setTaskState(AppState.TaskState.SUCCESS);
                retries.clear(key); activeKey=""; AppState.setActiveTaskKey(""); AppState.setRetryAttempt(0);
                Logger.i("[OK] " + key + " → task hilang/berubah, berhasil");
                handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs()); return;
            }
            busy=false; Logger.i("[RETRY] " + key + " → task masih ada, verifikasi gagal → scan ulang");
            handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs());
        }, 220L);
    }

    private void waitForDeleteResult(String key) {
        handler.postDelayed(() -> {
            if (!running || !MainActivity.isRunning()) { busy=false; return; }
            if (System.currentTimeMillis()-waitingSince > RESULT_TIMEOUT_MS) {
                busy=false; Logger.i("[WARN] " + key + " → timeout verifikasi hapus"); handler.postDelayed(scanRunnable, Math.max(500L, MainActivity.getRetryDelayMs())); return;
            }
            AccessibilityNodeInfo root=service.findMutualanRootForEngine();
            if(root==null || !isPendingScreen(root)){ handler.postDelayed(() -> waitForDeleteResult(key),POLL_MS); return; }
            List<Task> tasks=TaskScanner.scan(root); AppState.setRemaining(tasks.size());
            if(TaskVerifier.disappeared(tasks,key)){
                busy=false; waitingSince=0; AppState.incDeleted(); AppState.setTaskState(AppState.TaskState.SUCCESS);
                activeKey=""; AppState.setActiveTaskKey(""); AppState.setRetryAttempt(0); retries.clear(key);
                Logger.i("[OK] " + key + " → task dihapus dan terverifikasi");
                service.pendingActionFinishedDelete();
                handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs());
            } else {
                busy=false; Logger.i("[WARN] " + key + " → task masih ada setelah hapus"); handler.postDelayed(scanRunnable, MainActivity.getRetryDelayMs());
            }
        },220L);
    }

    private boolean clickBest(AccessibilityNodeInfo node){
        AccessibilityNodeInfo n=node;
        for(int i=0;i<7 && n!=null;i++){ if(n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; n=n.getParent(); }
        return false;
    }
    private String shortKey(Task t){ return t.type.name().toLowerCase(Locale.ROOT)+" "+(t.username.isEmpty()?t.key:t.username); }
    private String collectText(AccessibilityNodeInfo root){StringBuilder s=new StringBuilder();walk(root,n->{if(n.isVisibleToUser()){String x=TaskParser.ownText(n);if(!x.isEmpty())s.append('\n').append(x);}});return s.toString();}
    private interface Walker{void a(AccessibilityNodeInfo n);} private void walk(AccessibilityNodeInfo n,Walker w){if(n==null)return;w.a(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)walk(c,w);}}
}
