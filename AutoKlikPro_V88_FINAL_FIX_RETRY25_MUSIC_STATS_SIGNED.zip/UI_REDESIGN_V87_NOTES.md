# AutoKlik Pro V87 — Neon UI

UI rebuilt from the approved MANZX DIGITAL neon/cyberpunk design direction.

## What changed
- Redesigned Beranda, Log, Statistik, and Pengaturan screens.
- Added stronger glassmorphism cards, neon borders, spacing hierarchy, and active navigation state.
- Kept the existing view IDs so MainActivity/automation wiring continues to use the same data sources.
- Kept Accessibility, scanner, retry, verifier, executor, and logger classes unchanged.
- Statistics remain driven by AppState/session history; no fake task counters were introduced.
- Added a root-project GitHub Actions workflow at `.github/workflows/build-v87-neon-ui.yml`.

## Important
This is a real Android UI implementation, not a screenshot used as a background. Buttons, navigation, logs, counters, settings, and chart remain actual Android views.
