# AutoKlik Pro UI Redesign v85

## Scope
UI/UX redesign only, based on the supplied neon-purple reference collage. Automation behavior is not intentionally changed.

## Reference layout
- Header: lightning logo, AutoKlik Pro, BY MANZXDIGITAL, v2.0.
- Home: accessibility/status cards, MULAI, STOP/PAUSE, RESET STATE, Aktivitas saat ini, Kontrol cepat, Mode aktif.
- Log: title/subtitle, HAPUS LOG, four filters, large scrollable log panel.
- Statistik: three KPI cards, Statistik Target (Follow/Like), Ringkasan Aktivitas, and three summary tiles.
- Pengaturan: accessibility, delay controls, media, about, help.
- Bottom navigation: BERANDA / LOG / STATISTIK / PENGATURAN.
- Loading: full-screen MANZX DIGITAL neon treatment.

## Data integrity
- Dashboard and statistics counters read directly from AppState.
- Log screen renders the actual in-memory Logger/MainActivity log; no fabricated sample log entries are included.
- Total Task is calculated from processed outcome counters.
- Success Rate is calculated from real processed outcomes.
- Active Duration is measured from the current UI session.
- Seven-day chart uses locally recorded UI-session activity deltas; missing days remain zero rather than being invented.

## Automation preservation
These engine files were preserved byte-for-byte from the supplied V84 source:
- AutomationAccessibilityService.java
- PendingRetryEngine.java
- engine/AppState.java
- engine/Logger.java
- engine/RetryManager.java
- engine/Task.java
- engine/TaskExecutor.java
- engine/TaskParser.java
- engine/TaskScanner.java
- engine/TaskVerifier.java

Only UI presentation files were changed: MainActivity.java, NeonChartView.java, and activity_main.xml plus visual resources already present in the supplied source.
