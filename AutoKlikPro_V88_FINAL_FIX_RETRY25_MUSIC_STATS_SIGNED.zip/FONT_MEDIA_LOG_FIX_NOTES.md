# V88 Font + Media + Log Fix

- Splash `MANZX` + `DIGITAL`: Climate Crisis.
- Header `AutoKlik Pro`: Blaka.
- Card/section titles enlarged.
- Log filters now change the rendered list and active chip correctly; `[OK]` / `[DEL]` matching is case-correct.
- Media section is now a Spotify keep-playing control, not photo/media-library access.
- Spotify control uses Android Notification Listener access and MediaSession transport controls. It requests PLAY repeatedly after TikTok becomes active.
- External GitHub Actions workflow downloads the exact TTFs at build time into `app/src/main/res/font/` before Gradle build.
