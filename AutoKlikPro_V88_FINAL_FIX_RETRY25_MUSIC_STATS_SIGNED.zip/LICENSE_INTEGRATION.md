# MANZX License Integration

AutoKlik Pro and MANZX License Generator use the same ECDSA P-256 public key and compact license protocol.

Payload: 22 bytes + raw ECDSA P-256 signature (64 bytes).
Device prefix: MNZX-.

The AutoKlik APK contains only the public verification key.
The Generator contains the signing private key and must remain private.
