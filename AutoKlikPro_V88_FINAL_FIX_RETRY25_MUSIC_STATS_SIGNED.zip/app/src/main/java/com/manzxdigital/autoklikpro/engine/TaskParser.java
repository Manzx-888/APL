package com.manzxdigital.autoklikpro.engine;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TaskParser {
    private static final Pattern USER = Pattern.compile("@[A-Za-z0-9._-]{2,40}");
    private TaskParser() {}

    public static String ownText(android.view.accessibility.AccessibilityNodeInfo node) {
        if (node == null) return "";
        String a = node.getText() == null ? "" : node.getText().toString().trim();
        String b = node.getContentDescription() == null ? "" : node.getContentDescription().toString().trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty() || a.equals(b)) return a;
        return a + " " + b;
    }

    public static String username(String text) {
        Matcher m = USER.matcher(text == null ? "" : text);
        return m.find() ? m.group().toLowerCase(Locale.ROOT) : "";
    }

    public static Task.Type type(String text) {
        String x = text == null ? "" : text.toLowerCase(Locale.ROOT);
        if (x.contains("follow") || x.contains("ikuti")) return Task.Type.FOLLOW;
        if (x.contains("like") || x.contains("suka")) return Task.Type.LIKE;
        if (x.contains("comment") || x.contains("komen")) return Task.Type.COMMENT;
        if (x.contains("engagement")) return Task.Type.ENGAGEMENT;
        return Task.Type.UNKNOWN;
    }

    public static String key(String title) {
        String normalized = (title == null ? "" : title).toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        String user = username(title);
        return type(title).name().toLowerCase(Locale.ROOT) + "|" + user + "|" + normalized;
    }

    public static boolean isTaskTitle(String text) {
        String x = (text == null ? "" : text).replaceAll("\\s+", " ").trim().toLowerCase(Locale.ROOT);
        return x.matches(".*verifikasi\\s+(follow|like)\\b.*") || x.contains("verifikasi like pada postingan") || x.contains("verifikasi follow pada");
    }

    public static boolean isActionRecoveryFailure(String failure) {
        // Kept for compatibility with older callers. These messages are now
        // permanent conditions and are handled by isPermanentDelete().
        return false;
    }

    public static boolean isPermanentDelete(String failure) {
        String x = failure == null ? "" : failure.toLowerCase(Locale.ROOT);
        return containsAny(x, "akun belum diikuti", "account not followed", "posting belum disukai", "post belum disukai", "posting not liked",
                "engagement sudah mencapai target", "target sudah tercapai", "engagement reached", "target reached", "task invalid", "invalid task");
    }

    public static boolean containsAny(String text, String... values) {
        String x = text == null ? "" : text.toLowerCase(Locale.ROOT);
        for (String v : values) if (x.contains(v.toLowerCase(Locale.ROOT))) return true;
        return false;
    }
}
