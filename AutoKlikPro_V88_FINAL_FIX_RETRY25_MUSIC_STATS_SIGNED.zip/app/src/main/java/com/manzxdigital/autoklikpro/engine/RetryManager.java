package com.manzxdigital.autoklikpro.engine;

import java.util.HashMap;
import java.util.Map;

public final class RetryManager {
    private final Map<String, Integer> attempts = new HashMap<>();
    private final int max;
    public RetryManager(int max) { this.max = Math.max(1, max); }
    public synchronized int next(String key) { int n = attempts.getOrDefault(key, 0) + 1; attempts.put(key, n); return n; }
    public synchronized int get(String key) { return attempts.getOrDefault(key, 0); }
    public synchronized boolean exhausted(String key) { return get(key) >= max; }
    public synchronized void clear(String key) { attempts.remove(key); }
    public synchronized void clearAll() { attempts.clear(); }
    public int max() { return max; }
}
