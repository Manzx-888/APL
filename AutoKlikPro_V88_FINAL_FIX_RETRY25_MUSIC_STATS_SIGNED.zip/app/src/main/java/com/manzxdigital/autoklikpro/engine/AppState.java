package com.manzxdigital.autoklikpro.engine;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class AppState {
    public enum Mode { IDLE, TASK, RETRY }
    public enum TaskState { IDLE, SCANNING, TASK_FOUND, EXECUTING, VERIFYING, SUCCESS, RETRY, FAILED_AFTER_5_RETRIES }

    private static volatile Mode mode = Mode.IDLE;
    private static volatile TaskState taskState = TaskState.IDLE;
    private static volatile String activeTaskKey = "";
    private static volatile int retryAttempt = 0;
    private static volatile int success = 0;
    private static volatile int failed = 0;
    private static volatile int skipped = 0;
    private static volatile int deleted = 0;
    private static volatile int retryTotal = 0;
    private static volatile int followTotal = 0;
    private static volatile int likeTotal = 0;
    private static volatile int remaining = 0;
    private static SharedPreferences persistent;

    public static synchronized void init(Context context) {
        if (context != null && persistent == null) {
            persistent = context.getApplicationContext().getSharedPreferences("autoklik_totals", Context.MODE_PRIVATE);
        }
    }

    private static void persist(String key, int value) {
        if (persistent != null) persistent.edit().putInt(key, value).apply();
    }

    private static void recordDaily(String type) {
        if (persistent == null) return;
        String day = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        String key = "daily_" + day + "_" + type;
        persistent.edit().putInt(key, persistent.getInt(key, 0) + 1).apply();
    }

    public static int getPersistent(String key) { return persistent == null ? 0 : persistent.getInt(key, 0); }
    public static int getDaily(String day) { return getDailyType(day, "success"); }
    public static int getDailyType(String day, String type) {
        return persistent == null ? 0 : persistent.getInt("daily_" + day + "_" + type, 0);
    }

    private AppState() {}

    public static synchronized void resetAll() {
        mode = Mode.IDLE; taskState = TaskState.IDLE; activeTaskKey = ""; retryAttempt = 0;
        success = failed = skipped = deleted = retryTotal = followTotal = likeTotal = remaining = 0;
    }
    public static Mode getMode() { return mode; }
    public static void setMode(Mode value) { mode = value; }
    public static TaskState getTaskState() { return taskState; }
    public static void setTaskState(TaskState value) { taskState = value; }
    public static String getActiveTaskKey() { return activeTaskKey; }
    public static void setActiveTaskKey(String value) { activeTaskKey = value == null ? "" : value; }
    public static int getRetryAttempt() { return retryAttempt; }
    public static void setRetryAttempt(int value) { retryAttempt = Math.max(0, value); }
    public static int getSuccess() { return persistent == null ? success : persistent.getInt("success", success); }
    public static int getFailed() { return failed; }
    public static int getSkipped() { return skipped; }
    public static int getDeleted() { return persistent == null ? deleted : persistent.getInt("deleted", deleted); }
    public static int getRetryTotal() { return persistent == null ? retryTotal : persistent.getInt("retry", retryTotal); }
    public static int getFollowTotal() { return persistent == null ? followTotal : persistent.getInt("follow", followTotal); }
    public static int getLikeTotal() { return persistent == null ? likeTotal : persistent.getInt("like", likeTotal); }
    public static int getRemaining() { return remaining; }
    public static void setRemaining(int value) { remaining = Math.max(0, value); }
    public static synchronized void incSuccess() { success++; persist("success", success); recordDaily("success"); }
    public static synchronized void incFailed() { failed++; }
    public static synchronized void incSkipped() { skipped++; }
    public static synchronized void incDeleted() { deleted++; persist("deleted", deleted); recordDaily("deleted"); }
    public static synchronized void incRetry() { retryTotal++; persist("retry", retryTotal); recordDaily("retry"); }
    public static synchronized void incFollow() { followTotal++; persist("follow", followTotal); recordDaily("follow"); }
    public static synchronized void incLike() { likeTotal++; persist("like", likeTotal); recordDaily("like"); }
}
