package com.manzxdigital.autoklikpro.engine;

import com.manzxdigital.autoklikpro.MainActivity;

public final class Logger {
    private Logger() {}
    public static void i(String message) { MainActivity.log(message); }
}
