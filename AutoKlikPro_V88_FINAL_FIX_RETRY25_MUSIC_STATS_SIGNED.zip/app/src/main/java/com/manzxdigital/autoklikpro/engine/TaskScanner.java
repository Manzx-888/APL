package com.manzxdigital.autoklikpro.engine;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parser for Mutualan's "Tugas Tertunda" rows. It deliberately does not execute actions. */
public final class TaskScanner {
    private TaskScanner() {}

    public static List<Task> scan(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> titles = new ArrayList<>();
        walk(root, n -> { if (n.isVisibleToUser() && TaskParser.isTaskTitle(TaskParser.ownText(n))) titles.add(n); });
        List<Task> result = new ArrayList<>();
        if (titles.isEmpty()) return parseFlattenedPage(root);
        for (AccessibilityNodeInfo titleNode : titles) {
            String title = TaskParser.ownText(titleNode);
            AccessibilityNodeInfo container = findContainer(titleNode);
            if (container == null) continue;
            String full = nodeText(container);
            String failure = extractFailure(full);
            AccessibilityNodeInfo[] actions = findActions(container);
            String key = TaskParser.key(title);
            if (!key.isEmpty()) result.add(new Task(key, title, TaskParser.username(title), TaskParser.type(title), failure, container, actions[0], actions[1]));
        }
        result.sort(Comparator.comparingInt(t -> top(t.container)));
        List<Task> unique = new ArrayList<>();
        for (Task t : result) {
            if (TaskVerifier.findSame(unique, t.key) == null) unique.add(t);
            if (unique.size() >= 50) break;
        }
        return unique;
    }

    private static List<Task> parseFlattenedPage(AccessibilityNodeInfo root) {
        String page=nodeText(root).replaceAll("\\s+", " ").trim();
        Pattern pat=Pattern.compile("verifikasi\\s+(follow|like)\\b.*?(?=verifikasi\\s+(?:follow|like)\\b|$)",Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
        Matcher m=pat.matcher(page); List<Task> out=new ArrayList<>();
        while(m.find() && out.size()<50){String title=m.group().trim();String key=TaskParser.key(title);if(key.isEmpty())continue;String failure=extractFailure(title);AccessibilityNodeInfo[] actions=findActions(root);out.add(new Task(key,title,TaskParser.username(title),TaskParser.type(title),failure,root,actions[0],actions[1]));}
        return out;
    }

    private static AccessibilityNodeInfo findContainer(AccessibilityNodeInfo title) {
        AccessibilityNodeInfo node = title, fallback = null;
        for (int i=0; i<12 && node != null; i++) {
            node = node.getParent(); if (node == null) break;
            Rect b = bounds(node);
            if (b.height() >= 55 && b.height() <= 380 && b.width() >= 180) {
                if (fallback == null) fallback = node;
                int right = 0;
                for (AccessibilityNodeInfo c : clickable(node)) {
                    Rect cb=bounds(c); if (cb.centerX() > b.left + b.width()*0.62f && cb.centerY() >= b.top-16 && cb.centerY() <= b.bottom+16) right++;
                }
                if (right >= 2) return node;
            }
        }
        return fallback != null ? fallback : title.getParent();
    }

    private static AccessibilityNodeInfo[] findActions(AccessibilityNodeInfo container) {
        // Never bubble a RETRY/HAPUS label all the way up to a large row/detail
        // container. That was the source of the intermittent "retry opens detail"
        // bug: the label lived inside a clickable icon, but the nearest clickable
        // ancestor could be the whole task card.
        String refreshGlyph = new String(Character.toChars(0x21BB));
        AccessibilityNodeInfo retry = findLabeled(container, "retry", "coba lagi", "muat ulang", refreshGlyph);
        String trashGlyph = new String(Character.toChars(0x1F5D1));
        AccessibilityNodeInfo delete = findLabeled(container, "hapus", "delete", "remove", "trash", "buang", trashGlyph);
        return new AccessibilityNodeInfo[]{retry, delete};
    }

    private static AccessibilityNodeInfo findLabeled(AccessibilityNodeInfo root, String... labels) {
        if (root == null) return null;
        Rect containerBounds = bounds(root);
        final AccessibilityNodeInfo[] found={null};
        walk(root,n->{
            if (found[0] != null || !n.isVisibleToUser()) return;
            StringBuilder meta = new StringBuilder(TaskParser.ownText(n));
            try { if (n.getViewIdResourceName() != null) meta.append(' ').append(n.getViewIdResourceName()); } catch (Throwable ignored) {}
            String x = meta.toString().toLowerCase();
            boolean matches = false;
            for (String l : labels) if (x.contains(l.toLowerCase())) { matches=true; break; }
            if (!matches) return;

            AccessibilityNodeInfo cur=n;
            for (int i=0; i<4 && cur!=null; i++) {
                if (cur.isVisibleToUser() && cur.isClickable()) {
                    Rect b=bounds(cur);
                    // A real action button is a small control on the right side of
                    // the task row. A full-width clickable row is NOT acceptable.
                    boolean inside = containerBounds.isEmpty() || containerBounds.contains(b);
                    boolean small = b.width() > 0 && b.height() > 0
                            && (containerBounds.isEmpty() || b.width() <= Math.max(220, (int)(containerBounds.width()*0.45f)))
                            && (containerBounds.isEmpty() || b.height() <= Math.max(140, (int)(containerBounds.height()*0.65f)));
                    boolean rightSide = containerBounds.isEmpty()
                            || b.centerX() >= containerBounds.left + containerBounds.width()*0.52f;
                    if (inside && small && rightSide) { found[0]=cur; return; }
                }
                cur=cur.getParent();
            }
        });
        return found[0];
    }
    private static List<AccessibilityNodeInfo> clickable(AccessibilityNodeInfo root){List<AccessibilityNodeInfo> o=new ArrayList<>();walk(root,n->{if(n.isVisibleToUser()&&n.isClickable())o.add(n);});return o;}
    private static String nodeText(AccessibilityNodeInfo root){StringBuilder s=new StringBuilder();walk(root,n->{String x=TaskParser.ownText(n);if(!x.isEmpty())s.append('\n').append(x);});return s.toString();}
    private static String extractFailure(String text){String[] lines=text.split("\\n");for(String l:lines){String x=l.trim().toLowerCase();if(x.startsWith("gagal:")||TaskParser.isPermanentDelete(x)||x.contains("aplikasi tertutup sebelum tugas selesai"))return l.trim();}return "";}
    private static int top(AccessibilityNodeInfo n){return bounds(n).top;}
    private static Rect bounds(AccessibilityNodeInfo n){Rect r=new Rect();if(n!=null)n.getBoundsInScreen(r);return r;}
    private interface Walker{void accept(AccessibilityNodeInfo n);} private static void walk(AccessibilityNodeInfo n,Walker w){if(n==null)return;w.accept(n);for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null)walk(c,w);}}
}
