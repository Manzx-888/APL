package com.manzxdigital.autoklikpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import android.animation.ValueAnimator;

public class NeonLightningView extends View {
    private final Paint glow=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint core=new Paint(Paint.ANTI_ALIAS_FLAG);
    private float pulse=1f;
    public NeonLightningView(Context c, AttributeSet a){super(c,a); init();}
    public NeonLightningView(Context c){super(c);init();}
    private void init(){ setLayerType(View.LAYER_TYPE_SOFTWARE,null); ValueAnimator a=ValueAnimator.ofFloat(.55f,1f); a.setDuration(950); a.setRepeatMode(ValueAnimator.REVERSE); a.setRepeatCount(ValueAnimator.INFINITE); a.addUpdateListener(v->{pulse=(Float)v.getAnimatedValue();invalidate();}); a.start(); }
    @Override protected void onDraw(Canvas c){
        float w=getWidth(),h=getHeight(); float s=Math.min(w,h)/120f; float cx=w/2f, cy=h/2f;
        Path z=new Path(); z.moveTo(cx-10*s,cy-52*s); z.lineTo(cx+16*s,cy-52*s); z.lineTo(cx-2*s,cy-8*s); z.lineTo(cx+22*s,cy-8*s); z.lineTo(cx-18*s,cy+56*s); z.lineTo(cx-5*s,cy+14*s); z.lineTo(cx-27*s,cy+14*s); z.close();
        glow.setStyle(Paint.Style.FILL); glow.setColor(0xFFD37CFF); glow.setShadowLayer(18*pulse,0,0,0xFF7B18FF); c.drawPath(z,glow);
        core.setStyle(Paint.Style.FILL); core.setColor(0xFFF8EFFF); c.drawPath(z,core);
    }
}
