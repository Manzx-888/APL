package com.manzxdigital.autoklikpro.engine;

import java.util.List;

public final class TaskVerifier {
    private TaskVerifier() {}
    public static Task findSame(List<Task> tasks, String key) {
        if (tasks == null || key == null) return null;
        for (Task t : tasks) if (key.equals(t.key)) return t;
        return null;
    }
    public static boolean disappeared(List<Task> tasks, String key) { return findSame(tasks, key) == null; }
}
