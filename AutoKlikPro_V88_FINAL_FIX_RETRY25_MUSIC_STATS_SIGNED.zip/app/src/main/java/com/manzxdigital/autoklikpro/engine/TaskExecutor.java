package com.manzxdigital.autoklikpro.engine;

/** Coordinates ownership of the single active task. The AccessibilityService remains the low-level UI driver. */
public final class TaskExecutor {
    private boolean locked;
    private String key = "";
    public synchronized boolean lock(String taskKey) {
        if (locked) return false;
        locked = true; key = taskKey == null ? "" : taskKey;
        AppState.setActiveTaskKey(key); AppState.setTaskState(AppState.TaskState.EXECUTING);
        return true;
    }
    public synchronized void unlock() { locked = false; key = ""; AppState.setActiveTaskKey(""); }
    public synchronized boolean isLocked() { return locked; }
    public synchronized String key() { return key; }
}
