package com.manzxdigital.autoklikpro;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;

import java.util.Locale;

/** Offline license verifier. The APK contains only the public verification key. */
public final class LicenseManager {
    private static final String PREF = "autoklik_license";
    private static final String KEY_ACTIVE = "active_key";
    private static final String KEY_DEVICE = "device_id";
    private static final String KEY_EXPIRY = "expiry_day";
    private static final String PREFIX = "MNZX-";
    private static final String PUBLIC_KEY_B64 = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAELzbY3iUs1SZ4S1AOoDISWib/J08wzid/xoWQ+dwciTtgNta3CfGQuikzyS+d/JHFr8cWFX1IwQaJydRuOC2hPA==";
    private static final int PAYLOAD_SIZE = 22;
    private static final int SIGNATURE_SIZE = 64;

    private LicenseManager() {}

    public static String getDeviceId(Context context) {
        String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null || androidId.trim().isEmpty()) androidId = "unknown";
        byte[] hash = sha256(androidId.toUpperCase(Locale.US).getBytes(StandardCharsets.UTF_8));
        StringBuilder s = new StringBuilder(PREFIX);
        for (int i = 0; i < 8; i++) s.append(String.format(Locale.US, "%02X", hash[i]));
        return s.toString();
    }

    public static boolean isActivated(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String key = p.getString(KEY_ACTIVE, null);
        String device = p.getString(KEY_DEVICE, null);
        if (key == null || device == null) return false;
        if (!getDeviceId(context).equals(device)) return false;
        Result result = verify(context, key);
        if (!result.valid) return false;
        return result.lifetime || epochDay() <= result.expiryDay;
    }

    public static Result activate(Context context, String licenseKey) {
        Result result = verify(context, licenseKey);
        if (!result.valid) return result;
        if (!getDeviceId(context).equals(result.deviceId)) {
            return Result.invalid("Lisensi bukan untuk perangkat ini.");
        }
        if (!result.lifetime && epochDay() > result.expiryDay) {
            return Result.invalid("Lisensi sudah kadaluarsa.");
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(KEY_ACTIVE, normalizeKey(licenseKey))
                .putString(KEY_DEVICE, result.deviceId)
                .putLong(KEY_EXPIRY, result.expiryDay)
                .apply();
        return result;
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }

    public static Result getCurrent(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String key = p.getString(KEY_ACTIVE, null);
        return key == null ? Result.invalid("Belum diaktivasi.") : verify(context, key);
    }

    private static Result verify(Context context, String licenseKey) {
        try {
            String clean = normalizeKey(licenseKey);
            if (!clean.startsWith(PREFIX)) return Result.invalid("Format license key tidak valid.");
            String encoded = clean.substring(PREFIX.length()).replace("-", "");
            byte[] all = android.util.Base64.decode(encoded, android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP);
            if (all.length != PAYLOAD_SIZE + SIGNATURE_SIZE) return Result.invalid("Panjang license key tidak valid.");

            byte[] payload = new byte[PAYLOAD_SIZE];
            byte[] signatureRaw = new byte[SIGNATURE_SIZE];
            System.arraycopy(all, 0, payload, 0, PAYLOAD_SIZE);
            System.arraycopy(all, PAYLOAD_SIZE, signatureRaw, 0, SIGNATURE_SIZE);

            PublicKey publicKey = KeyFactory.getInstance("EC").generatePublic(
                    new X509EncodedKeySpec(android.util.Base64.decode(PUBLIC_KEY_B64, android.util.Base64.DEFAULT)));

            Signature verifier = Signature.getInstance("SHA256withECDSA");
            verifier.initVerify(publicKey);
            verifier.update(payload);
            if (!verifier.verify(rawToDerP256(signatureRaw))) return Result.invalid("Signature license tidak valid.");

            ByteBuffer buffer = ByteBuffer.wrap(payload);
            int version = buffer.get() & 0xFF;
            int product = buffer.get() & 0xFF;
            if (version != 1 || product != 1) return Result.invalid("License bukan untuk AutoKlik Pro.");
            byte[] idHash = new byte[4];
            byte[] deviceHash = new byte[8];
            buffer.get(idHash);
            buffer.get(deviceHash);
            long issuedDay = ((long) buffer.getInt()) & 0xFFFFFFFFL;
            long expiryDay = ((long) buffer.getInt()) & 0xFFFFFFFFL;

            String actualDevice = getDeviceId(context);
            byte[] actualHash = sha256(actualDevice.getBytes(StandardCharsets.UTF_8));
            for (int i = 0; i < 8; i++) {
                if (deviceHash[i] != actualHash[i]) return Result.invalid("Lisensi bukan untuk perangkat ini.");
            }
            return new Result(true, "Lisensi valid.", actualDevice, issuedDay, expiryDay, expiryDay == 0L);
        } catch (Exception e) {
            return Result.invalid("License key tidak valid.");
        }
    }

    private static String normalizeKey(String value) {
        if (value == null) return "";
        return value.trim()
                .toUpperCase(Locale.US)
                .replace(" ", "")
                .replace("\n", "")
                .replace("\r", "");
    }

    private static long epochDay() { return System.currentTimeMillis() / 86400000L; }
    private static byte[] sha256(byte[] data) {
        try { return MessageDigest.getInstance("SHA-256").digest(data); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }

    // Android's ECDSA Signature API returns DER; generator stores compact r||s.
    private static byte[] rawToDerP256(byte[] raw) {
        byte[] r = trimInteger(raw, 0, 32);
        byte[] s = trimInteger(raw, 32, 32);
        int bodyLen = 2 + r.length + 2 + s.length;
        byte[] out = new byte[2 + bodyLen];
        int p = 0;
        out[p++] = 0x30; out[p++] = (byte) bodyLen;
        out[p++] = 0x02; out[p++] = (byte) r.length; System.arraycopy(r, 0, out, p, r.length); p += r.length;
        out[p++] = 0x02; out[p++] = (byte) s.length; System.arraycopy(s, 0, out, p, s.length);
        return out;
    }

    private static byte[] trimInteger(byte[] raw, int offset, int length) {
        int start = offset;
        int end = offset + length;
        while (start < end - 1 && raw[start] == 0) start++;
        int len = end - start;
        boolean high = (raw[start] & 0x80) != 0;
        byte[] out = new byte[len + (high ? 1 : 0)];
        System.arraycopy(raw, start, out, high ? 1 : 0, len);
        return out;
    }

    public static final class Result {
        public final boolean valid;
        public final String message;
        public final String deviceId;
        public final long issuedDay;
        public final long expiryDay;
        public final boolean lifetime;
        private Result(boolean valid, String message, String deviceId, long issuedDay, long expiryDay, boolean lifetime) {
            this.valid = valid; this.message = message; this.deviceId = deviceId; this.issuedDay = issuedDay; this.expiryDay = expiryDay; this.lifetime = lifetime;
        }
        static Result invalid(String message) { return new Result(false, message, "", 0, 0, false); }
    }
}
