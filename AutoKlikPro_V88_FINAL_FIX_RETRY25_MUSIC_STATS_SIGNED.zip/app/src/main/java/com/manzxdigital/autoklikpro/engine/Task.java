package com.manzxdigital.autoklikpro.engine;

import android.view.accessibility.AccessibilityNodeInfo;

public final class Task {
    public enum Type { FOLLOW, LIKE, COMMENT, ENGAGEMENT, UNKNOWN }
    public final String key;
    public final String title;
    public final String username;
    public final Type type;
    public final String failure;
    public final AccessibilityNodeInfo container;
    public final AccessibilityNodeInfo retryNode;
    public final AccessibilityNodeInfo deleteNode;

    public Task(String key, String title, String username, Type type, String failure,
                AccessibilityNodeInfo container, AccessibilityNodeInfo retryNode,
                AccessibilityNodeInfo deleteNode) {
        this.key = key; this.title = title; this.username = username; this.type = type;
        this.failure = failure == null ? "" : failure;
        this.container = container; this.retryNode = retryNode; this.deleteNode = deleteNode;
    }
}
