# AutoKlik Pro intentionally keeps reflection-sensitive Android Accessibility classes.
