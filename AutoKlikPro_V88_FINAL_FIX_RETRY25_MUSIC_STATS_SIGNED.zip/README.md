# AutoKlik Pro v65 — Like Count Anchor Fix

Fix fokus pada bug TikTok yang membuat automation menekan avatar/profil (+) alih-alih tombol Like.

Perubahan utama:
- Jangan memilih anonymous rail control berdasarkan urutan saja.
- Cari angka Like di right action rail sebagai anchor (contoh 310).
- Cari clickable control yang berada tepat di atas angka tersebut.
- Reject control yang berlabel profile/profil/report/lapor/flag.
- Structural fallback dibuat lebih ketat agar avatar besar tidak dianggap Like.
- Follow flow tidak diubah.

Catatan: build APK harus dilakukan melalui GitHub Actions karena environment lokal tidak menyediakan Gradle.


V73 FOLLOW fix: target button requires visible exact "Ikuti/Follow"; hidden recommendation follow buttons are rejected. Successful follow is verified by visible exact "Tindakan lainnya" in the profile action row. Global failure retry remains 5x; permanent conditions are deleted immediately.


V86 FIX: release APK dibuat dengan temporary signing keystore dan diverifikasi dengan apksigner sebelum artifact diupload.
